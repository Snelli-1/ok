#!/usr/bin/env python3
"""Multi-camera PTZ Patrol Controller REAL v1.3.0. Real ONVIF only."""
import configparser,logging,math,queue,threading,time,traceback
from dataclasses import dataclass,field
from pathlib import Path
from typing import Dict,List,Optional
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from real_onvif_camera_v1_3_0 import RealOnvifCamera,Position
BASE=Path(__file__).resolve().parent; CONFIG=BASE/'config_REAL_v1_3_0.ini'; LOGDIR=BASE/'logs_real';LOGDIR.mkdir(exist_ok=True)
logging.basicConfig(filename=LOGDIR/'application_real_v1_3_0.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(threadName)s %(message)s')
@dataclass
class PatrolPoint: name:str;pan:float;tilt:float;zoom:float;dwell:float=5.0;speed:float=.5
@dataclass
class CameraModel:
 id:str;name:str;host:str;onvif_port:int=8899;rtsp_port:int=554;enabled:bool=True;points:List[PatrolPoint]=field(default_factory=list);camera:Optional[RealOnvifCamera]=None;position:Position=field(default_factory=lambda:Position(None,None,None));state:str='DISCONNECTED';error:str='';step_index:int=0;next_due:float=0.0
class MultiCameraManager:
 def __init__(self,models,emit):self.models=models;self.emit=emit;self.stop_evt=threading.Event();self.pause_evt=threading.Event();self.thread=None;self.lock=threading.RLock()
 def connect_one(self,m):
  m.state='CONNECTING';self.emit(m.id,f'Connecting {m.host}:{m.onvif_port}')
  try:m.camera=RealOnvifCamera(m.host,m.onvif_port,m.rtsp_port,logger=lambda s:self.emit(m.id,s));desc=m.camera.connect();m.position=m.camera.last_position;m.state='READY';m.error='';self.emit(m.id,'CONNECTED '+str(desc));return True
  except Exception as e:m.state='ERROR';m.error=str(e);self.emit(m.id,'CONNECT ERROR '+str(e));logging.error(traceback.format_exc());return False
 def connect_all(self):
  for m in self.models:
   if m.enabled:self.connect_one(m)
 def start(self):
  if self.thread and self.thread.is_alive():return
  self.stop_evt.clear();self.thread=threading.Thread(target=self._loop,name='RoundRobinPatrol',daemon=True);self.thread.start()
 def _loop(self):
  self.emit('SYSTEM','ROUND-ROBIN PATROL STARTED')
  while not self.stop_evt.is_set():
   if self.pause_evt.is_set():time.sleep(.1);continue
   worked=False
   for m in self.models:
    if self.stop_evt.is_set():break
    if not m.enabled or not m.points:continue
    if not m.camera or not m.camera.connected:
     if not self.connect_one(m):time.sleep(.5);continue
    now=time.monotonic()
    if now<m.next_due:continue
    p=m.points[m.step_index%len(m.points)];m.state=f'MOVING {p.name}';self.emit(m.id,f'PATROL step={m.step_index+1} name={p.name} pan={p.pan:.3f} tilt={p.tilt:.3f} zoom={p.zoom:.3f} speed={p.speed:.3f}')
    try:
     m.camera.absolute_move(p.pan,p.tilt,p.zoom,p.speed);time.sleep(.25);m.position=m.camera.status();m.state=f'DWELL {p.dwell:.1f}s';m.step_index=(m.step_index+1)%len(m.points);m.next_due=time.monotonic()+max(.2,p.dwell);worked=True
    except Exception as e:m.state='ERROR';m.error=str(e);m.camera.connected=False;self.emit(m.id,'PATROL ERROR '+str(e));logging.error(traceback.format_exc())
    time.sleep(.05)
   if not worked:time.sleep(.1)
  self.emit('SYSTEM','ROUND-ROBIN PATROL STOPPED')
 def stop(self):
  self.stop_evt.set()
  for m in self.models:
   if m.camera:
    try:m.camera.stop();m.state='STOPPED'
    except Exception as e:self.emit(m.id,'STOP ERROR '+str(e))
 def toggle_pause(self):
  if self.pause_evt.is_set():self.pause_evt.clear();self.emit('SYSTEM','RESUMED')
  else:self.pause_evt.set();self.emit('SYSTEM','PAUSED')
class Radar(ttk.Frame):
 def __init__(self,parent):super().__init__(parent);self.canvas=tk.Canvas(self,width=390,height=390,bg='#071b11',highlightthickness=1,highlightbackground='#375');self.canvas.pack(fill='both',expand=True);self.pos=Position(None,None,None);self.name='No camera';self.after(250,self.draw)
 def set(self,name,pos):self.name=name;self.pos=pos
 def draw(self):
  c=self.canvas;c.delete('all');w=max(c.winfo_width(),100);h=max(c.winfo_height(),100);cx=w/2;cy=h/2;r=min(w,h)*.40
  c.create_oval(cx-r,cy-r,cx+r,cy+r,fill='#063a20',outline='#58ff95',width=2)
  for frac in (.25,.5,.75):c.create_oval(cx-r*frac,cy-r*frac,cx+r*frac,cy+r*frac,outline='#176a3f')
  c.create_line(cx-r,cy,cx+r,cy,fill='#176a3f');c.create_line(cx,cy-r,cx,cy+r,fill='#176a3f')
  for deg,label in [(0,'0°'),(90,'90°'),(180,'180°'),(270,'270°')]:
   a=math.radians(deg);x=cx+math.cos(a)*r*1.10;y=cy-math.sin(a)*r*1.10;c.create_text(x,y,text=label,fill='#b8ffd0')
  pan=self.pos.pan if self.pos.pan is not None else 0.0;tilt=self.pos.tilt if self.pos.tilt is not None else 0.0;zoom=self.pos.zoom if self.pos.zoom is not None else 0.0
  # ONVIF normalized pan -1..1 maps to 180..-180 degrees, with 0 at east, matching the reference radar style.
  angle=-pan*math.pi;length=r*(.75+.20*zoom);ex=cx+math.cos(angle)*length;ey=cy+math.sin(angle)*length
  c.create_line(cx,cy,ex,ey,fill='#8cff4d',width=5,arrow=tk.LAST);c.create_oval(cx-5,cy-5,cx+5,cy+5,fill='#00ff62',outline='')
  c.create_text(cx,18,text=self.name,fill='white',font=('Segoe UI',12,'bold'));c.create_text(cx,h-18,text=f'Pan {pan:+.3f}  Tilt {tilt:+.3f}  Zoom {zoom:.3f}  {self.pos.pan_tilt_status}',fill='#c7ffd5')
  self.after(250,self.draw)
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('PTZ Patrol Controller REAL v1.3.0');self.geometry('1280x800');self.q=queue.Queue();self.models=self.load_config();self.manager=MultiCameraManager(self.models,self.emit);self.selected=None;self._ui();self.after(100,self.tick);self.protocol('WM_DELETE_WINDOW',self.close)
 def default_models(self):return [CameraModel('camera_1','Macro Video IPCamera','192.168.1.102',points=[PatrolPoint('Center',0,0,0,5,.5),PatrolPoint('Left',-.6,0,0,5,.5),PatrolPoint('Right',.6,0,0,5,.5)])]
 def load_config(self):
  if not CONFIG.exists():return self.default_models()
  cp=configparser.ConfigParser();cp.read(CONFIG,encoding='utf-8');out=[]
  for sec in cp.sections():
   if not sec.startswith('CAMERA:'):continue
   cid=sec.split(':',1)[1];m=CameraModel(cid,cp.get(sec,'name',fallback=cid),cp.get(sec,'host'),cp.getint(sec,'onvif_port',fallback=8899),cp.getint(sec,'rtsp_port',fallback=554),cp.getboolean(sec,'enabled',fallback=True))
   for part in cp.get(sec,'points',fallback='').split('|'):
    if not part.strip():continue
    try:n,p,t,z,d,s=[x.strip() for x in part.split(',')];m.points.append(PatrolPoint(n,float(p),float(t),float(z),float(d),float(s)))
    except Exception:pass
   out.append(m)
  return out or self.default_models()
 def save_config(self):
  cp=configparser.ConfigParser()
  for m in self.models:
   sec=f'CAMERA:{m.id}';cp[sec]={'name':m.name,'host':m.host,'onvif_port':str(m.onvif_port),'rtsp_port':str(m.rtsp_port),'enabled':str(m.enabled).lower(),'points':' | '.join(f'{p.name},{p.pan},{p.tilt},{p.zoom},{p.dwell},{p.speed}' for p in m.points)}
  with CONFIG.open('w',encoding='utf-8') as f:cp.write(f)
  self.emit('SYSTEM',f'Saved {CONFIG}')
 def _ui(self):
  style=ttk.Style();style.theme_use('clam');style.configure('Treeview',rowheight=25)
  toolbar=ttk.Frame(self,padding=7);toolbar.pack(fill='x')
  for text,cmd in [('Connect selected',self.connect_selected),('Connect all',lambda:self.bg(self.manager.connect_all)),('Start round-robin patrol',self.manager.start),('Pause/Resume',self.manager.toggle_pause),('EMERGENCY STOP',self.manager.stop),('Save config',self.save_config),('Add camera',self.add_camera),('Remove camera',self.remove_camera)]:ttk.Button(toolbar,text=text,command=cmd).pack(side='left',padx=3)
  main=ttk.Panedwindow(self,orient='horizontal');main.pack(fill='both',expand=True,padx=7,pady=3)
  left=ttk.Frame(main);center=ttk.Frame(main);right=ttk.Frame(main);main.add(left,weight=2);main.add(center,weight=3);main.add(right,weight=3)
  ttk.Label(left,text='Cameras',font=('Segoe UI',12,'bold')).pack(anchor='w');self.camtree=ttk.Treeview(left,columns=('name','host','state'),show='headings',height=10)
  for col,width in [('name',150),('host',120),('state',190)]:self.camtree.heading(col,text=col.title());self.camtree.column(col,width=width)
  self.camtree.pack(fill='both',expand=True);self.camtree.bind('<<TreeviewSelect>>',self.select_camera)
  ttk.Label(center,text='Patrol points',font=('Segoe UI',12,'bold')).pack(anchor='w');self.pointtree=ttk.Treeview(center,columns=('name','pan','tilt','zoom','dwell','speed'),show='headings',height=11)
  for col in ('name','pan','tilt','zoom','dwell','speed'):self.pointtree.heading(col,text=col.title());self.pointtree.column(col,width=78)
  self.pointtree.pack(fill='both',expand=True);edit=ttk.Frame(center);edit.pack(fill='x');self.vars={k:tk.StringVar(value=v) for k,v in [('name','Point'),('pan','0'),('tilt','0'),('zoom','0'),('dwell','5'),('speed','0.5')]}
  for k in self.vars:ttk.Label(edit,text=k).pack(side='left');ttk.Entry(edit,textvariable=self.vars[k],width=7).pack(side='left',padx=2)
  ttk.Button(edit,text='Add',command=self.add_point).pack(side='left');ttk.Button(edit,text='Delete',command=self.remove_point).pack(side='left')
  self.radar=Radar(right);self.radar.pack(fill='both',expand=True)
  manual=ttk.Frame(right);manual.pack(fill='x')
  for text,p,t,z in [('Left',-.15,0,0),('Right',.15,0,0),('Up',0,.15,0),('Down',0,-.15,0),('Zoom +',0,0,.15),('Zoom -',0,0,-.15)]:ttk.Button(manual,text=text,command=lambda p=p,t=t,z=z:self.manual(p,t,z)).pack(side='left',padx=2)
  logframe=ttk.LabelFrame(self,text='Real operation log');logframe.pack(fill='both',padx=7,pady=4);self.log=tk.Text(logframe,height=10,bg='#101517',fg='#d8f3dc');self.log.pack(fill='both',expand=True)
  self.refresh_trees();first=self.camtree.get_children();
  if first:self.camtree.selection_set(first[0]);self.select_camera()
 def emit(self,cid,msg):self.q.put((cid,str(msg)));logging.info('[%s] %s',cid,msg)
 def bg(self,fn):threading.Thread(target=lambda:self.safe(fn),daemon=True).start()
 def safe(self,fn):
  try:fn()
  except Exception as e:self.emit('SYSTEM','ERROR '+str(e));logging.error(traceback.format_exc())
 def refresh_trees(self):
  selected=self.selected.id if self.selected else None
  self.camtree.delete(*self.camtree.get_children())
  for m in self.models:self.camtree.insert('', 'end',iid=m.id,values=(m.name,m.host,m.state))
  if selected and self.camtree.exists(selected):self.camtree.selection_set(selected)
 def select_camera(self,event=None):
  sel=self.camtree.selection();
  if not sel:return
  self.selected=next((m for m in self.models if m.id==sel[0]),None);self.pointtree.delete(*self.pointtree.get_children())
  if self.selected:
   for i,p in enumerate(self.selected.points):self.pointtree.insert('', 'end',iid=str(i),values=(p.name,p.pan,p.tilt,p.zoom,p.dwell,p.speed))
   self.radar.set(self.selected.name,self.selected.position)
 def connect_selected(self):
  if self.selected:self.bg(lambda:self.manager.connect_one(self.selected))
 def manual(self,p,t,z):
  m=self.selected
  if not m or not m.camera:return messagebox.showerror('Not connected','Connect selected camera first')
  self.bg(lambda:(m.camera.continuous_move(p,t,z,.20),setattr(m,'position',m.camera.status()),self.emit(m.id,'Manual move and status complete')))
 def add_point(self):
  if not self.selected:return
  try:self.selected.points.append(PatrolPoint(self.vars['name'].get(),float(self.vars['pan'].get()),float(self.vars['tilt'].get()),float(self.vars['zoom'].get()),float(self.vars['dwell'].get()),float(self.vars['speed'].get())));self.select_camera()
  except Exception as e:messagebox.showerror('Invalid point',str(e))
 def remove_point(self):
  if not self.selected:return
  ids=sorted([int(x) for x in self.pointtree.selection()],reverse=True)
  for i in ids:
   if 0<=i<len(self.selected.points):self.selected.points.pop(i)
  self.select_camera()
 def add_camera(self):
  n=1
  while any(m.id==f'camera_{n}' for m in self.models):n+=1
  self.models.append(CameraModel(f'camera_{n}',f'Camera {n}','192.168.1.100',points=[PatrolPoint('Center',0,0,0)]));self.refresh_trees()
 def remove_camera(self):
  if not self.selected:return
  if messagebox.askyesno('Remove camera',f'Remove {self.selected.name}?'):
   self.models.remove(self.selected);self.selected=None;self.refresh_trees()
 def tick(self):
  while not self.q.empty():cid,msg=self.q.get();self.log.insert('end',f'[{time.strftime("%H:%M:%S")}] [{cid}] {msg}\n');self.log.see('end')
  self.refresh_trees()
  if self.selected:self.radar.set(self.selected.name,self.selected.position)
  self.after(500,self.tick)
 def close(self):self.manager.stop();self.save_config();self.destroy()
if __name__=='__main__':App().mainloop()
