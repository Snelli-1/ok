PTZ Patrol Controller REAL v1.3.0
=================================
Real ONVIF only. No simulation backend and no invented camera state.

New in v1.3.0
- Multiple cameras stored in config_REAL_v1_3_0.ini.
- Round-robin patrol scheduler switches between enabled cameras continuously.
- Per-camera persistent absolute patrol points with pan, tilt, zoom, dwell and speed.
- Radar-style orientation display for the selected camera.
- Radar uses the camera's real GetStatus pan/tilt/zoom values.
- Connect selected, Connect all, Pause/Resume, and global Emergency Stop.
- Manual bounded ContinuousMove controls followed by guaranteed Stop.
- Automatic reconnect after a real network/SOAP error.
- Separate real-operation log in logs_real/application_real_v1_3_0.log.

Run
1. Keep PTZ_Patrol_Controller_REAL_v1_3_0.py and real_onvif_camera_v1_3_0.py together.
2. Rename RUN_REAL_v1_3_0.bat.txt to RUN_REAL_v1_3_0.bat, or run:
   py -3 PTZ_Patrol_Controller_REAL_v1_3_0.py
3. Connect the existing camera.
4. Verify Status and one short manual movement.
5. Start round-robin patrol.

Adding cameras
Click Add camera, update its IP in config_REAL_v1_3_0.ini, restart, then Connect all.
Each camera can have a different number of points. The scheduler gives each due camera
one real movement command, then advances to the next camera, so one slow dwell does not
block all other cameras.

Radar interpretation
- The bright green line is the horizontal centerline of the camera view.
- Pan -1.0..+1.0 is mapped around the full circle.
- Tilt and zoom are shown numerically below the radar.
- The radar is not video and does not claim field-of-view width.
- If physical left/right is reversed, reverse the sign of configured pan points.

Safety
Emergency Stop sends a real Stop request to every connected camera. Keep the button
accessible during first testing. Begin with speed 0.5 or lower.
