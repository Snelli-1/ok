#!/usr/bin/env python3
"""Real ONVIF SOAP 1.2 backend for PTZ Patrol Controller v1.3.0.
Standard-library only. No simulated camera, generated capability, or silent fallback.
"""
from __future__ import annotations
import http.client, time, urllib.parse, xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

SOAP="http://www.w3.org/2003/05/soap-envelope"
TDS="http://www.onvif.org/ver10/device/wsdl"
TRT="http://www.onvif.org/ver10/media/wsdl"
TPTZ="http://www.onvif.org/ver20/ptz/wsdl"
TT="http://www.onvif.org/ver10/schema"

def _esc(s): return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def _local(tag): return tag.rsplit('}',1)[-1]
def _env(body): return f'''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'''
def _texts(root,name): return [(e.text or '').strip() for e in root.iter() if _local(e.tag)==name and (e.text or '').strip()]
def _tokens(root,names):
    out=[]
    for e in root.iter():
        if _local(e.tag) in names:
            token=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
            if token and token not in out: out.append(token)
    return out

@dataclass
class Position:
    pan: Optional[float]
    tilt: Optional[float]
    zoom: Optional[float]
    pan_tilt_status: str=''
    zoom_status: str=''
    timestamp: float=0.0

class OnvifError(RuntimeError): pass

class RealOnvifCamera:
    def __init__(self,host:str,port:int=8899,rtsp_port:int=554,timeout:float=5.0,logger:Optional[Callable[[str],None]]=None):
        self.host=host; self.port=int(port); self.rtsp_port=int(rtsp_port); self.timeout=float(timeout); self.logger=logger
        self.device=f'http://{host}:{port}/onvif/device_service'
        self.media=f'http://{host}:{port}/onvif/media_service'
        self.ptz=f'http://{host}:{port}/onvif/ptz_service'
        self.profiles:List[str]=[]; self.ptz_configs:List[str]=[]; self.presets:Dict[str,str]={}
        self.connected=False; self.last_position=Position(None,None,None,timestamp=time.time())
    def _log(self,msg):
        if self.logger: self.logger(msg)
    def _call(self,url,operation,body):
        xml=_env(body); u=urllib.parse.urlparse(url); conn=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=self.timeout); started=time.monotonic()
        try:
            conn.request('POST',u.path or '/',xml.encode('utf-8'),{'Content-Type':'application/soap+xml; charset=utf-8','Connection':'close','User-Agent':'PTZ-Patrol-REAL/1.3.0'})
            response=conn.getresponse(); text=response.read(2*1024*1024).decode('utf-8',errors='replace')
        except Exception as exc:
            self._log(f'{operation} NETWORK ERROR {type(exc).__name__}: {exc}'); self.connected=False; raise OnvifError(f'{operation}: {exc}') from exc
        finally: conn.close()
        elapsed=int((time.monotonic()-started)*1000); self._log(f'{operation} HTTP {response.status} {elapsed} ms')
        try: root=ET.fromstring(text)
        except Exception as exc: raise OnvifError(f'{operation}: non-XML HTTP {response.status}: {exc}') from exc
        for element in root.iter():
            if _local(element.tag)=='Fault':
                detail=' | '.join(_texts(root,'Text')+_texts(root,'Value')) or 'unspecified SOAP fault'
                raise OnvifError(f'{operation}: SOAP Fault: {detail}')
        if response.status>=400: raise OnvifError(f'{operation}: HTTP {response.status}')
        return root
    def connect(self):
        self._call(self.device,'GetSystemDateAndTime','<tds:GetSystemDateAndTime/>')
        caps=self._call(self.device,'GetCapabilities','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>')
        xaddrs=_texts(caps,'XAddr')
        self.media=next((x for x in xaddrs if 'media' in x.lower() and 'media2' not in x.lower()),self.media)
        self.ptz=next((x for x in xaddrs if 'ptz' in x.lower()),self.ptz)
        profiles=self._call(self.media,'GetProfiles','<trt:GetProfiles/>')
        self.profiles=_tokens(profiles,{'Profiles','Profile'}); self.ptz_configs=_tokens(profiles,{'PTZConfiguration'})
        if not self.profiles: raise OnvifError('camera returned no real media ProfileToken')
        self.connected=True; self.refresh_presets(); self.status()
        return self.describe()
    def describe(self):
        return {'host':self.host,'onvif_port':self.port,'rtsp_port':self.rtsp_port,'device_xaddr':self.device,'media_xaddr':self.media,'ptz_xaddr':self.ptz,'profiles':list(self.profiles),'ptz_configurations':list(self.ptz_configs),'presets':dict(self.presets)}
    def profile(self):
        if not self.profiles: self.connect()
        return self.profiles[0]
    def status(self):
        root=self._call(self.ptz,'GetStatus',f'<tptz:GetStatus><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken></tptz:GetStatus>')
        pan=tilt=zoom=None; pt_state=zoom_state=''
        for e in root.iter():
            name=_local(e.tag)
            if name=='PanTilt' and 'x' in e.attrib: pan=float(e.attrib['x']); tilt=float(e.attrib.get('y',0.0))
            elif name=='Zoom' and 'x' in e.attrib: zoom=float(e.attrib['x'])
            elif name=='MoveStatus':
                for child in e:
                    if _local(child.tag)=='PanTilt': pt_state=(child.text or '').strip()
                    elif _local(child.tag)=='Zoom': zoom_state=(child.text or '').strip()
        self.last_position=Position(pan,tilt,zoom,pt_state,zoom_state,time.time()); return self.last_position
    def refresh_presets(self):
        if not self.profiles: return {}
        root=self._call(self.ptz,'GetPresets',f'<tptz:GetPresets><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken></tptz:GetPresets>'); result={}
        for e in root.iter():
            if _local(e.tag)=='Preset':
                token=e.attrib.get('token',''); name=next(((c.text or '').strip() for c in e if _local(c.tag)=='Name'),token)
                if token: result[name or token]=token
        self.presets=result; return dict(result)
    def stop(self):
        self._call(self.ptz,'Stop',f'<tptz:Stop><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>')
    def goto_preset(self,token):
        self._call(self.ptz,'GotoPreset',f'<tptz:GotoPreset><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken><tptz:PresetToken>{_esc(token)}</tptz:PresetToken></tptz:GotoPreset>')
    def absolute_move(self,pan,tilt,zoom=0.0,speed=0.5):
        pan=max(-1.0,min(1.0,float(pan))); tilt=max(-1.0,min(1.0,float(tilt))); zoom=max(0.0,min(1.0,float(zoom))); speed=max(0.01,min(1.0,float(speed)))
        body=f'<tptz:AbsoluteMove><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken><tptz:Position><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Position><tptz:Speed><tt:PanTilt x="{speed}" y="{speed}"/><tt:Zoom x="{speed}"/></tptz:Speed></tptz:AbsoluteMove>'
        self._call(self.ptz,'AbsoluteMove',body)
    def continuous_move(self,pan,tilt,zoom=0.0,duration=0.20):
        pan=max(-1.0,min(1.0,float(pan))); tilt=max(-1.0,min(1.0,float(tilt))); zoom=max(-1.0,min(1.0,float(zoom))); duration=max(0.05,min(2.0,float(duration)))
        body=f'<tptz:ContinuousMove><tptz:ProfileToken>{_esc(self.profile())}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Velocity></tptz:ContinuousMove>'
        try: self._call(self.ptz,'ContinuousMove',body); time.sleep(duration)
        finally: self.stop()
