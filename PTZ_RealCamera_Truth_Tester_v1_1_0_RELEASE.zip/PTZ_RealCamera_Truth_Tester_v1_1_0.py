#!/usr/bin/env python3
"""PTZ Real Camera Truth Tester v1.1.0.
Standalone, real-device-only, no-auth-first ONVIF/PTZ diagnostic for authorized private-LAN devices.
Logs every request, response, token, endpoint, decision and elapsed time chronologically.
"""
from __future__ import annotations
import argparse, base64, hashlib, http.client, ipaddress, json, os, re, secrets, socket, sys, time, traceback, urllib.parse
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET

VERSION="1.1.0"
SOAP="http://www.w3.org/2003/05/soap-envelope"
WSA="http://www.w3.org/2005/08/addressing"
TDS="http://www.onvif.org/ver10/device/wsdl"
TRT="http://www.onvif.org/ver10/media/wsdl"
TR2="http://www.onvif.org/ver20/media/wsdl"
TPTZ="http://www.onvif.org/ver20/ptz/wsdl"
TT="http://www.onvif.org/ver10/schema"
WSSE="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
WSU="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
NS={"s":SOAP,"tds":TDS,"trt":TRT,"tr2":TR2,"tptz":TPTZ,"tt":TT}
for p,u in NS.items(): ET.register_namespace(p,u)

@dataclass
class Record:
    seq:int; utc:str; phase:str; operation:str; endpoint:str; mode:str; status:str; code:str; elapsed_ms:int; request_xml:str; response_status:str; response_headers:Dict[str,str]; response_xml:str; interpretation:str

class Chronicle:
    def __init__(self,host:str,out:Path):
        out.mkdir(parents=True,exist_ok=True); stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); safe=re.sub(r"[^A-Za-z0-9_.-]","_",host)
        self.txt=out/f"REAL_CAMERA_ALL_IN_ONE_{safe}_{stamp}.txt"; self.jsonl=out/f"REAL_CAMERA_EVENTS_{safe}_{stamp}.jsonl"; self.seq=0
        self.txt.write_text(f"""PTZ REAL CAMERA TRUTH TESTER v{VERSION}\nTarget: {host}\nUTC start: {datetime.now(timezone.utc).isoformat()}\n\nGUARANTEES\n- This file contains only responses received from the configured physical endpoint.\n- PASS means bytes were actually received from the configured target endpoint.\n- SOAP_OK means an ONVIF response body was parsed. SOAP_FAULT means the camera returned a SOAP fault.\n- NO_AUTH is always attempted first. WSSE is attempted only after an authorization result and only when credentials exist.\n- No camera configuration is changed. No preset is created or deleted. Motion is locked unless --arm-motion is given.\n- Requests and responses are recorded in exact chronological order. Secrets are redacted.\n\n""",encoding="utf-8")
    def section(self,name):
        with self.txt.open("a",encoding="utf-8") as f:f.write(f"\n{'='*90}\n{name}\n{'='*90}\n")
        print(f"\n=== {name} ===")
    def add(self,phase,op,endpoint,mode,status,code,elapsed,req="",http_status="",headers=None,resp="",why=""):
        self.seq+=1; r=Record(self.seq,datetime.now(timezone.utc).isoformat(),phase,op,endpoint,mode,status,code,int(elapsed*1000),redact(req),str(http_status),redact_obj(headers or {}),redact(resp),redact(why))
        line=f"[{r.seq:03d}] {phase:<15} {op:<28} {mode:<8} {status:<11} {code:<6} {r.elapsed_ms:>6} ms | {r.endpoint} | {r.interpretation}"
        print(line)
        with self.txt.open("a",encoding="utf-8") as f:
            f.write(line+"\n")
            if r.request_xml:f.write("REQUEST XML:\n"+r.request_xml+"\n")
            if r.response_status:f.write("HTTP STATUS: "+r.response_status+"\n")
            if r.response_headers:f.write("RESPONSE HEADERS:\n"+json.dumps(r.response_headers,indent=2,ensure_ascii=False)+"\n")
            if r.response_xml:f.write("RESPONSE XML/BODY:\n"+r.response_xml+"\n")
        with self.jsonl.open("a",encoding="utf-8") as f:f.write(json.dumps(asdict(r),ensure_ascii=False)+"\n")
    def conclude(self,data):
        self.section("FINAL MACHINE SETUP RECOMMENDATION")
        safe=redact_obj(data)
        with self.txt.open("a",encoding="utf-8") as f:f.write(json.dumps(safe,indent=2,ensure_ascii=False)+"\n")
        print(json.dumps(safe,indent=2,ensure_ascii=False));print(f"\nRETURN THIS FILE:\n{self.txt}")

def redact(s:Any)->str:
    s=str(s or "")
    s=re.sub(r"(?s)(<wsse:Password[^>]*>).*?(</wsse:Password>)",r"\1<REDACTED>\2",s)
    s=re.sub(r"(?s)(<wsse:Nonce[^>]*>).*?(</wsse:Nonce>)",r"\1<REDACTED>\2",s)
    s=re.sub(r"(?i)(password|authorization)(\s*[:=]\s*)\S+",r"\1\2<REDACTED>",s)
    s=re.sub(r"(rtsp://[^:/\s]+:)[^@\s]+@",r"\1<REDACTED>@",s)
    return s[:200000]
def redact_obj(v):
    if isinstance(v,dict):return {str(k):("<REDACTED>" if str(k).lower() in {"password","authorization","nonce","passworddigest"} else redact_obj(x)) for k,x in v.items()}
    if isinstance(v,list):return [redact_obj(x) for x in v]
    return redact(v) if isinstance(v,str) else v

def wsse_header(user:str,password:str)->str:
    nonce=secrets.token_bytes(16); created=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    digest=base64.b64encode(hashlib.sha1(nonce+created.encode()+password.encode()).digest()).decode()
    return f'''<s:Header><wsse:Security s:mustUnderstand="1" xmlns:wsse="{WSSE}" xmlns:wsu="{WSU}"><wsse:UsernameToken><wsse:Username>{xml_escape(user)}</wsse:Username><wsse:Password Type="{WSSE}#PasswordDigest">{digest}</wsse:Password><wsse:Nonce EncodingType="{WSSE}#Base64Binary">{base64.b64encode(nonce).decode()}</wsse:Nonce><wsu:Created>{created}</wsu:Created></wsse:UsernameToken></wsse:Security></s:Header>'''
def xml_escape(s):return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")
def envelope(body:str,header="")->str:return f'''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tr2="{TR2}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}" xmlns:wsse="{WSSE}" xmlns:wsu="{WSU}">{header}<s:Body>{body}</s:Body></s:Envelope>'''

def post_xml(url,xml,timeout):
    u=urllib.parse.urlparse(url); cls=http.client.HTTPSConnection if u.scheme=="https" else http.client.HTTPConnection
    c=cls(u.hostname,u.port or (443 if u.scheme=="https" else 80),timeout=timeout)
    path=(u.path or "/")+(f"?{u.query}" if u.query else "")
    try:
        c.request("POST",path,xml.encode(),{"Content-Type":"application/soap+xml; charset=utf-8","User-Agent":f"PTZ-Truth/{VERSION}","Connection":"close"});r=c.getresponse();b=r.read(1024*1024)
        return r.status,r.reason,dict(r.getheaders()),b.decode("utf-8",errors="replace")
    finally:c.close()
def localname(tag):return tag.rsplit("}",1)[-1]
def parse_xml(text):return ET.fromstring(text)
def fault_text(root):
    vals=[]
    for e in root.iter():
        if localname(e.tag) in {"Value","Text","Subcode","Reason"} and (e.text or "").strip():vals.append((e.text or "").strip())
    return " | ".join(vals)
def is_fault(root):return any(localname(e.tag)=="Fault" for e in root.iter())
def texts(root,name):return [(e.text or "").strip() for e in root.iter() if localname(e.tag)==name and (e.text or "").strip()]
def attrs(root,name,attr="token"):
    return [e.attrib.get(attr) or e.attrib.get(f"{{{TT}}}{attr}") for e in root.iter() if localname(e.tag)==name and (e.attrib.get(attr) or e.attrib.get(f"{{{TT}}}{attr}"))]
def xaddrs(root):
    out={}
    for e in root.iter():
        if localname(e.tag)=="XAddr" and (e.text or "").strip():
            parent="unknown"; out.setdefault(parent,[]).append((e.text or "").strip())
    return out

def authorized_fault(status,root,text):
    t=(fault_text(root) if root is not None else text).lower()
    return status in (401,403) or any(x in t for x in ["notauthorized","unauthorized","ter:notauthorized","wsse:failedauthentication"])

def soap_call(log,phase,op,url,body,user,password,timeout,allow_auth=True):
    modes=[("NO_AUTH","")]
    results=[]
    for mode,hdr in modes:
        xml=envelope(body,hdr);st=time.monotonic()
        try:
            hs,reason,headers,text=post_xml(url,xml,timeout);root=None
            try:root=parse_xml(text)
            except Exception:pass
            if root is not None and is_fault(root):status="SOAP_FAULT";code="R201" if authorized_fault(hs,root,text) else "R202";why=fault_text(root) or "SOAP fault"
            elif root is not None:status="SOAP_OK";code="R000";why="XML parsed from real camera"
            else:status="HTTP_ONLY";code="R203";why="HTTP response was not parseable SOAP XML"
            log.add(phase,op,url,mode,status,code,time.monotonic()-st,xml,f"{hs} {reason}",headers,text,why);results.append((mode,status,hs,root,text))
            if status=="SOAP_OK":return results[-1]
            if authorized_fault(hs,root,text) and allow_auth and user:
                mode="WSSE";xml=envelope(body,wsse_header(user,password));st=time.monotonic()
                try:
                    hs,reason,headers,text=post_xml(url,xml,timeout);root=parse_xml(text)
                    status="SOAP_FAULT" if is_fault(root) else "SOAP_OK";code="R201" if authorized_fault(hs,root,text) else "R202" if status=="SOAP_FAULT" else "R000";why=fault_text(root) if status=="SOAP_FAULT" else "WS-Security response parsed"
                    log.add(phase,op,url,mode,status,code,time.monotonic()-st,xml,f"{hs} {reason}",headers,text,why);return mode,status,hs,root,text
                except Exception as e:log.add(phase,op,url,mode,"NETWORK_FAIL","R102",time.monotonic()-st,xml,"",{},"",f"{type(e).__name__}: {e}")
            return results[-1]
        except socket.timeout as e:log.add(phase,op,url,mode,"TIMEOUT","R101",time.monotonic()-st,xml,"",{},"",str(e))
        except Exception as e:log.add(phase,op,url,mode,"NETWORK_FAIL","R102",time.monotonic()-st,xml,"",{},"",f"{type(e).__name__}: {e}")
    return ("NO_AUTH","FAIL",0,None,"")

def first_url(values,contains,fallback):
    for v in values:
        if contains.lower() in v.lower():return v
    return fallback

def main():
    ap=argparse.ArgumentParser(description="Real-device-only no-auth-first ONVIF/PTZ truth tester")
    ap.add_argument("--host",default="192.168.1.102");ap.add_argument("--port",type=int,default=8899);ap.add_argument("--username",default="");ap.add_argument("--password",default="")
    ap.add_argument("--timeout",type=float,default=5.0);ap.add_argument("--output",default="real_camera_truth_logs");ap.add_argument("--arm-motion",action="store_true")
    ap.add_argument("--version",action="version",version=VERSION);a=ap.parse_args()
    if not ipaddress.ip_address(a.host).is_private:raise SystemExit("Private-LAN targets only")
    device=f"http://{a.host}:{a.port}/onvif/device_service";log=Chronicle(a.host,Path(a.output));discovered=[];profiles=[];ptz_configs=[];presets=[];position=False;movement_verified=False
    log.section("00 NETWORK FACTS")
    st=time.monotonic()
    try:
        with socket.create_connection((a.host,a.port),a.timeout) as s:log.add("network","TCP_CONNECT",f"{a.host}:{a.port}","REAL","PASS","R000",time.monotonic()-st,"",str(s.getpeername()),{},"","TCP connection established")
    except Exception as e:log.add("network","TCP_CONNECT",f"{a.host}:{a.port}","REAL","FAIL","R102",time.monotonic()-st,"","",{},"",str(e));log.conclude({"result":"NETWORK_FAILED"});return 2

    log.section("01 DEVICE SERVICE, NO-AUTH FIRST")
    calls=[
      ("GetSystemDateAndTime",f"<tds:GetSystemDateAndTime/>"),
      ("GetDeviceInformation",f"<tds:GetDeviceInformation/>"),
      ("GetCapabilities",f"<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>"),
      ("GetServices",f"<tds:GetServices><tds:IncludeCapability>true</tds:IncludeCapability></tds:GetServices>"),
      ("GetScopes",f"<tds:GetScopes/>"),
      ("GetNetworkInterfaces",f"<tds:GetNetworkInterfaces/>"),
    ]
    roots={}
    for op,body in calls:
        res=soap_call(log,"device",op,device,body,a.username,a.password,a.timeout);roots[op]=res[3]
        if res[3] is not None:discovered+=texts(res[3],"XAddr")
        time.sleep(.35)
    media_url=first_url(discovered,"media",f"http://{a.host}:{a.port}/onvif/media_service")
    ptz_url=first_url(discovered,"ptz",f"http://{a.host}:{a.port}/onvif/ptz_service")

    log.section("02 MEDIA SERVICE AND REAL TOKENS")
    mode,status,hs,root,text=soap_call(log,"media","GetProfiles",media_url,"<trt:GetProfiles/>",a.username,a.password,a.timeout)
    if root is not None and status=="SOAP_OK":
        profiles=attrs(root,"Profiles")
        if not profiles:profiles=attrs(root,"Profile")
        ptz_configs=attrs(root,"PTZConfiguration")
    for token in profiles:
        body=f'''<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup><trt:ProfileToken>{xml_escape(token)}</trt:ProfileToken></trt:GetStreamUri>'''
        soap_call(log,"media","GetStreamUri",media_url,body,a.username,a.password,a.timeout)
        soap_call(log,"media","GetSnapshotUri",media_url,f"<trt:GetSnapshotUri><trt:ProfileToken>{xml_escape(token)}</trt:ProfileToken></trt:GetSnapshotUri>",a.username,a.password,a.timeout)
        time.sleep(.25)

    log.section("03 PTZ CAPABILITY, POSITION AND PRESETS")
    soap_call(log,"ptz","GetNodes",ptz_url,"<tptz:GetNodes/>",a.username,a.password,a.timeout)
    soap_call(log,"ptz","GetConfigurations",ptz_url,"<tptz:GetConfigurations/>",a.username,a.password,a.timeout)
    for cfg in ptz_configs:
        soap_call(log,"ptz","GetConfigurationOptions",ptz_url,f"<tptz:GetConfigurationOptions><tptz:ConfigurationToken>{xml_escape(cfg)}</tptz:ConfigurationToken></tptz:GetConfigurationOptions>",a.username,a.password,a.timeout)
    for token in profiles:
        res=soap_call(log,"ptz","GetStatus",ptz_url,f"<tptz:GetStatus><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken></tptz:GetStatus>",a.username,a.password,a.timeout)
        if res[3] is not None and res[1]=="SOAP_OK":position=any(localname(e.tag)=="Position" for e in res[3].iter())
        res=soap_call(log,"ptz","GetPresets",ptz_url,f"<tptz:GetPresets><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken></tptz:GetPresets>",a.username,a.password,a.timeout)
        if res[3] is not None and res[1]=="SOAP_OK":presets+=attrs(res[3],"Preset")

    log.section("04 OPTIONAL SAFE REAL MOVEMENT")
    if not a.arm_motion:
        log.add("motion","ALL_MOVEMENT",ptz_url,"LOCKED","SKIP","R401",0,"","",{},"","Use --arm-motion only after reviewing this read-only log")
    elif not profiles:
        log.add("motion","ALL_MOVEMENT",ptz_url,"REAL","SKIP","R402",0,"","",{},"","No real ProfileToken was returned")
    else:
        token=profiles[0]
        soap_call(log,"motion","Stop_before",ptz_url,f"<tptz:Stop><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>",a.username,a.password,a.timeout)
        if presets:
            res=soap_call(log,"motion","GotoPreset_existing",ptz_url,f"<tptz:GotoPreset><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken><tptz:PresetToken>{xml_escape(presets[0])}</tptz:PresetToken></tptz:GotoPreset>",a.username,a.password,a.timeout);movement_verified=res[1]=="SOAP_OK"
        else:
            body=f'''<tptz:ContinuousMove><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="0.08" y="0.0"/><tt:Zoom x="0.0"/></tptz:Velocity><tptz:Timeout>PT0.20S</tptz:Timeout></tptz:ContinuousMove>'''
            res=soap_call(log,"motion","ContinuousMove_0.08",ptz_url,body,a.username,a.password,a.timeout);time.sleep(.20)
            soap_call(log,"motion","Stop_after",ptz_url,f"<tptz:Stop><tptz:ProfileToken>{xml_escape(token)}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>",a.username,a.password,a.timeout);movement_verified=res[1]=="SOAP_OK"

    recommendation="NO_USABLE_PROFILE"
    if profiles and presets:recommendation="PRESET_ONLY_FIRST"
    elif profiles and position:recommendation="ONVIF_PTZ_WITH_CAMERA_POSITION"
    elif profiles:recommendation="ONVIF_PTZ_WITH_SOFTWARE_POSITION_ESTIMATION"
    result={"version":VERSION,"real_device_only":True,"camera":{"host":a.host,"device_url":device,"media_url":media_url,"ptz_url":ptz_url},"real_profile_tokens":profiles,"real_ptz_configuration_tokens":ptz_configs,"real_preset_tokens":presets,"camera_reports_position":position,"movement_command_accepted":movement_verified,"recommended_controller_mode":recommendation,"next_controller_config":{"host":a.host,"onvif_port":a.port,"rtsp_port":554,"adapter":"onvif_real_only","simulation_disabled":True,"dry_run":True,"movement_mode":"preset_only" if presets else "bounded_continuous","position_source":"camera" if position else "software_estimate"}}
    log.conclude(result);return 0
if __name__=="__main__":raise SystemExit(main())
