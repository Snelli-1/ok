PTZ REAL CAMERA TRUTH TESTER v1.1.0
===================================

WHAT THIS VERSION FIXES
- No import of the patrol controller.
- No MockCameraBridge, mock profiles, simulated capabilities or fake positions.
- No ONVIF Python package is required.
- Sends raw SOAP directly to 192.168.1.102:8899.
- Tries every read-only operation without authentication first.
- Uses WS-Security PasswordDigest only after a real authorization fault and only if
  --username and --password were supplied.
- Saves every request and response in strict chronological order.

FIRST RUN, NO AUTHENTICATION
py -3 PTZ_RealCamera_Truth_Tester_v1_1_0.py --host 192.168.1.102 --port 8899

IF THE LOG SHOWS NotAuthorized
py -3 PTZ_RealCamera_Truth_Tester_v1_1_0.py --host 192.168.1.102 --port 8899 --username admin --password "YOUR_PASSWORD"

DO NOT ARM MOTION YET.
Return:
real_camera_truth_logs\REAL_CAMERA_ALL_IN_ONE_192.168.1.102_*.txt

READ-ONLY SEQUENCE
1 TCP connection
2 GetSystemDateAndTime
3 GetDeviceInformation
4 GetCapabilities
5 GetServices
6 GetScopes
7 GetNetworkInterfaces
8 dynamic Media XAddr selection
9 GetProfiles and extraction of real ProfileToken/PTZConfigurationToken values
10 GetStreamUri and GetSnapshotUri for each real profile
11 dynamic PTZ XAddr selection
12 GetNodes
13 GetConfigurations
14 GetConfigurationOptions
15 GetStatus for every profile
16 GetPresets for every profile
17 final controller configuration recommendation

MOVEMENT
--arm-motion remains locked by default. If later enabled, the tester uses an existing
camera-returned preset first. It never invents token 1, MAIN, Profile_1 or any other token.
If no preset exists, it uses one 0.20 s bounded ContinuousMove and sends Stop.

NEXT PRODUCTION RUN: REMOVE ALL MOCKS
Use the included fail-closed audit:
py -3 REMOVE_ALL_MOCKS_NEXT_RUN_v1_2_0.py PTZ_Patrol_Controller_v1_2_0.py --config config.txt
The production release must not ship unless this command returns PASS. The replacement
controller should have only real ONVIF and explicit unavailable/error states. Unknown
capabilities remain UNKNOWN, never simulated true/false values.
