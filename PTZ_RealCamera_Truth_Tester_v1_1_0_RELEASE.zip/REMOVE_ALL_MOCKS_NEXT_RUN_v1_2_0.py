#!/usr/bin/env python3
"""Fail-closed mock audit for the next PTZ Patrol Controller build.
This does not silently rewrite logic. It creates an exact removal report and exits nonzero
until every mock/simulation path has been removed from the production source/config.
"""
import argparse,re,sys,json
from pathlib import Path
PATTERNS=[
 r'\bMockCameraBridge\b',r'\bMockProfile\b',r'\bmock_mode\b',r'AdapterMode\.MOCK',
 r'\bmock_test\b',r'--mock-test',r'--discovery-mock-test',r'\bsimulated\b',r'\bmock:',
 r'intermittent_mock',r'limited_mock',r'full_mock'
]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--config');a=ap.parse_args()
 findings=[]
 for fn in [a.source,a.config]:
  if not fn:continue
  p=Path(fn);text=p.read_text(encoding='utf-8',errors='replace')
  for n,line in enumerate(text.splitlines(),1):
   hits=[pat for pat in PATTERNS if re.search(pat,line,re.I)]
   if hits:findings.append({'file':str(p),'line':n,'patterns':hits,'text':line[:500]})
 out=Path('MOCK_REMOVAL_AUDIT.json');out.write_text(json.dumps({'pass':not findings,'findings':findings},indent=2),encoding='utf-8')
 if findings:
  print(f'FAIL: {len(findings)} mock/simulation references remain. See {out}')
  return 1
 print('PASS: no known mock/simulation references remain in production files.')
 return 0
if __name__=='__main__':raise SystemExit(main())
