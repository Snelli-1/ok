@echo off
cd /d "%~dp0"
py -3 PTZ_Patrol_Controller_REAL_v1_4_3.py
pause
