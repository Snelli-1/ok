#!/usr/bin/env python3
"""Thread-safe bounded pulse engine. The only module allowed to issue PTZ motion."""
from __future__ import annotations
import threading,time
class BoundedPulseEngine:
 def __init__(self,cam,emit=lambda *a:None,pulse_duration=.20,pulse_gap=.04):
  self.cam=cam;self.emit=emit;self.pulse_duration=pulse_duration;self.pulse_gap=pulse_gap;self.lock=threading.RLock();self.cancel=threading.Event();self.thread=None;self.generation=0;self.owner='NONE';self.in_flight=False;self.hold_active=False;self.pulses=0;self.last_confirmed=0.;self.exit_reason='idle';self.target_step=None;self.hard_blocked=False
 def alive(self):return bool(self.thread and self.thread.is_alive())
 def _log(self,msg):self.emit(self.cam.id,msg)
 def cancel_motion(self,reason='cancel',join=True,stop=True):
  with self.lock:self.generation+=1;self.cancel.set();t=self.thread;self.exit_reason=reason
  if stop and self.cam.api:
   try:self.cam.api.stop();self._log(f'Stop result OK reason={reason}')
   except Exception as e:self.cam.confidence='UNSYNCED';self._log(f'Stop result ERROR {e}')
  if join and t and t is not threading.current_thread():t.join(timeout=2)
  with self.lock:
   if not self.alive():self.thread=None;self.owner='NONE';self.hold_active=False;self.in_flight=False
 def _reserve(self,direction,generation):
  with self.lock:
   if generation!=self.generation or self.cancel.is_set():return None
   current=self.cam.pan_step
   if direction<0 and current<=-self.cam.left_limit:self.hard_blocked=True;self.cam.state='HARD_BOUND';self._log(f'HARD_BOUND_BLOCKED LEFT step={current} limit={-self.cam.left_limit}');return None
   if direction>0 and current>=self.cam.right_limit:self.hard_blocked=True;self.cam.state='HARD_BOUND';self._log(f'HARD_BOUND_BLOCKED RIGHT step={current} limit={self.cam.right_limit}');return None
   return max(-self.cam.left_limit,min(self.cam.right_limit,current+direction))
 def pulse(self,direction=0,tilt=0,zoom=0,generation=None):
  generation=self.generation if generation is None else generation;reserved=self._reserve(direction,generation) if direction else self.cam.pan_step
  if reserved is None:
   try:self.cam.api.stop()
   except Exception:pass
   return False
  with self.lock:
   if generation!=self.generation or self.cancel.is_set():return False
   self.in_flight=True
  pan=.15*(1 if direction>0 else -1 if direction<0 else 0);ok_move=False;ok_stop=False
  try:
   self._log(f'physical request start gen={generation} owner={self.owner} dir={direction}')
   self.cam.api.continuous_move(pan,.15*tilt,.15*zoom);ok_move=True;self._log('ContinuousMove result OK')
   end=time.monotonic()+self.pulse_duration
   while time.monotonic()<end:
    if self.cancel.wait(min(.02,max(0,end-time.monotonic()))):break
  except Exception as e:self._log(f'ContinuousMove result ERROR {e}')
  finally:
   try:self.cam.api.stop();ok_stop=True;self._log('Stop result OK')
   except Exception as e:self._log(f'Stop result ERROR {e}')
   with self.lock:self.in_flight=False
  if not (ok_move and ok_stop):
   self.cam.confidence='UNSYNCED';self.cancel.set();self.exit_reason='physical failure';return False
  with self.lock:
   if generation!=self.generation:return False
   if direction:self.cam.pan_step=reserved;self.cam.heading_deg=reserved*(360/52)
   self.cam.tilt_step=max(-self.cam.tilt_down_limit,min(self.cam.tilt_up_limit,self.cam.tilt_step+tilt));self.pulses+=1;self.last_confirmed=time.time();self.hard_blocked=False
  self._log(f'committed step={self.cam.pan_step} pulse={self.pulses}');return True
 def start_hold(self,direction=0,tilt=0,zoom=0,owner='MOUSE'):
  self.cancel_motion('new session',join=True,stop=True)
  with self.lock:self.generation+=1;g=self.generation;self.cancel=threading.Event();self.owner=owner;self.hold_active=True;self.pulses=0;self.exit_reason='running';self.cam.manual_override=True;self.cam.motion_owner=owner;self.cam.state='MANUAL_OVERRIDE'
  def run():
   self._log(f'motion session start gen={g} owner={owner}')
   reason='released'
   while not self.cancel.is_set() and g==self.generation:
    if not self.pulse(direction,tilt,zoom,g):reason='bound/error';break
    if self.cancel.wait(self.pulse_gap):break
   with self.lock:self.hold_active=False;self.cam.manual_override=False;self.cam.motion_owner='NONE';self.exit_reason=reason
   self._log(f'motion session end gen={g} reason={reason}')
  self.thread=threading.Thread(target=run,name=f'Pulse-{self.cam.id}-{g}',daemon=True);self.thread.start();return g
 def move_to(self,target,owner='AUTOMATION',external_cancel=None):
  target=max(-self.cam.left_limit,min(self.cam.right_limit,int(target)));self.target_step=target;self.owner=owner;self.cam.motion_owner=owner
  while self.cam.pan_step!=target:
   if external_cancel and external_cancel.is_set():self.exit_reason='external cancel';return False
   d=1 if target>self.cam.pan_step else -1
   if not self.pulse(d,0,0,self.generation):return False
   if self.cancel.wait(self.pulse_gap):return False
  self._log(f'automation target reached step={target}');return True
