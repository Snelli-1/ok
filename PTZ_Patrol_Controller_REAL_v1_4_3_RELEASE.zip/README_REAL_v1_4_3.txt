PTZ PATROL CONTROLLER REAL v1.4.3
=================================

This release replaces direct GUI and automation motion with one per-camera
BoundedPulseEngine. ContinuousMove and Stop are issued only by that engine.

Key fixes
- Mouse and arrow-key hold repeatedly issue confirmed 0.20 s pulses until release.
- 120 ms keyboard-release debounce tolerates Windows auto-repeat release/press pairs.
- Automation converts normalized Pan targets into bounded integer targets and walks to
  the target one confirmed pulse at a time. AbsoluteMove is not used.
- Hard-bound checks occur before every physical Pan command.
- Counters and radar update only after ContinuousMove and Stop both succeed.
- Failed Stop marks the estimate UNSYNCED and cancels further pulses.
- Camera switching, focus loss, Pause, Emergency Stop and close cancel stale workers.

Controls
- Mouse hold on PTZ buttons: repeated movement.
- Arrow keys held: repeated movement.
- Number keys 1-8: camera selection.
- Space or Escape: Emergency Stop.
- START PATROL: clears Emergency Stop and starts pulse-based automation.

Default camera
192.168.1.102:8899, SOAP 1.2, -26/+26 Pan steps.

Validation
Run: py -3 SELF_TEST_REAL_v1_4_3.py
Then run RUN_REAL_v1_4_3.bat.

Important
Position remains a bounded software estimate because the camera exposes no trustworthy
servo encoder or motor-step feedback. Recalibrate after external movement or power loss.
