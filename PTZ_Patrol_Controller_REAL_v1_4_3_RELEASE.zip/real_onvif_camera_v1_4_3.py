#!/usr/bin/env python3
"""Real ONVIF SOAP 1.2 transport for PTZ Patrol Controller REAL v1.4.3."""
from __future__ import annotations
import http.client,time,urllib.parse,xml.etree.ElementTree as ET
SOAP='http://www.w3.org/2003/05/soap-envelope';TDS='http://www.onvif.org/ver10/device/wsdl';TRT='http://www.onvif.org/ver10/media/wsdl';TPTZ='http://www.onvif.org/ver20/ptz/wsdl';TT='http://www.onvif.org/ver10/schema'
def _local(x):return x.rsplit('}',1)[-1]
def _esc(x):return str(x).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def _env(body):return f'<?xml version="1.0"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'
class OnvifError(RuntimeError):pass
class RealOnvifCamera:
 def __init__(self,host,port=8899,timeout=5,logger=None):
  self.host=host;self.port=int(port);self.timeout=float(timeout);self.logger=logger;self.connected=False;self.device=f'http://{host}:{port}/onvif/device_service';self.media=f'http://{host}:{port}/onvif/media_service';self.ptz=f'http://{host}:{port}/onvif/ptz_service';self.profiles=[]
 def _log(self,x):
  if self.logger:self.logger(x)
 def _call(self,url,op,body):
  u=urllib.parse.urlparse(url);c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=self.timeout);xml=_env(body);t=time.monotonic()
  try:c.request('POST',u.path or '/',xml.encode(),{'Content-Type':'application/soap+xml; charset=utf-8','Connection':'close','User-Agent':'PTZ-Patrol-REAL/1.4.3'});r=c.getresponse();raw=r.read(2097152).decode(errors='replace')
  except Exception as e:self.connected=False;raise OnvifError(f'{op}: {type(e).__name__}: {e}') from e
  finally:c.close()
  self._log(f'{op} HTTP {r.status} {int((time.monotonic()-t)*1000)} ms')
  root=ET.fromstring(raw)
  if any(_local(e.tag)=='Fault' for e in root.iter()):raise OnvifError(f'{op}: SOAP fault')
  return root
 def connect(self):
  cap=self._call(self.device,'GetCapabilities','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>')
  xs=[(e.text or '').strip() for e in cap.iter() if _local(e.tag)=='XAddr']
  self.media=next((x for x in xs if 'media' in x.lower() and 'media2' not in x.lower()),self.media);self.ptz=next((x for x in xs if 'ptz' in x.lower()),self.ptz)
  p=self._call(self.media,'GetProfiles','<trt:GetProfiles/>');self.profiles=[e.attrib['token'] for e in p.iter() if _local(e.tag) in ('Profiles','Profile') and 'token' in e.attrib]
  if not self.profiles:raise OnvifError('No ProfileToken')
  self.connected=True;return True
 def _profile(self):
  if not self.connected:self.connect()
  return self.profiles[0]
 def continuous_move(self,pan,tilt,zoom=0):
  b=f'<tptz:ContinuousMove><tptz:ProfileToken>{_esc(self._profile())}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="{float(pan):.3f}" y="{float(tilt):.3f}"/><tt:Zoom x="{float(zoom):.3f}"/></tptz:Velocity></tptz:ContinuousMove>';self._call(self.ptz,'ContinuousMove',b)
 def stop(self):
  b=f'<tptz:Stop><tptz:ProfileToken>{_esc(self._profile())}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>';self._call(self.ptz,'Stop',b)
 def system_time(self):return self._call(self.device,'GetSystemDateAndTime','<tds:GetSystemDateAndTime/>')
