#!/usr/bin/env python3
"""PTZ Patrol Controller REAL v1.4.3."""
import configparser,math,queue,threading,time
from dataclasses import dataclass,field
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from real_onvif_camera_v1_4_3 import RealOnvifCamera
from bounded_pulse_engine_v1_4_3 import BoundedPulseEngine
BASE=Path(__file__).resolve().parent;CFG=BASE/'config_REAL_v1_4_3.ini'
@dataclass
class Point:name:str;pan:float;dwell:float=5
@dataclass
class Cam:
 id:str;name:str;host:str;port:int=8899;enabled:bool=True;points:list=field(default_factory=list);api:object=None;engine:object=None;state:str='DISCONNECTED';pan_step:int=0;left_limit:int=26;right_limit:int=26;tilt_step:int=0;tilt_up_limit:int=13;tilt_down_limit:int=13;heading_deg:float=0;confidence:str='UNSYNCED';manual_override:bool=False;motion_owner:str='NONE';auto_index:int=0;last_error:str=''
class Radar(tk.Canvas):
 def __init__(self,p):super().__init__(p,bg='#062718',height=210,highlightthickness=1);self.cam=None;self.bind('<Configure>',lambda e:self.draw())
 def set(self,c):self.cam=c;self.draw()
 def draw(self):
  self.delete('all');w=max(100,self.winfo_width());h=max(100,self.winfo_height());cx=w/2;cy=h/2;r=min(w,h)*.36
  for f in (1,.66,.33):self.create_oval(cx-r*f,cy-r*f,cx+r*f,cy+r*f,outline='#47e880')
  self.create_line(cx-r,cy,cx+r,cy,fill='#247944');self.create_line(cx,cy-r,cx,cy+r,fill='#247944')
  if not self.cam:return
  a=math.radians(self.cam.heading_deg);x=cx+math.cos(a)*r*.85;y=cy-math.sin(a)*r*.85
  self.create_line(cx,cy,x,y,fill='#baff35',width=4,arrow='last');self.create_text(cx,14,text=self.cam.name,fill='white',font=('Segoe UI',11,'bold'));self.create_text(cx,h-14,text=f'S{self.cam.pan_step:+d}  {self.cam.heading_deg:+.1f} deg  {self.cam.motion_owner}',fill='#baff35')
class Controller:
 def __init__(self,cams,emit):self.cams=cams;self.emit=emit;self.stop_evt=threading.Event();self.pause_evt=threading.Event();self.thread=None;self.mode='STOPPED'
 def connect(self,c):
  c.state='CONNECTING'
  try:c.api=RealOnvifCamera(c.host,c.port,logger=lambda x:self.emit(c.id,x));c.api.connect();c.engine=BoundedPulseEngine(c,self.emit);c.state='READY';c.confidence='ESTIMATED';return True
  except Exception as e:c.state='ERROR';c.last_error=str(e);self.emit(c.id,str(e));return False
 def start(self):
  valid=[c for c in self.cams if c.enabled and c.points]
  if not valid:self.emit('SYSTEM','No enabled camera has patrol points');return
  self.emergency(False);self.stop_evt.clear();self.pause_evt.clear();self.mode='RUNNING'
  if self.thread and self.thread.is_alive():return
  self.thread=threading.Thread(target=self.loop,name='AutomationScheduler',daemon=True);self.thread.start()
 def loop(self):
  self.emit('SYSTEM','AUTOMATION START')
  while not self.stop_evt.is_set():
   if self.pause_evt.is_set():self.mode='PAUSED';time.sleep(.05);continue
   self.mode='RUNNING'
   for c in self.cams:
    if self.stop_evt.is_set():break
    if not c.enabled or not c.points or c.manual_override:continue
    if not c.api and not self.connect(c):continue
    point=c.points[c.auto_index%len(c.points)];target=max(-c.left_limit,min(c.right_limit,round(point.pan*26)));c.state='AUTO_MOVING';c.engine.cancel_motion('automation new target',join=True,stop=True)
    with c.engine.lock:c.engine.generation+=1;c.engine.cancel=threading.Event();c.engine.owner='AUTOMATION';c.engine.target_step=target
    self.emit(c.id,f'automation point={point.name} target={target}')
    if c.engine.move_to(target,'AUTOMATION',self.stop_evt):
     c.state='AUTO_DWELL';self.emit(c.id,f'dwell start {point.dwell:.1f} s');end=time.monotonic()+point.dwell
     while time.monotonic()<end and not self.stop_evt.is_set() and not self.pause_evt.is_set() and not c.manual_override:time.sleep(.05)
     self.emit(c.id,'dwell end');c.auto_index=(c.auto_index+1)%len(c.points);c.state='READY'
   time.sleep(.03)
  self.mode='STOPPED';self.emit('SYSTEM','AUTOMATION EXIT')
 def pause(self):
  if self.pause_evt.is_set():self.pause_evt.clear()
  else:self.pause_evt.set();[c.engine.cancel_motion('pause') for c in self.cams if c.engine]
 def emergency(self,active=True):
  if active:self.stop_evt.set();self.mode='EMERGENCY'
  for c in self.cams:
   if c.engine:c.engine.cancel_motion('EMERGENCY' if active else 'restart',join=True,stop=True)
   if active:c.state='STOPPED';c.motion_owner='EMERGENCY'
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('PTZ Patrol Controller REAL v1.4.3');self.geometry('1400x850');self.q=queue.Queue();self.cams=self.load();self.ctrl=Controller(self.cams,self.emit);self.selected=self.cams[0];self.key_timer={};self.key_stamp={};self.mouse_cam=None;self.build();self.bind_keys();self.after(100,self.tick);self.protocol('WM_DELETE_WINDOW',self.close)
 def load(self):
  cp=configparser.ConfigParser();cp.read(CFG);out=[]
  for s in cp.sections():
   c=Cam(s,cp.get(s,'name'),cp.get(s,'host'),cp.getint(s,'port',fallback=8899),left_limit=cp.getint(s,'left_limit',fallback=26),right_limit=cp.getint(s,'right_limit',fallback=26));
   for x in cp.get(s,'points',fallback='CENTER,0,5').split('|'):
    n,pan,d=x.split(',');c.points.append(Point(n.strip(),float(pan),float(d)))
   out.append(c)
  return out or [Cam('camera_1','Macro Video IPCamera','192.168.1.102',points=[Point('CENTER',0),Point('LEFT',-.6),Point('RIGHT',.6)])]
 def emit(self,c,m):self.q.put((c,m))
 def build(self):
  top=ttk.Frame(self,padding=6);top.pack(fill='x');self.mode=ttk.Label(top,text='MODE: STOPPED',font=('Segoe UI',11,'bold'));self.mode.pack(side='right')
  for t,f in [('CONNECT',self.connect),('START PATROL',self.ctrl.start),('PAUSE',self.ctrl.pause),('EMERGENCY STOP',lambda:self.ctrl.emergency(True))]:ttk.Button(top,text=t,command=f).pack(side='left',padx=3)
  pane=ttk.Panedwindow(self,orient='horizontal');pane.pack(fill='both',expand=True,padx=6,pady=6);left=ttk.Frame(pane,padding=6);right=ttk.Frame(pane,padding=6);pane.add(left,weight=2);pane.add(right,weight=4)
  self.tree=ttk.Treeview(left,columns=('key','name','state'),show='headings',height=6)
  for n in ('key','name','state'):self.tree.heading(n,text=n.upper())
  self.tree.pack(fill='x');self.tree.bind('<<TreeviewSelect>>',self.select)
  pad=ttk.LabelFrame(left,text='Hold mouse or arrow key');pad.pack(fill='x',pady=6);g=ttk.Frame(pad);g.pack()
  for text,r,c,d,t in [('UP',0,1,0,1),('LEFT',1,0,-1,0),('RIGHT',1,2,1,0),('DOWN',2,1,0,-1)]:
   b=ttk.Button(g,text=text,width=9);b.grid(row=r,column=c,padx=2,pady=2);b.bind('<ButtonPress-1>',lambda e,d=d,t=t:self.mouse_start(d,t));b.bind('<ButtonRelease-1>',lambda e:self.release('mouse'))
  ttk.Button(g,text='STOP',command=lambda:self.release('stop')).grid(row=1,column=1)
  ttk.Label(left,text='1-8 select camera | arrows PTZ | Space/Esc emergency').pack()
  self.status=tk.Text(left,height=22,bg='#101719',fg='#d8f3dc',font=('Consolas',9));self.status.pack(fill='both',expand=True,pady=6)
  self.radar=Radar(right);self.radar.pack(fill='both',expand=True)
  self.log=tk.Text(right,height=14,bg='#101719',fg='#d8f3dc',font=('Consolas',9));self.log.pack(fill='x',pady=6)
  self.refresh_tree()
 def refresh_tree(self):
  self.tree.delete(*self.tree.get_children())
  for i,c in enumerate(self.cams):self.tree.insert('', 'end',iid=c.id,values=(i+1,c.name,c.state))
  self.tree.selection_set(self.selected.id)
 def connect(self):threading.Thread(target=lambda:self.ctrl.connect(self.selected),daemon=True).start()
 def select(self,e=None):
  ids=self.tree.selection()
  if ids and ids[0]!=self.selected.id:self.release('camera switch');self.selected=next(c for c in self.cams if c.id==ids[0])
 def choose(self,i):
  if i<len(self.cams):self.release('camera switch');self.selected=self.cams[i];self.tree.selection_set(self.selected.id)
 def ensure(self,c):return bool(c.api or self.ctrl.connect(c))
 def mouse_start(self,d,t):
  c=self.selected
  if self.ensure(c):self.mouse_cam=c;c.engine.start_hold(d,t,0,'MOUSE')
 def release(self,reason):
  c=self.mouse_cam or self.selected
  if c.engine:c.engine.cancel_motion(reason,join=True,stop=True);c.state='READY';c.motion_owner='NONE'
  self.mouse_cam=None
 def bind_keys(self):self.bind_all('<KeyPress>',self.key_down);self.bind_all('<KeyRelease>',self.key_up);self.bind_all('<FocusOut>',lambda e:self.release('focus loss'));self.bind_all('<ButtonRelease-1>',lambda e:self.release('root mouse release'),add='+')
 def editing(self):return isinstance(self.focus_get(),(tk.Entry,tk.Text,ttk.Entry))
 def key_down(self,e):
  if self.editing():return
  m={'Left':(-1,0),'Right':(1,0),'Up':(0,1),'Down':(0,-1)}
  if e.keysym in m:
   self.key_stamp[e.keysym]=time.monotonic();timer=self.key_timer.pop(e.keysym,None)
   if timer:self.after_cancel(timer)
   if not self.selected.engine or self.selected.engine.owner!='KEYBOARD':
    self.release('direction change');c=self.selected
    if self.ensure(c):c.engine.start_hold(*m[e.keysym],0,'KEYBOARD')
   return 'break'
  if e.keysym in ('space','Escape'):self.ctrl.emergency(True);return 'break'
  if e.keysym in tuple(str(i) for i in range(1,9)):self.choose(int(e.keysym)-1);return 'break'
 def key_up(self,e):
  if e.keysym in ('Left','Right','Up','Down'):
   stamp=self.key_stamp.get(e.keysym,0)
   def debounce():
    if time.monotonic()-self.key_stamp.get(e.keysym,0)>=.11:self.release('keyboard debounce release')
   self.key_timer[e.keysym]=self.after(120,debounce);return 'break'
 def tick(self):
  while not self.q.empty():c,m=self.q.get();self.log.insert('end',f'[{time.strftime("%H:%M:%S")}] [{c}] {m}\n');self.log.see('end')
  c=self.selected;e=c.engine;left=c.pan_step+c.left_limit;right=c.right_limit-c.pan_step
  lines=[f'Camera: {c.name}',f'State: {c.state}',f'Owner: {c.motion_owner}',f'Pan step: {c.pan_step:+d}',f'Left remaining: {left} steps',f'Right remaining: {right} steps',f'Confidence: {c.confidence}',f'Target step: {e.target_step if e else None}',f'Pulse count: {e.pulses if e else 0}',f'Hold active: {e.hold_active if e else False}',f'Hard blocked: {e.hard_blocked if e else False}',f'Worker alive: {e.alive() if e else False}',f'Last error: {c.last_error or "none"}'];self.status.delete('1.0','end');self.status.insert('end','\n'.join(lines));self.radar.set(c);self.mode.config(text='MODE: '+self.ctrl.mode)
  for cam in self.cams:
   if self.tree.exists(cam.id):self.tree.item(cam.id,values=(self.cams.index(cam)+1,cam.name,cam.state))
  self.after(150,self.tick)
 def close(self):self.ctrl.emergency(True);self.destroy()
if __name__=='__main__':App().mainloop()
