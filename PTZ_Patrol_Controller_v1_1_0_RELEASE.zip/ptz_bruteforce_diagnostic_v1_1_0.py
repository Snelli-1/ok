#!/usr/bin/env python3
"""PTZ Patrol Controller 1.1.0 safe compatibility survey.
Read-only by default. Motion requires --allow-motion and is bounded.
"""
from __future__ import annotations
import argparse, csv, hashlib, http.client, json, os, platform, re, socket, subprocess, sys, time, traceback, urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

VERSION="1.1.0"
COMMON_PORTS=[80,81,88,443,554,8000,8080,8554,8899,2020,5000,34567,37777]
ONVIF_PORTS=[80,81,88,8000,8080,8899,2020,5000]
ERRORS={
"E000":"OK", "E101":"TCP connection refused/unreachable", "E102":"TCP timeout", "E103":"DNS/invalid address",
"E201":"HTTP authentication required", "E202":"HTTP response received but endpoint not ONVIF", "E203":"HTTP request failed",
"E301":"ONVIF dependency missing", "E302":"ONVIF authentication failed", "E303":"ONVIF device service failed",
"E304":"Media service unavailable", "E305":"PTZ service unavailable", "E306":"No media profiles", "E307":"No PTZ-capable profile",
"E308":"ONVIF operation unsupported", "E309":"SOAP/ONVIF timeout", "E310":"Malformed/incomplete ONVIF response",
"E401":"No position data", "E402":"No move status", "E403":"No presets", "E404":"No stream URI", "E405":"No snapshot URI",
"E501":"Motion test locked; --allow-motion not supplied", "E502":"Movement command failed", "E503":"Emergency Stop/Stop failed",
"E504":"Cannot safely test AbsoluteMove without a known position/range", "E505":"Cannot safely test RelativeMove without range data",
"E601":"MAC address not found", "E602":"OUI vendor not found", "E603":"IEEE OUI database missing",
"E701":"Unexpected internal error", "E702":"Test interrupted by operator", "E703":"Stable-step error recovered; test continued",
}

@dataclass
class StepResult:
    seq:int; phase:str; operation:str; target:str; started:str; elapsed_ms:int; status:str; code:str; meaning:str; detail:str; data:Dict[str,Any]

class SurveyLog:
    def __init__(self, host:str, out_dir:Path):
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
        safe=re.sub(r"[^A-Za-z0-9_.-]","_",host)
        out_dir.mkdir(parents=True,exist_ok=True)
        self.txt=out_dir/f"ALL_IN_ONE_{safe}_{stamp}.txt"
        self.jsonl=out_dir/f"MACHINE_READABLE_{safe}_{stamp}.jsonl"
        self.seq=0; self.results:List[StepResult]=[]
        self._write_header(host)
    def _write_header(self,host):
        text=f"""PTZ PATROL CONTROLLER v{VERSION} - ALL IN ONE COMPATIBILITY LOG
Generated: {datetime.now(timezone.utc).isoformat()}
Target: {host}

HOW TO READ THIS LOG
PASS = the camera returned a usable response.
FAIL = the operation was attempted and failed.
SKIP = the operation was intentionally not attempted because a prerequisite or safety permission was absent.
INFO = discovery evidence, not a pass/fail claim.
Each line has a short code. Search that code in README_v1_1_0.txt.
Timing is elapsed milliseconds. TIMEOUT entries distinguish a silent camera from an explicit rejection.
Read-only capability discovery runs first. Physical movement runs last and only with --allow-motion.
A successful SOAP response proves communication, but movement confirmation requires status change or visual observation.

LOGICAL ORDER
01 environment -> 02 reachability -> 03 MAC/OUI -> 04 ports -> 05 HTTP/RTSP fingerprints ->
06 ONVIF endpoint/auth -> 07 services -> 08 media/profiles/URIs -> 09 PTZ metadata/status/presets ->
10 optional bounded motion -> 11 capability and position conclusion.

"""
        self.txt.write_text(text,encoding="utf-8")
    def note(self,text):
        with self.txt.open("a",encoding="utf-8") as f:f.write(f"\n### {text}\n")
    def add(self,phase,operation,target,status,code,detail="",data=None,started_mono=None):
        self.seq+=1; data=data or {}; elapsed=int((time.monotonic()-(started_mono or time.monotonic()))*1000)
        r=StepResult(self.seq,phase,operation,target,datetime.now(timezone.utc).isoformat(),elapsed,status,code,ERRORS.get(code,"Unknown code"),sanitize(detail),sanitize_obj(data))
        self.results.append(r)
        line=f"[{r.seq:03d}] {phase:<12} {operation:<30} {status:<5} {code} {elapsed:>6} ms | {r.detail}\n"
        with self.txt.open("a",encoding="utf-8") as f:f.write(line)
        with self.jsonl.open("a",encoding="utf-8") as f:f.write(json.dumps(asdict(r),ensure_ascii=False,default=str)+"\n")
        return r
    def finish(self,summary):
        self.note("FINAL CAPABILITY SUMMARY")
        with self.txt.open("a",encoding="utf-8") as f:
            f.write(json.dumps(sanitize_obj(summary),indent=2,ensure_ascii=False,default=str)+"\n")
            f.write("\nERROR CODE INDEX\n")
            for k,v in ERRORS.items():f.write(f"{k}: {v}\n")
        return self.txt,self.jsonl

def sanitize(s):
    s=str(s or "")
    s=re.sub(r"(?i)(password|passwd|pwd|authorization)(\s*[:=]\s*)[^\s,;]+",r"\1\2<REDACTED>",s)
    s=re.sub(r"(?i)(://[^:/\s]+:)[^@/\s]+@",r"\1<REDACTED>@",s)
    return s[:4000]
def sanitize_obj(v):
    if isinstance(v,dict): return {str(k):("<REDACTED>" if str(k).lower() in {"password","authorization","passwd","pwd"} else sanitize_obj(x)) for k,x in v.items()}
    if isinstance(v,(list,tuple)): return [sanitize_obj(x) for x in v]
    if isinstance(v,(str,bytes)): return sanitize(v.decode(errors="replace") if isinstance(v,bytes) else v)
    if isinstance(v,(int,float,bool)) or v is None:return v
    try:return sanitize(str(v))
    except:return "<unprintable>"

def classify(exc:Exception,default="E701"):
    t=str(exc).lower()
    if "timed out" in t or "timeout" in t:return "E309"
    if any(x in t for x in ["401","unauthorized","not authorized","authentication","password digest"]):return "E302"
    if any(x in t for x in ["actionnotsupported","not supported","unsupported"]):return "E308"
    if any(x in t for x in ["refused","unreachable","no route"]):return "E101"
    return default

def timed(log,phase,op,target,fn:Callable[[],Any],ok_detail="response received",fail_code="E701"):
    start=time.monotonic()
    try:
        data=fn(); log.add(phase,op,target,"PASS","E000",ok_detail,to_plain(data),start); return True,data
    except Exception as e:
        log.add(phase,op,target,"FAIL",classify(e,fail_code),f"{type(e).__name__}: {e}",{"trace_tail":traceback.format_exc().splitlines()[-4:]},start); return False,None

def to_plain(x,depth=0):
    if depth>4:return str(x)
    if x is None or isinstance(x,(str,int,float,bool)):return x
    if isinstance(x,(list,tuple)):return [to_plain(v,depth+1) for v in x]
    if isinstance(x,dict):return {str(k):to_plain(v,depth+1) for k,v in x.items()}
    if hasattr(x,"__dict__"):return {str(k):to_plain(v,depth+1) for k,v in vars(x).items() if not str(k).startswith("_")}
    return str(x)

def tcp_probe(host,port,timeout):
    with socket.create_connection((host,port),timeout=timeout):return {"open":True}
def http_probe(host,port,timeout,path="/"):
    cls=http.client.HTTPSConnection if port==443 else http.client.HTTPConnection
    c=cls(host,port,timeout=timeout)
    try:
        c.request("GET",path,headers={"User-Agent":f"PTZPatrol/{VERSION}"}); r=c.getresponse(); body=r.read(1024)
        return {"status":r.status,"reason":r.reason,"server":r.getheader("Server"),"www_authenticate":r.getheader("WWW-Authenticate"),"content_type":r.getheader("Content-Type"),"body_sha256":hashlib.sha256(body).hexdigest(),"body_preview":body[:160].decode(errors="replace")}
    finally:c.close()
def rtsp_probe(host,port,timeout):
    s=socket.create_connection((host,port),timeout=timeout);s.settimeout(timeout)
    try:
        req=f"OPTIONS rtsp://{host}:{port}/ RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: PTZPatrol/{VERSION}\r\n\r\n".encode();s.sendall(req);return {"reply":s.recv(2048).decode(errors="replace")}
    finally:s.close()
def get_mac(host):
    cmds=[ ["arp","-a",host], ["ip","neigh","show",host] ]
    if os.name=="nt":cmds=[["arp","-a",host]]
    for cmd in cmds:
        try:
            out=subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT,timeout=5)
            m=re.search(r"(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}",out)
            if m:return m.group(0).replace("-",":").upper(),out
        except Exception:pass
    return None,""
def oui_lookup(mac,paths):
    key=re.sub(r"[^0-9A-F]","",mac.upper())
    for path in paths:
        if not path.exists():continue
        try:
            with path.open(encoding="utf-8-sig",errors="replace",newline="") as f:
                for row in csv.DictReader(f):
                    assignment=re.sub(r"[^0-9A-F]","",row.get("Assignment","").upper())
                    if assignment and key.startswith(assignment):return row.get("Organization Name") or row.get("Organization") or "",assignment,str(path)
        except Exception:continue
    return None,None,None

def attr(obj,name,default=None):return getattr(obj,name,default) if obj is not None else default

def run(args):
    log=SurveyLog(args.host,Path(args.output_dir)); summary={"version":VERSION,"host":args.host,"read_only_default":not args.allow_motion,"open_ports":[],"working_onvif_ports":[],"vendor":None,"position_mode":"unknown","speed_support":"unknown","recommended_mode":"read_only"}
    log.note("01 ENVIRONMENT")
    log.add("environment","runtime",args.host,"INFO","E000",f"Python {platform.python_version()} on {platform.platform()}",{"allow_motion":args.allow_motion,"timeout_s":args.timeout,"delay_s":args.delay})
    log.note("02 REACHABILITY AND 03 MAC/OUI")
    try: socket.getaddrinfo(args.host,None); log.add("network","resolve_host",args.host,"PASS","E000","host resolved")
    except Exception as e: log.add("network","resolve_host",args.host,"FAIL","E103",str(e)); return 2
    mac,raw=get_mac(args.host)
    if mac:
        log.add("identity","arp_mac",args.host,"PASS","E000",f"MAC {mac}")
        vendor,prefix,source=oui_lookup(mac,[Path("oui.csv"),Path("data/oui.csv"),Path("mam.csv"),Path("oui36.csv")])
        if vendor:summary["vendor"]=vendor;log.add("identity","ieee_oui_lookup",mac,"PASS","E000",f"{vendor} ({prefix})",{"source":source})
        else:log.add("identity","ieee_oui_lookup",mac,"INFO","E602","No matching local IEEE assignment; run update_ieee_oui_database.py")
    else:log.add("identity","arp_mac",args.host,"INFO","E601","MAC unavailable; target may not be on the local L2 network")
    log.note("04 DYNAMIC MULTIPORT SCAN")
    ports=sorted(set((args.ports or COMMON_PORTS)+ONVIF_PORTS))
    for p in ports:
        start=time.monotonic()
        try:tcp_probe(args.host,p,args.timeout);summary["open_ports"].append(p);log.add("port_scan",f"tcp_{p}",f"{args.host}:{p}","PASS","E000","TCP port open",started_mono=start)
        except socket.timeout as e:log.add("port_scan",f"tcp_{p}",f"{args.host}:{p}","FAIL","E102",str(e),started_mono=start)
        except Exception as e:log.add("port_scan",f"tcp_{p}",f"{args.host}:{p}","FAIL","E101",str(e),started_mono=start)
        time.sleep(args.delay)
    log.note("05 HTTP AND RTSP FINGERPRINTS")
    for p in summary["open_ports"]:
        if p in (80,81,88,443,8000,8080,8899,2020,5000):timed(log,"fingerprint",f"http_get_root_{p}",f"{args.host}:{p}",lambda p=p:http_probe(args.host,p,args.timeout),fail_code="E203")
        if p in (554,8554):timed(log,"fingerprint",f"rtsp_options_{p}",f"{args.host}:{p}",lambda p=p:rtsp_probe(args.host,p,args.timeout),fail_code="E203")
        time.sleep(args.delay)
    log.note("06-09 ONVIF SERVICE AND CAPABILITY SURVEY")
    try:from onvif import ONVIFCamera
    except Exception as e:
        log.add("onvif","import_onvif_zeep","local","FAIL","E301",str(e));log.finish(summary);return 3
    successful=[]
    candidate_ports=[p for p in summary["open_ports"] if p in ONVIF_PORTS] or ONVIF_PORTS
    for p in candidate_ports:
        ok,cam=timed(log,"onvif",f"connect_port_{p}",f"{args.host}:{p}",lambda p=p:ONVIFCamera(args.host,p,args.username,args.password),"ONVIFCamera object created","E303")
        if not ok:continue
        ok,info=timed(log,"onvif",f"GetDeviceInformation_{p}",f"{args.host}:{p}",lambda cam=cam:cam.devicemgmt.GetDeviceInformation(),fail_code="E303")
        if not ok:continue
        successful.append((p,cam));summary["working_onvif_ports"].append(p)
        if not summary["vendor"]:summary["vendor"]=str(attr(info,"Manufacturer","") or "")
        timed(log,"onvif","GetSystemDateAndTime",str(p),lambda cam=cam:cam.devicemgmt.GetSystemDateAndTime(),fail_code="E303")
        timed(log,"onvif","GetCapabilities_All",str(p),lambda cam=cam:cam.devicemgmt.GetCapabilities({"Category":"All"}),fail_code="E303")
        timed(log,"onvif","GetServices",str(p),lambda cam=cam:cam.devicemgmt.GetServices({"IncludeCapability":True}),fail_code="E303")
        okm,media=timed(log,"media","CreateMediaService",str(p),lambda cam=cam:cam.create_media_service(),fail_code="E304")
        okp,ptz=timed(log,"ptz","CreatePTZService",str(p),lambda cam=cam:cam.create_ptz_service(),fail_code="E305")
        if not okm:continue
        okprof,profiles=timed(log,"media","GetProfiles",str(p),lambda media=media:media.GetProfiles(),fail_code="E306")
        if not okprof or not profiles:continue
        for idx,profile in enumerate(profiles):
            token=str(attr(profile,"token","") or attr(profile,"_token","") or "")
            log.add("media",f"Profile_{idx}",token,"INFO","E000",f"profile token={token}",to_plain(profile))
            timed(log,"media",f"GetStreamUri_{idx}",token,lambda media=media,token=token:media.GetStreamUri({"StreamSetup":{"Stream":"RTP-Unicast","Transport":{"Protocol":"RTSP"}},"ProfileToken":token}),fail_code="E404")
            timed(log,"media",f"GetSnapshotUri_{idx}",token,lambda media=media,token=token:media.GetSnapshotUri({"ProfileToken":token}),fail_code="E405")
            if not okp:continue
            timed(log,"ptz",f"GetStatus_{idx}",token,lambda ptz=ptz,token=token:ptz.GetStatus({"ProfileToken":token}),fail_code="E401")
            okpre,presets=timed(log,"ptz",f"GetPresets_{idx}",token,lambda ptz=ptz,token=token:ptz.GetPresets({"ProfileToken":token}),fail_code="E403")
            timed(log,"ptz","GetNodes",token,lambda ptz=ptz:ptz.GetNodes(),fail_code="E308")
            timed(log,"ptz","GetConfigurations",token,lambda ptz=ptz:ptz.GetConfigurations(),fail_code="E308")
            cfg_token=str(attr(attr(profile,"PTZConfiguration",None),"token","") or attr(attr(profile,"PTZConfiguration",None),"_token","") or "")
            if cfg_token:timed(log,"ptz","GetConfigurationOptions",cfg_token,lambda ptz=ptz,cfg_token=cfg_token:ptz.GetConfigurationOptions({"ConfigurationToken":cfg_token}),fail_code="E308")
            if args.allow_motion:
                run_motion_suite(log,ptz,token,presets if okpre else [],args,summary)
            else:log.add("motion","all_motion_commands",token,"SKIP","E501","Read-only survey complete. Re-run with --allow-motion only while watching the camera and keeping its area clear.")
            break
        break
    if not successful:summary["recommended_mode"]="vendor_or_non_onvif_diagnostics";summary["position_mode"]="software_estimation_required_until_proven"
    txt,jsonl=log.finish(summary)
    print(f"ALL_IN_ONE_LOG={txt}");print(f"JSONL_LOG={jsonl}")
    return 0 if successful else 4

def safe_stop(log,ptz,token,label):
    return timed(log,"motion",label,token,lambda:ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True}),fail_code="E503")[0]
def run_motion_suite(log,ptz,token,presets,args,summary):
    log.note("10 ARMED, BOUNDED, NON-DESTRUCTIVE MOTION TESTS")
    safe_stop(log,ptz,token,"Stop_before_motion")
    ok0,s0=timed(log,"motion","GetStatus_baseline",token,lambda:ptz.GetStatus({"ProfileToken":token}),fail_code="E401")
    position=attr(s0,"Position",None) if ok0 else None
    summary["position_mode"]="camera_reported" if position is not None else "software_estimation_required"
    speeds=[0.10,0.25,0.50]
    for speed in speeds:
        start=time.monotonic()
        try:
            ptz.ContinuousMove({"ProfileToken":token,"Velocity":{"PanTilt":{"x":speed,"y":0.0},"Zoom":{"x":0.0}}});time.sleep(min(args.motion_seconds,0.35));ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True})
            log.add("motion",f"ContinuousMove_pan_speed_{speed:.2f}",token,"PASS","E000","command accepted and Stop sent; verify physical movement/status delta",started_mono=start)
            summary["speed_support"]="command_accepted_multiple_speeds"
        except Exception as e:
            try:ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True})
            except Exception:pass
            log.add("motion",f"ContinuousMove_pan_speed_{speed:.2f}",token,"FAIL",classify(e,"E502"),str(e),started_mono=start)
        time.sleep(max(args.delay,1.0))
    safe_stop(log,ptz,token,"Stop_after_continuous_tests")
    if presets:
        first=presets[0];ptoken=str(attr(first,"token","") or attr(first,"_token","") or "")
        if ptoken:timed(log,"motion","GotoPreset_existing_first",ptoken,lambda:ptz.GotoPreset({"ProfileToken":token,"PresetToken":ptoken}),fail_code="E502");summary["recommended_mode"]="preset_only_candidate"
    else:log.add("motion","GotoPreset_existing_first",token,"SKIP","E403","No existing preset. The survey never creates or deletes presets.")
    if position is None:
        log.add("motion","AbsoluteMove_roundtrip",token,"SKIP","E504","Position unavailable; unsafe to construct a return-to-origin move.")
        log.add("motion","RelativeMove_roundtrip",token,"SKIP","E505","No validated coordinate range/return position.")
    safe_stop(log,ptz,token,"Final_Emergency_Stop")

def parse_ports(text):
    if not text:return None
    out=[]
    for x in text.split(","):
        p=int(x.strip())
        if not 1<=p<=65535:raise argparse.ArgumentTypeError("ports must be 1..65535")
        out.append(p)
    return out

def main():
    ap=argparse.ArgumentParser(description="PTZ Patrol Controller 1.1.0 safe brute-force compatibility survey")
    ap.add_argument("--host",required=True);ap.add_argument("--username",default="admin");ap.add_argument("--password",default="")
    ap.add_argument("--ports",type=parse_ports,help="comma-separated extra/override candidates")
    ap.add_argument("--timeout",type=float,default=3.0);ap.add_argument("--delay",type=float,default=0.75)
    ap.add_argument("--motion-seconds",type=float,default=0.25);ap.add_argument("--output-dir",default="bruteforce_logs")
    ap.add_argument("--allow-motion",action="store_true",help="ARM bounded physical movement. Omit for read-only survey.")
    ap.add_argument("--version",action="version",version=VERSION)
    a=ap.parse_args();a.timeout=max(.2,min(a.timeout,30));a.delay=max(.1,min(a.delay,10));a.motion_seconds=max(.1,min(a.motion_seconds,.5))
    try:return run(a)
    except KeyboardInterrupt:print("Interrupted; if camera was moving use its app/power-safe stop procedure.",file=sys.stderr);return 130
    except Exception:traceback.print_exc();return 1
if __name__=="__main__":raise SystemExit(main())
