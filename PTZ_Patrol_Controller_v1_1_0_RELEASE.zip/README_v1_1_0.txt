PTZ PATROL CONTROLLER 1.1.0 - COMPATIBILITY SURVEY RELEASE
==========================================================

PURPOSE
-------
This release adds a slow, ordered, multiport and multi-operation compatibility survey.
It is designed for cameras that are visible during discovery but do not provide video,
position, presets, or physical PTZ movement through the currently selected backend.

IMPORTANT VERSION NOTE
----------------------
All files in this package belong to version 1.1.0. Do not mix them with files named v1_0.
Rename config_v1_1_0.txt to config.txt only inside a separate v1.1.0 folder.

FIRST RUN
---------
1. Create a new folder named PTZ_Patrol_Controller_v1_1_0.
2. Extract all package files there.
3. Rename requirements_v1_1_0.txt to requirements.txt.
4. Rename config_v1_1_0.txt to config.txt.
5. Install dependencies:

   py -3 -m pip install -r requirements.txt

6. Optionally download the current official IEEE MAC assignment databases:

   py -3 update_ieee_oui_database_v1_1_0.py

7. Rename RUN_READ_ONLY_TEST_v1_1_0.bat.txt to RUN_READ_ONLY_TEST_v1_1_0.bat and run it.

READ-ONLY COMMAND
-----------------
py -3 ptz_bruteforce_diagnostic_v1_1_0.py --host 192.168.1.102 --username admin --password YOUR_PASSWORD

The default survey sends no movement operation. It scans common camera ports slowly,
records HTTP and RTSP evidence, then requests ONVIF device, media, profile, stream,
snapshot, PTZ configuration, status, and preset information in dependency order.

ARMED MOTION COMMAND
--------------------
Use only after the read-only log proves that the PTZ service and a media profile exist:

py -3 ptz_bruteforce_diagnostic_v1_1_0.py --host 192.168.1.102 --username admin --password YOUR_PASSWORD --allow-motion

Motion is deliberately bounded to no more than 0.50 s per command, defaults to 0.25 s,
and sends Stop before, between, after, and at the final emergency-stop checkpoint.
The test never creates, changes, or deletes presets. It may call only an already existing
first preset. AbsoluteMove and RelativeMove are skipped when a safe return position and
coordinate ranges cannot be established.

ALL-IN-ONE LOG
--------------
Send back the newest file:

bruteforce_logs\ALL_IN_ONE_192.168.1.102_YYYYMMDD_HHMMSS.txt

It contains explanations, ordered operations, elapsed time in ms, PASS/FAIL/SKIP/INFO,
short error codes, sanitized replies, and a final compatibility recommendation.
Passwords and authorization fields are redacted. A JSONL companion is also generated.

NO STABLE STEPS ERROR
---------------------
The compatibility survey does not rely on patrol stable-step generation. Every operation
is an independent checkpoint. Failure at one optional operation is logged and the next
logical operation continues. A failed prerequisite causes dependent operations to SKIP,
not an endless popup. The existing GUI may still show the older stable-step error until
the diagnostic result identifies the correct real backend and patrol mode.

POSITION AND SPEED DECISION
---------------------------
- GetStatus returns Position: position_mode=camera_reported.
- PTZ works but Position is absent: position_mode=software_estimation_required.
- Several ContinuousMove speeds are accepted: speed support is a candidate, but real
  speed scaling still requires visual observation or position deltas.
- Existing presets and GotoPreset work: preset_only_candidate is recommended.
- Device service works but PTZ service fails: read_only_media is recommended.
- No ONVIF endpoint works: vendor_or_non_onvif_diagnostics is recommended.

SHORT ERROR CODES
-----------------
E000 OK.
E101 TCP refused or unreachable. Check IP, VLAN, firewall, and camera power.
E102 TCP timeout. Port silently dropped or device too slow.
E103 Invalid/unresolvable host.
E201 HTTP authentication required. This can still prove an HTTP service exists.
E202 HTTP exists but the tested endpoint is not ONVIF.
E203 Generic HTTP/RTSP probe failure.
E301 onvif-zeep missing. Install requirements.txt.
E302 ONVIF authentication failed. Verify account and ONVIF user permissions.
E303 Device service failed. Port may be web/vendor service rather than ONVIF.
E304 Media service unavailable.
E305 PTZ service unavailable.
E306 No media profiles returned.
E307 No PTZ-capable profile found.
E308 Operation explicitly unsupported.
E309 SOAP/ONVIF timeout.
E310 Incomplete or malformed ONVIF response.
E401 Position unavailable. Software position estimation may be required.
E402 MoveStatus unavailable.
E403 No presets returned.
E404 No stream URI returned.
E405 No snapshot URI returned.
E501 Motion test locked. Re-run with --allow-motion only after review.
E502 Movement command rejected or failed.
E503 Stop failed. End testing and use the camera's safe local stop/power procedure.
E504 AbsoluteMove skipped because return-to-origin safety was not proven.
E505 RelativeMove skipped because range/return safety was not proven.
E601 MAC unavailable. OUI lookup works only on the local Layer-2 network or known MAC.
E602 MAC found but no local IEEE assignment matched.
E603 IEEE local database missing. Run the updater.
E701 Unexpected internal error.
E702 Operator interrupted the survey.
E703 A step failed but the sequencer recovered and continued.

MAC/OUI AND VENDOR SELECTION
----------------------------
The update script obtains MA-L, MA-M, and MA-S public CSV assignment data directly from
the IEEE Registration Authority. MAC/OUI is only one evidence source. OEM cameras may
use another manufacturer's network module, so OUI never selects a dangerous vendor
command by itself. Manufacturer/model strings, open ports, HTTP headers, ONVIF services,
profile tokens, working operations, and explicit camera responses are combined.

PORT 80 AND 8899
----------------
The pair is recorded as a weak fingerprint only. It does not prove V380, CamHi, XMeye,
or any other vendor. The tool first tests standard services and writes the evidence.
Unknown proprietary protocols remain read-only until a verified adapter is available.

ONVIF OPERATION ORDER
---------------------
GetDeviceInformation -> GetSystemDateAndTime -> GetCapabilities -> GetServices ->
CreateMediaService -> CreatePTZService -> GetProfiles -> GetStreamUri -> GetSnapshotUri ->
GetStatus -> GetPresets -> GetNodes -> GetConfigurations -> GetConfigurationOptions ->
optional Stop -> bounded ContinuousMove speed samples -> Stop -> optional existing preset -> Stop.

SOURCE REFERENCES
-----------------
ONVIF PTZ Service Specification v25.12:
https://www.onvif.org/specs/2512/ONVIF-PTZ-Service-Spec-v2512.pdf

IEEE Registration Authority public listing:
https://regauth.standards.ieee.org/standards-ra-web/pub/view.html

IEEE public assignment CSV base:
https://standards-oui.ieee.org/
