#!/usr/bin/env python3
"""Download official public IEEE MAC assignment CSV files for local lookup."""
from pathlib import Path
import hashlib, urllib.request, datetime
SOURCES={
 "oui.csv":"https://standards-oui.ieee.org/oui/oui.csv",
 "mam.csv":"https://standards-oui.ieee.org/oui28/mam.csv",
 "oui36.csv":"https://standards-oui.ieee.org/oui36/oui36.csv",
}
def main():
 out=Path("data");out.mkdir(exist_ok=True)
 lines=[f"Updated UTC: {datetime.datetime.now(datetime.timezone.utc).isoformat()}"]
 for name,url in SOURCES.items():
  dest=out/name;tmp=dest.with_suffix(dest.suffix+".tmp")
  req=urllib.request.Request(url,headers={"User-Agent":"PTZ-Patrol-Controller/1.1.0"})
  with urllib.request.urlopen(req,timeout=30) as r: data=r.read()
  if b"Assignment" not in data[:500]: raise RuntimeError(f"Unexpected IEEE response for {url}")
  tmp.write_bytes(data);tmp.replace(dest)
  lines.append(f"{name} {len(data)} bytes SHA256 {hashlib.sha256(data).hexdigest()} {url}")
 (out/"IEEE_OUI_SOURCE_AND_HASHES.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
 print("\n".join(lines))
if __name__=="__main__":main()
