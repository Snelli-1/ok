PTZ MAXIMUM READ-ONLY ENUMERATOR v1.2.0
=======================================
Run the supplied BAT beside the Python script. The TXT log is written into that exact
folder and opened in Notepad at completion.

Default test areas:
- selected-port inventory including 554, 8800, 8899, 5050 and 5051
- Device service and alternate endpoint forms
- broad read-only Device enumeration
- Media 1 profiles, sources, configurations, stream and snapshot URIs
- PTZ capabilities, nodes, configurations, options, status, presets and preset tours
- Imaging settings/options/status/presets
- Event capabilities and event properties
- RTSP OPTIONS and DESCRIBE against known V380 path candidates
- safe unknown-token controls

Optional flags:
--soap11          also test SOAP 1.1; the camera previously dropped those connections
--wide-port-scan  scan TCP 1-65535 on this one private-LAN host with 32 workers

Strict exclusions:
No movement, Home, preset write, config write, PullPoint subscription, auxiliary command,
reboot, reset, firmware operation, credential guessing, cloud request, malformed XML or
exploit payload.
