#!/usr/bin/env python3
"""Maximum safe read-only enumerator for an authorized private-LAN ONVIF/V380 camera.
Logs beside the BAT/script. No movement, writes, reboot, reset, auth guessing, cloud access,
firmware changes, subscriptions, auxiliary commands, or malformed exploit payloads.
"""
from __future__ import annotations
import argparse, http.client, ipaddress, json, os, re, socket, struct, time, traceback, urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

VERSION='1.2.0'
S12='http://www.w3.org/2003/05/soap-envelope';S11='http://schemas.xmlsoap.org/soap/envelope/'
TDS='http://www.onvif.org/ver10/device/wsdl';TRT='http://www.onvif.org/ver10/media/wsdl';TR2='http://www.onvif.org/ver20/media/wsdl';TPTZ='http://www.onvif.org/ver20/ptz/wsdl';TIMG='http://www.onvif.org/ver20/imaging/wsdl';TEV='http://www.onvif.org/ver10/events/wsdl';TT='http://www.onvif.org/ver10/schema'
def loc(t):return t.rsplit('}',1)[-1]
def esc(s):return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def envelope(body,soap):return f'<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{soap}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tr2="{TR2}" xmlns:tptz="{TPTZ}" xmlns:timg="{TIMG}" xmlns:tev="{TEV}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'
def texts(root,name):return [(e.text or '').strip() for e in root.iter() if loc(e.tag)==name and (e.text or '').strip()]
def tokens(root,names):
 out=[]
 for e in root.iter():
  if loc(e.tag) in names:
   value=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
   if value and value not in out:out.append(value)
 return out
class Log:
 def __init__(self,d,host):
  d=Path(d).resolve();d.mkdir(parents=True,exist_ok=True);self.path=d/f'PTZ_MAXIMUM_READONLY_{host}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt';self.f=self.path.open('w',encoding='utf-8',buffering=1);self.n=0;self.start=time.monotonic();self.write(f'PTZ MAXIMUM READ-ONLY ENUMERATOR v{VERSION}\nTarget: {host}\nUTC start: {datetime.now(timezone.utc).isoformat()}\nLog file: {self.path}\nSTRICTLY EXCLUDED: movement, Home, preset writes, config writes, subscriptions, auxiliary commands, reboot, reset, firmware, credentials guessing, cloud access, exploit payloads.\n')
 def write(self,s):print(s,flush=True);self.f.write(s+'\n');self.f.flush()
 def add(self,phase,name,status,detail='',req='',resp=''):
  self.n+=1;self.write(f'[{self.n:04d}] +{time.monotonic()-self.start:8.3f} s {phase:<11} {name:<42} {status:<12} {detail}')
  if req:self.write('REQUEST:\n'+req)
  if resp:self.write('RESPONSE:\n'+resp)
 def close(self):self.f.flush();os.fsync(self.f.fileno());self.f.close()
def soap_post(url,body,soap12,action,timeout):
 u=urllib.parse.urlparse(url);xml=envelope(body,S12 if soap12 else S11);headers={'Connection':'close','User-Agent':f'PTZ-Maximum-ReadOnly/{VERSION}'}
 if soap12:headers['Content-Type']='application/soap+xml; charset=utf-8'+(f'; action="{action}"' if action else '')
 else:headers.update({'Content-Type':'text/xml; charset=utf-8','SOAPAction':f'"{action or ""}"'})
 c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=timeout);start=time.monotonic()
 try:c.request('POST',u.path or '/',xml.encode(),headers);r=c.getresponse();data=r.read(4194304).decode('utf-8',errors='replace')
 finally:c.close()
 return r.status,r.reason,data,xml,int((time.monotonic()-start)*1000)
def call(log,phase,name,url,body,action,timeout,soap12=True):
 try:
  code,reason,data,req,ms=soap_post(url,body,soap12,action,timeout)
  try:root=ET.fromstring(data)
  except Exception:log.add(phase,name,'HTTP_ONLY',f'HTTP {code} {reason}, {ms} ms',req,data[:20000]);return None
  if any(loc(e.tag)=='Fault' for e in root.iter()):
   fault=' | '.join(texts(root,'Text')+texts(root,'Value')) or 'unspecified SOAP fault';log.add(phase,name,'SOAP_FAULT',f'HTTP {code}, {ms} ms, {fault}',req,data);return root
  log.add(phase,name,'SOAP_OK',f'HTTP {code}, {ms} ms, {len(data)} chars',req,data);return root
 except socket.timeout as e:log.add(phase,name,'TIMEOUT',str(e));return None
 except Exception as e:log.add(phase,name,'EXCEPTION',f'{type(e).__name__}: {e}',resp=traceback.format_exc());return None
def variants(log,phase,name,url,body,action,timeout,soap11):
 roots=[]
 roots.append(call(log,phase,name+'_S12_ACTION',url,body,action,timeout,True))
 roots.append(call(log,phase,name+'_S12_NOACTION',url,body,None,timeout,True))
 if soap11:
  roots.append(call(log,phase,name+'_S11_ACTION',url,body,action,timeout,False))
  roots.append(call(log,phase,name+'_S11_EMPTY',url,body,'',timeout,False))
 return roots
def tcp_open(host,port,timeout):
 try:
  with socket.create_connection((host,port),timeout):return port
 except Exception:return None
def rtsp(log,host,port,path,method,timeout):
 uri=f'rtsp://{host}:{port}{path}';req=f'{method} {uri} RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: PTZ-Maximum-ReadOnly/{VERSION}\r\nAccept: application/sdp\r\n\r\n'
 try:
  with socket.create_connection((host,port),timeout) as s:s.sendall(req.encode());s.settimeout(timeout);data=b''
  # connection is closed here; retry with live receive
  with socket.create_connection((host,port),timeout) as s:
   s.sendall(req.encode());s.settimeout(timeout)
   while len(data)<65536:
    try:chunk=s.recv(4096)
    except socket.timeout:break
    if not chunk:break
    data+=chunk
  text=data.decode(errors='replace');log.add('RTSP',f'{method}_{path}','RESPONSE',f'{len(data)} B',req,text)
 except Exception as e:log.add('RTSP',f'{method}_{path}','FAIL',f'{type(e).__name__}: {e}')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='192.168.1.102');ap.add_argument('--port',type=int,default=8899);ap.add_argument('--rtsp-port',type=int,default=554);ap.add_argument('--timeout',type=float,default=4);ap.add_argument('--log-dir',default=str(Path(__file__).resolve().parent));ap.add_argument('--soap11',action='store_true');ap.add_argument('--wide-port-scan',action='store_true');a=ap.parse_args()
 if not ipaddress.ip_address(a.host).is_private:raise SystemExit('Private-LAN target required')
 log=Log(a.log_dir,a.host);base=f'http://{a.host}:{a.port}';device=base+'/onvif/device_service';services={'device':device,'media':base+'/onvif/media_service','media2':base+'/onvif/media2_service','ptz':base+'/onvif/ptz_service','imaging':base+'/onvif/image_service','events':base+'/onvif/event_service'}
 inventory={'open_ports':[],'xaddrs':[],'profiles':[],'video_sources':[],'audio_sources':[],'ptz_nodes':[],'ptz_configs':[],'video_source_configs':[],'video_encoder_configs':[],'audio_source_configs':[],'audio_encoder_configs':[],'metadata_configs':[]}
 try:
  log.add('SYSTEM','POLICY','INFO','Maximum standards-compliant read-only enumeration. Nothing that changes camera state is sent.')
  ports=list(range(1,65536)) if a.wide_port_scan else sorted(set([21,22,23,53,80,81,443,554,8000,8080,8554,8800,8899,5050,5051,34567,37777]))
  workers=32 if a.wide_port_scan else 12
  with ThreadPoolExecutor(max_workers=workers) as ex:
   futures=[ex.submit(tcp_open,a.host,p,.35 if a.wide_port_scan else .8) for p in ports]
   for f in as_completed(futures):
    p=f.result()
    if p:inventory['open_ports'].append(p);log.add('NETWORK',f'TCP_{p}','OPEN','connect succeeded')
  inventory['open_ports'].sort();log.add('NETWORK','PORT_SUMMARY','INFO',json.dumps(inventory['open_ports']))
  for path in ['/onvif/device_service','/onvif/Device_service','/onvif/services','/device_service','/onvif/device_service/']:
   variants(log,'DEVICE','PATH_'+path.replace('/','_'),base+path,'<tds:GetSystemDateAndTime/>',TDS+'/GetSystemDateAndTime',a.timeout,a.soap11)
  device_ops=[
   ('GetSystemDateAndTime','<tds:GetSystemDateAndTime/>'),('GetDeviceInformation','<tds:GetDeviceInformation/>'),('GetServiceCapabilities','<tds:GetServiceCapabilities/>'),('GetServicesTrue','<tds:GetServices><tds:IncludeCapability>true</tds:IncludeCapability></tds:GetServices>'),('GetServicesFalse','<tds:GetServices><tds:IncludeCapability>false</tds:IncludeCapability></tds:GetServices>'),('GetCapabilitiesAll','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>'),('GetScopes','<tds:GetScopes/>'),('GetHostname','<tds:GetHostname/>'),('GetDNS','<tds:GetDNS/>'),('GetNTP','<tds:GetNTP/>'),('GetNetworkInterfaces','<tds:GetNetworkInterfaces/>'),('GetNetworkProtocols','<tds:GetNetworkProtocols/>'),('GetNetworkDefaultGateway','<tds:GetNetworkDefaultGateway/>'),('GetZeroConfiguration','<tds:GetZeroConfiguration/>'),('GetDynamicDNS','<tds:GetDynamicDNS/>'),('GetDiscoveryMode','<tds:GetDiscoveryMode/>'),('GetRemoteDiscoveryMode','<tds:GetRemoteDiscoveryMode/>'),('GetUsers','<tds:GetUsers/>'),('GetWsdlUrl','<tds:GetWsdlUrl/>'),('GetEndpointReference','<tds:GetEndpointReference/>'),('GetSystemLogSystem','<tds:GetSystemLog><tds:LogType>System</tds:LogType></tds:GetSystemLog>'),('GetSystemLogAccess','<tds:GetSystemLog><tds:LogType>Access</tds:LogType></tds:GetSystemLog>'),('GetSystemSupportInformation','<tds:GetSystemSupportInformation/>'),('GetCertificates','<tds:GetCertificates/>'),('GetCertificatesStatus','<tds:GetCertificatesStatus/>'),('GetCACertificates','<tds:GetCACertificates/>'),('GetClientCertificateMode','<tds:GetClientCertificateMode/>'),('GetRelayOutputs','<tds:GetRelayOutputs/>'),('GetDot11Capabilities','<tds:GetDot11Capabilities/>'),('GetDot11Status','<tds:GetDot11Status/>'),('GetDot1XConfigurations','<tds:GetDot1XConfigurations/>'),('GetStorageConfigurations','<tds:GetStorageConfigurations/>'),('GetGeoLocation','<tds:GetGeoLocation/>'),('GetRemoteUser','<tds:GetRemoteUser/>')]
  for name,body in device_ops:
   for root in variants(log,'DEVICE',name,device,body,TDS+'/'+re.sub(r'(True|False|All|System|Access)$','',name),a.timeout,a.soap11):
    if root:
     for x in texts(root,'XAddr'):
      if x not in inventory['xaddrs']:inventory['xaddrs'].append(x)
  for x in inventory['xaddrs']:
   low=x.lower()
   if 'media2' in low:services['media2']=x
   elif 'media' in low:services['media']=x
   elif 'ptz' in low:services['ptz']=x
   elif 'imag' in low:services['imaging']=x
   elif 'event' in low:services['events']=x
  log.add('SYSTEM','SERVICE_MAP','INFO',json.dumps(services,indent=2))
  media_ops=[('GetServiceCapabilities','<trt:GetServiceCapabilities/>'),('GetProfiles','<trt:GetProfiles/>'),('GetVideoSources','<trt:GetVideoSources/>'),('GetAudioSources','<trt:GetAudioSources/>'),('GetVideoSourceConfigurations','<trt:GetVideoSourceConfigurations/>'),('GetVideoEncoderConfigurations','<trt:GetVideoEncoderConfigurations/>'),('GetAudioSourceConfigurations','<trt:GetAudioSourceConfigurations/>'),('GetAudioEncoderConfigurations','<trt:GetAudioEncoderConfigurations/>'),('GetAudioDecoderConfigurations','<trt:GetAudioDecoderConfigurations/>'),('GetMetadataConfigurations','<trt:GetMetadataConfigurations/>'),('GetVideoAnalyticsConfigurations','<trt:GetVideoAnalyticsConfigurations/>'),('GetOSDs','<trt:GetOSDs/>')]
  for name,body in media_ops:
   for root in variants(log,'MEDIA1',name,services['media'],body,TRT+'/'+name,a.timeout,a.soap11):
    if root:
     inventory['profiles']+=tokens(root,{'Profiles','Profile'});inventory['video_sources']+=tokens(root,{'VideoSources','VideoSource'});inventory['audio_sources']+=tokens(root,{'AudioSources','AudioSource'});inventory['video_source_configs']+=tokens(root,{'VideoSourceConfiguration'});inventory['video_encoder_configs']+=tokens(root,{'VideoEncoderConfiguration'});inventory['audio_source_configs']+=tokens(root,{'AudioSourceConfiguration'});inventory['audio_encoder_configs']+=tokens(root,{'AudioEncoderConfiguration'});inventory['metadata_configs']+=tokens(root,{'MetadataConfiguration'})
  for key in list(inventory):
   if isinstance(inventory[key],list):inventory[key]=list(dict.fromkeys(inventory[key]))
  for p in inventory['profiles']:
   profile_ops=[('GetProfile',f'<trt:GetProfile><trt:ProfileToken>{esc(p)}</trt:ProfileToken></trt:GetProfile>'),('GetStreamUri',f'<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup><trt:ProfileToken>{esc(p)}</trt:ProfileToken></trt:GetStreamUri>'),('GetSnapshotUri',f'<trt:GetSnapshotUri><trt:ProfileToken>{esc(p)}</trt:ProfileToken></trt:GetSnapshotUri>')]
   for name,body in profile_ops:variants(log,'MEDIA1',name+'_'+p,services['media'],body,TRT+'/'+name,a.timeout,a.soap11)
  ptz_ops=[('GetServiceCapabilities','<tptz:GetServiceCapabilities/>'),('GetNodes','<tptz:GetNodes/>'),('GetConfigurations','<tptz:GetConfigurations/>')]
  for name,body in ptz_ops:
   for root in variants(log,'PTZ',name,services['ptz'],body,TPTZ+'/'+name,a.timeout,a.soap11):
    if root:inventory['ptz_nodes']+=tokens(root,{'PTZNode'});inventory['ptz_configs']+=tokens(root,{'PTZConfiguration'})
  inventory['ptz_nodes']=list(dict.fromkeys(inventory['ptz_nodes']));inventory['ptz_configs']=list(dict.fromkeys(inventory['ptz_configs']))
  for n in inventory['ptz_nodes']:variants(log,'PTZ','GetNode_'+n,services['ptz'],f'<tptz:GetNode><tptz:NodeToken>{esc(n)}</tptz:NodeToken></tptz:GetNode>',TPTZ+'/GetNode',a.timeout,a.soap11)
  for c in inventory['ptz_configs']:
   variants(log,'PTZ','GetConfiguration_'+c,services['ptz'],f'<tptz:GetConfiguration><tptz:PTZConfigurationToken>{esc(c)}</tptz:PTZConfigurationToken></tptz:GetConfiguration>',TPTZ+'/GetConfiguration',a.timeout,a.soap11)
   variants(log,'PTZ','GetConfigurationOptions_'+c,services['ptz'],f'<tptz:GetConfigurationOptions><tptz:ConfigurationToken>{esc(c)}</tptz:ConfigurationToken></tptz:GetConfigurationOptions>',TPTZ+'/GetConfigurationOptions',a.timeout,a.soap11)
  for p in inventory['profiles']:
   for name,body in [('GetCompatibleConfigurations',f'<tptz:GetCompatibleConfigurations><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetCompatibleConfigurations>'),('GetStatus',f'<tptz:GetStatus><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetStatus>'),('GetPresets',f'<tptz:GetPresets><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetPresets>'),('GetPresetTours',f'<tptz:GetPresetTours><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetPresetTours>')]:variants(log,'PTZ',name+'_'+p,services['ptz'],body,TPTZ+'/'+name,a.timeout,a.soap11)
  for v in inventory['video_sources']:
   for name,body in [('GetImagingSettings',f'<timg:GetImagingSettings><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetImagingSettings>'),('GetOptions',f'<timg:GetOptions><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetOptions>'),('GetMoveOptions',f'<timg:GetMoveOptions><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetMoveOptions>'),('GetStatus',f'<timg:GetStatus><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetStatus>'),('GetPresets',f'<timg:GetPresets><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetPresets>'),('GetCurrentPreset',f'<timg:GetCurrentPreset><timg:VideoSourceToken>{esc(v)}</timg:VideoSourceToken></timg:GetCurrentPreset>')]:variants(log,'IMAGING',name+'_'+v,services['imaging'],body,TIMG+'/'+name,a.timeout,a.soap11)
  variants(log,'EVENTS','GetServiceCapabilities',services['events'],'<tev:GetServiceCapabilities/>',TEV+'/GetServiceCapabilities',a.timeout,a.soap11)
  variants(log,'EVENTS','GetEventProperties',services['events'],'<tev:GetEventProperties/>',TEV+'/GetEventProperties',a.timeout,a.soap11)
  if a.rtsp_port in inventory['open_ports']:
   for path in ['/live/ch00_0','/live/ch00_1','/live/ch01_0','/live/ch01_1','/stream1','/stream2','/h264','/11','/12']:
    rtsp(log,a.host,a.rtsp_port,path,'OPTIONS',a.timeout);rtsp(log,a.host,a.rtsp_port,path,'DESCRIBE',a.timeout)
  variants(log,'NEGATIVE','UnknownProfile',services['ptz'],'<tptz:GetStatus><tptz:ProfileToken>__UNKNOWN__</tptz:ProfileToken></tptz:GetStatus>',TPTZ+'/GetStatus',a.timeout,a.soap11)
  variants(log,'NEGATIVE','UnknownNode',services['ptz'],'<tptz:GetNode><tptz:NodeToken>__UNKNOWN__</tptz:NodeToken></tptz:GetNode>',TPTZ+'/GetNode',a.timeout,a.soap11)
  log.add('FINAL','INVENTORY','INFO',json.dumps(inventory,indent=2,ensure_ascii=False));return 0
 finally:
  log.add('SYSTEM','LOG_PATH','INFO',str(log.path));log.close();print('\nLOG FILE:',log.path)
if __name__=='__main__':raise SystemExit(main())
