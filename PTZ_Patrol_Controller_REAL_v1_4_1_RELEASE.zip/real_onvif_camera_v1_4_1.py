#!/usr/bin/env python3
"""Real ONVIF SOAP 1.2 backend for PTZ Patrol Controller REAL v1.4.1."""
from __future__ import annotations
import http.client, socket, time, urllib.parse, xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional
SOAP='http://www.w3.org/2003/05/soap-envelope';TDS='http://www.onvif.org/ver10/device/wsdl';TRT='http://www.onvif.org/ver10/media/wsdl';TPTZ='http://www.onvif.org/ver20/ptz/wsdl';TT='http://www.onvif.org/ver10/schema'
def esc(s):return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def local(t):return t.rsplit('}',1)[-1]
def envelope(body):return f'<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'
def texts(root,n):return [(e.text or '').strip() for e in root.iter() if local(e.tag)==n and (e.text or '').strip()]
def tokens(root,names):
 out=[]
 for e in root.iter():
  if local(e.tag) in names:
   v=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
   if v and v not in out:out.append(v)
 return out
@dataclass
class PTZStatus:
 pan:Optional[float]=None;tilt:Optional[float]=None;zoom:Optional[float]=None;pan_tilt_state:str='UNKNOWN';zoom_state:str='UNKNOWN';camera_utc:str='';received_at:float=0.0
class OnvifError(RuntimeError):pass
class RealOnvifCamera:
 def __init__(self,host,port=8899,rtsp_port=554,timeout=5.0,logger:Optional[Callable[[str],None]]=None):
  self.host=host;self.port=int(port);self.rtsp_port=int(rtsp_port);self.timeout=float(timeout);self.logger=logger;self.device=f'http://{host}:{port}/onvif/device_service';self.media=f'http://{host}:{port}/onvif/media_service';self.ptz=f'http://{host}:{port}/onvif/ptz_service';self.profiles=[];self.ptz_configs=[];self.connected=False;self.last_status=PTZStatus();self.device_info={};self.last_latency_ms=None
 def log(self,s):
  if self.logger:self.logger(s)
 def call(self,url,operation,body):
  u=urllib.parse.urlparse(url);xml=envelope(body);c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=self.timeout);start=time.monotonic()
  try:c.request('POST',u.path or '/',xml.encode('utf-8'),{'Content-Type':'application/soap+xml; charset=utf-8','Connection':'close','User-Agent':'PTZ-Patrol-REAL/1.4.1'});r=c.getresponse();raw=r.read(2097152).decode('utf-8',errors='replace')
  except Exception as e:self.connected=False;raise OnvifError(f'{operation}: {type(e).__name__}: {e}') from e
  finally:c.close()
  self.last_latency_ms=int((time.monotonic()-start)*1000);self.log(f'{operation} HTTP {r.status} {self.last_latency_ms} ms')
  try:root=ET.fromstring(raw)
  except Exception as e:raise OnvifError(f'{operation}: non-XML HTTP {r.status}: {e}') from e
  if any(local(e.tag)=='Fault' for e in root.iter()):raise OnvifError(f'{operation}: SOAP Fault: '+(' | '.join(texts(root,'Text')+texts(root,'Value')) or 'unspecified'))
  if r.status>=400:raise OnvifError(f'{operation}: HTTP {r.status}')
  return root
 def connect(self):
  info=self.call(self.device,'GetDeviceInformation','<tds:GetDeviceInformation/>');self.device_info={n:(texts(info,n) or [''])[0] for n in ('Manufacturer','Model','FirmwareVersion','SerialNumber','HardwareId')}
  caps=self.call(self.device,'GetCapabilities','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>');xs=texts(caps,'XAddr');self.media=next((x for x in xs if 'media' in x.lower() and 'media2' not in x.lower()),self.media);self.ptz=next((x for x in xs if 'ptz' in x.lower()),self.ptz)
  prof=self.call(self.media,'GetProfiles','<trt:GetProfiles/>');self.profiles=tokens(prof,{'Profiles','Profile'});self.ptz_configs=tokens(prof,{'PTZConfiguration'})
  if not self.profiles:raise OnvifError('camera returned no ProfileToken')
  self.connected=True;self.status();return self.describe()
 def describe(self):return {'host':self.host,'device':self.device,'media':self.media,'ptz':self.ptz,'profiles':self.profiles,'ptz_configs':self.ptz_configs,'device_info':self.device_info}
 def profile(self):
  if not self.profiles:self.connect()
  return self.profiles[0]
 def system_time(self):
  root=self.call(self.device,'GetSystemDateAndTime','<tds:GetSystemDateAndTime/>');utc=''
  for e in root.iter():
   if local(e.tag)=='UTCDateTime':
    d={local(x.tag):(x.text or '') for x in e.iter()};utc=f"{d.get('Year','')}-{int(d.get('Month','0')):02d}-{int(d.get('Day','0')):02d}T{int(d.get('Hour','0')):02d}:{int(d.get('Minute','0')):02d}:{int(d.get('Second','0')):02d}Z";break
  skew=None
  try:skew=(datetime.fromisoformat(utc.replace('Z','+00:00'))-datetime.now(timezone.utc)).total_seconds()
  except Exception:pass
  return utc,skew
 def status(self):
  root=self.call(self.ptz,'GetStatus',f'<tptz:GetStatus><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken></tptz:GetStatus>');s=PTZStatus(received_at=time.time())
  for e in root.iter():
   n=local(e.tag)
   if n=='PanTilt' and 'x' in e.attrib:s.pan=float(e.attrib['x']);s.tilt=float(e.attrib.get('y',0))
   elif n=='Zoom' and 'x' in e.attrib:s.zoom=float(e.attrib['x'])
   elif n=='MoveStatus':
    for c in e:
     if local(c.tag)=='PanTilt':s.pan_tilt_state=(c.text or '').strip()
     elif local(c.tag)=='Zoom':s.zoom_state=(c.text or '').strip()
   elif n=='UtcTime':s.camera_utc=(e.text or '').strip()
  self.last_status=s;return s
 def stop(self):self.call(self.ptz,'Stop',f'<tptz:Stop><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>')
 def continuous_move(self,pan,tilt,zoom=0.0,duration=.20):
  pan=max(-1,min(1,float(pan)));tilt=max(-1,min(1,float(tilt)));zoom=max(-1,min(1,float(zoom)));duration=max(.05,min(2,float(duration)));body=f'<tptz:ContinuousMove><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Velocity></tptz:ContinuousMove>'
  try:self.call(self.ptz,'ContinuousMove',body);time.sleep(duration)
  finally:self.stop()
 def absolute_move(self,pan,tilt,zoom=0.0,speed=.5):
  pan=max(-1,min(1,float(pan)));tilt=max(-1,min(1,float(tilt)));zoom=max(0,min(1,float(zoom)));speed=max(.01,min(1,float(speed)));body=f'<tptz:AbsoluteMove><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:Position><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Position><tptz:Speed><tt:PanTilt x="{speed}" y="{speed}"/><tt:Zoom x="{speed}"/></tptz:Speed></tptz:AbsoluteMove>';self.call(self.ptz,'AbsoluteMove',body)
