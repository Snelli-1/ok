PTZ PATROL CONTROLLER REAL v1.4.1
=================================
Adds software hard boundaries and press-and-hold manual control to v1.4.0.

Pan boundary model
- Zero/reference is step 0.
- Default hard bounds are -26 steps left and +26 steps right.
- 52 measured clicks per 360 degrees, therefore 6.9230769 degrees per step.
- The controller never sends another manual Pan pulse after the estimated hard bound.
- The radar line and displayed counter are clamped inside the same bounds.
- Status shows current signed step, left steps remaining, and right steps remaining.
- SET +/- LIMITS can reduce the limit per camera from 26 steps.

Press-and-hold
- Pressing Left/Right/Up/Down starts repeated 0.20 s ContinuousMove + Stop pulses.
- Further pulses continue while the mouse button remains pressed.
- Releasing the button stops repeat generation and issues a final Stop.
- Manual hold temporarily overrides/skips automatic patrol for that camera.
- Emergency Stop remains global.

Accuracy warning
No reliable servo encoder or motor-step data was exposed by ONVIF or the tested firmware.
The counter is a bounded software estimate. Camera reboot, movement from another app,
network failure, or a failed Stop makes physical position uncertain; recalibrate at zero.
