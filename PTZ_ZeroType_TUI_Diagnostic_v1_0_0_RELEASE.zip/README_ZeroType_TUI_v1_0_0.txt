PTZ ZERO-TYPE TUI DIAGNOSTIC v1.0.0
===================================

This is a completely separate Windows 10 Pro diagnostic. It does not import the patrol
GUI, does not use MockCameraBridge, and does not depend on patrol stable steps.

SAFETY MODEL
------------
- Private/local IPs only.
- Read-only by default.
- No password guessing or credential lists.
- No CVE/exploit checks.
- No reboot, reset, user change, configuration write, preset creation/deletion.
- Motion exists only behind --arm-motion and is bounded to 0.20 s with Stop checkpoints.

INSTALL
-------
py -3 -m pip install onvif-zeep zeep
Optional for stream decoding: install FFmpeg and ensure ffprobe.exe is on PATH.
Optional modern second library: py -3 -m pip install onvif-python
Note: onvif-zeep and onvif-python can expose overlapping module names. The script logs
which API imported and never treats an import failure as camera failure.

READ-ONLY RUN
-------------
py -3 PTZ_ZeroType_TUI_Diagnostic_v1_0_0.py --host 192.168.1.102 --username admin --password "YOUR_PASSWORD"

ARMED TEST ONLY AFTER REVIEW
----------------------------
py -3 PTZ_ZeroType_TUI_Diagnostic_v1_0_0.py --host 192.168.1.102 --username admin --password "YOUR_PASSWORD" --arm-motion

RETURN THIS FILE
----------------
zero_type_logs\ZERO_TYPE_ALL_IN_ONE_192.168.1.102_*.txt

CODE GUIDE
----------
Z000 response received / stage passed
Z101 TCP/host connection failed
Z102 timeout
Z103 ARP/MAC unavailable
Z104 no matching WS-Discovery reply
Z201 authentication rejected
Z202 HTTP/HTTPS probe failed
Z203 raw ONVIF endpoint probe failed
Z204 ONVIF client construction failed
Z205 GetDeviceInformation failed
Z206 onvif-zeep unavailable
Z207 modern onvif-python unavailable or API-name conflict
Z210 no authenticated ONVIF client, dependent stages skipped
Z301 media service creation failed
Z302 GetProfiles failed
Z303 GetStreamUri failed
Z304 GetSnapshotUri failed
Z401 RTSP OPTIONS failed
Z402 ffprobe stream validation failed
Z403 ffprobe missing
Z501 PTZ service creation failed
Z502 GetNodes failed
Z503 GetConfigurations failed
Z504 GetStatus/position failed
Z505 GetPresets failed
Z506 PTZ prerequisites absent
Z601 motion not armed
Z602 motion prerequisites absent
Z603 Stop failed
Z604 bounded ContinuousMove failed
Z900 other method-specific failure

METHOD SOURCES STUDIED
----------------------
- nirsimetri/onvif-python: WS-Discovery, ONVIFClient, Device, Media and PTZ service APIs.
- FalkTannhaeuser/python-onvif-zeep lineage: ONVIFCamera service-proxy pattern.
- valkka-onvif documentation: explicit WSDL/service endpoint ordering.
- ONVIF standard service operations: Device -> Media/Profile -> URI -> PTZ metadata/state.
- Common camera diagnostics: HTTP banner, RTSP OPTIONS, ffprobe validation.

“Every GitHub method” cannot be made finite or safe: repositories include credential
bruteforce, factory reset, exploits, shells, stream modification and destructive actions.
This implementation covers the legitimate, read-only interoperability methods and a
separately armed bounded PTZ test. It deliberately excludes destructive/offensive methods.
