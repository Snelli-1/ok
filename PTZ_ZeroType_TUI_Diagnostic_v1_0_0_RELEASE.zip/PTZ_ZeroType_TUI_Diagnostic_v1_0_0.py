#!/usr/bin/env python3
"""PTZ Zero-Type TUI Diagnostic v1.0.0 for Windows 10 Pro.
Authorized local-device diagnostics only. No password guessing, exploits, reset, reboot,
configuration writes, or unbounded movement. Read-only unless --arm-motion is supplied.
"""
from __future__ import annotations
import argparse, base64, concurrent.futures, hashlib, http.client, ipaddress, json, os, platform
import re, shutil, socket, subprocess, sys, threading, time, traceback, urllib.parse, uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

VERSION="1.0.0"
DEFAULT_PORTS=[80,81,88,443,554,8000,8080,8081,8554,8899,2020,5000,34567,37777]
ONVIF_PATHS=["/onvif/device_service","/onvif/Device_service","/onvif/services","/device_service"]
RTSP_PATHS=["/","/live/ch00_0","/live/ch00_1","/Streaming/Channels/101","/Streaming/Channels/102","/cam/realmonitor?channel=1&subtype=0","/cam/realmonitor?channel=1&subtype=1","/h264Preview_01_main","/h264Preview_01_sub"]
C={"reset":"\x1b[0m","red":"\x1b[31m","green":"\x1b[32m","yellow":"\x1b[33m","cyan":"\x1b[36m","bold":"\x1b[1m"}
if os.name=="nt": os.system("")
LOCK=threading.Lock()

def redact(v:Any)->Any:
    if isinstance(v,dict): return {str(k):("<REDACTED>" if any(x in str(k).lower() for x in ["pass","auth","credential"]) else redact(x)) for k,x in v.items()}
    if isinstance(v,list): return [redact(x) for x in v]
    s=str(v)
    s=re.sub(r"(?i)(password|authorization)(\s*[:=]\s*)\S+",r"\1\2<REDACTED>",s)
    s=re.sub(r"(rtsp://[^:/\s]+:)[^@\s]+@",r"\1<REDACTED>@",s)
    return s[:12000]

def plain(v:Any,depth=0)->Any:
    if depth>5:return str(v)
    if v is None or isinstance(v,(str,int,float,bool)):return v
    if isinstance(v,(list,tuple)):return [plain(x,depth+1) for x in v]
    if isinstance(v,dict):return {str(k):plain(x,depth+1) for k,x in v.items()}
    if hasattr(v,"__dict__"):return {str(k):plain(x,depth+1) for k,x in vars(v).items() if not str(k).startswith("_")}
    return str(v)

@dataclass
class Event:
    seq:int; utc:str; elapsed_ms:int; phase:str; method:str; target:str; status:str; code:str; summary:str; evidence:Any

class TUI:
    def __init__(self,host:str,out:Path):
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); out.mkdir(parents=True,exist_ok=True)
        safe=re.sub(r"[^\w.-]","_",host); self.start=time.monotonic(); self.seq=0; self.events=[]
        self.txt=out/f"ZERO_TYPE_ALL_IN_ONE_{safe}_{stamp}.txt"; self.jsonl=out/f"ZERO_TYPE_EVENTS_{safe}_{stamp}.jsonl"
        self.txt.write_text(self.header(host),encoding="utf-8")
    def header(self,h):return f"""PTZ ZERO-TYPE TUI DIAGNOSTIC v{VERSION}\nTarget: {h}\nStarted UTC: {datetime.now(timezone.utc).isoformat()}\n\nPURPOSE\nProve each link layer in strict chronological order. A later phase never runs before its prerequisite.\nPASS means a response was received. FAIL means attempted and rejected/timeout. SKIP means prerequisite absent.\nRead-only by default. No credential guessing, exploits, reboot, reset, or configuration changes.\n\nORDER\n00 safety -> 01 host -> 02 ARP/MAC -> 03 WS-Discovery -> 04 TCP -> 05 HTTP fingerprints ->\n06 raw ONVIF endpoint -> 07 authenticated ONVIF library A -> 08 authenticated ONVIF library B ->\n09 media/profile/URI -> 10 RTSP OPTIONS -> 11 ffprobe -> 12 PTZ read-only -> 13 optional bounded motion -> 14 conclusion.\n\n"""
    def phase(self,n,name):
        line=f"\n{'='*78}\nPHASE {n:02d}: {name}\n{'='*78}\n"; print(C['bold']+C['cyan']+line+C['reset']); self.txt.open("a",encoding="utf-8").write(line)
    def add(self,phase,method,target,status,code,summary,evidence=None,start=None):
        with LOCK:
            self.seq+=1; ev=Event(self.seq,datetime.now(timezone.utc).isoformat(),int(((time.monotonic() if start is None else time.monotonic())-(start if start is not None else self.start))*1000),phase,method,target,status,code,str(redact(summary)),redact(plain(evidence)))
            self.events.append(ev); color=C['green'] if status=="PASS" else C['yellow'] if status in ("INFO","SKIP") else C['red']
            line=f"[{ev.seq:03d}] {phase:<12} {method:<31} {status:<4} {code:<6} {ev.elapsed_ms:>6} ms | {ev.summary}"
            print(color+line+C['reset'])
            with self.txt.open("a",encoding="utf-8") as f:f.write(line+"\n"+(json.dumps(ev.evidence,ensure_ascii=False,indent=2,default=str)+"\n" if evidence is not None else ""))
            with self.jsonl.open("a",encoding="utf-8") as f:f.write(json.dumps(asdict(ev),ensure_ascii=False,default=str)+"\n")
    def finish(self,summary):
        self.phase(14,"CONCLUSION")
        with self.txt.open("a",encoding="utf-8") as f:f.write(json.dumps(redact(summary),ensure_ascii=False,indent=2)+"\n")
        print(C['bold']+f"\nALL-IN-ONE LOG: {self.txt}\nEVENT LOG:      {self.jsonl}"+C['reset'])

def attempt(ui,phase,method,target,fn,fail="Z900"):
    st=time.monotonic()
    try:r=fn();ui.add(phase,method,target,"PASS","Z000","response received",r,st);return True,r
    except socket.timeout as e:ui.add(phase,method,target,"FAIL","Z102",str(e),None,st)
    except Exception as e:
        s=str(e); code="Z201" if any(x in s.lower() for x in ["401","unauthorized","not authorized","authentication"]) else "Z301" if "not supported" in s.lower() else fail
        ui.add(phase,method,target,"FAIL",code,f"{type(e).__name__}: {s}",traceback.format_exc().splitlines()[-5:],st)
    return False,None

def run_cmd(cmd,timeout=12):
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout,creationflags=(subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0))
    return {"returncode":p.returncode,"stdout":p.stdout[-6000:],"stderr":p.stderr[-3000:]}
def tcp(host,p,t):
    with socket.create_connection((host,p),t) as s:return {"local":s.getsockname(),"remote":s.getpeername()}
def http_get(host,p,path,t):
    cls=http.client.HTTPSConnection if p==443 else http.client.HTTPConnection;c=cls(host,p,timeout=t)
    try:c.request("GET",path,headers={"User-Agent":f"PTZ-ZeroType/{VERSION}"});r=c.getresponse();b=r.read(2048);return {"status":r.status,"reason":r.reason,"headers":dict(r.getheaders()),"body_sha256":hashlib.sha256(b).hexdigest(),"preview":b[:500].decode(errors="replace")}
    finally:c.close()
def raw_onvif(host,p,path,t):
    body='''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body><tds:GetSystemDateAndTime xmlns:tds="http://www.onvif.org/ver10/device/wsdl"/></s:Body></s:Envelope>'''.encode()
    cls=http.client.HTTPSConnection if p==443 else http.client.HTTPConnection;c=cls(host,p,timeout=t)
    try:c.request("POST",path,body,{"Content-Type":"application/soap+xml; charset=utf-8","User-Agent":f"PTZ-ZeroType/{VERSION}"});r=c.getresponse();b=r.read(8192);return {"status":r.status,"reason":r.reason,"headers":dict(r.getheaders()),"xml":b.decode(errors="replace")}
    finally:c.close()
def rtsp_options(host,p,path,t,user,pwd):
    uri=f"rtsp://{host}:{p}{path}";s=socket.create_connection((host,p),t);s.settimeout(t)
    try:
        req=f"OPTIONS {uri} RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: PTZ-ZeroType/{VERSION}\r\n\r\n";s.sendall(req.encode());data=s.recv(8192).decode(errors="replace");return {"uri":uri,"reply":data}
    finally:s.close()
def ws_discovery(host,t):
    msg=f'''<?xml version="1.0" encoding="UTF-8"?><e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"><e:Header><w:MessageID>uuid:{uuid.uuid4()}</w:MessageID><w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To><w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header><e:Body><d:Probe/></e:Body></e:Envelope>'''.encode()
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.settimeout(t);s.sendto(msg,("239.255.255.250",3702));out=[]
    try:
        end=time.monotonic()+t
        while time.monotonic()<end:
            try:d,a=s.recvfrom(65535);text=d.decode(errors="replace");
            except socket.timeout:break
            if host in text or a[0]==host:out.append({"from":a,"xml":text})
    finally:s.close()
    if not out:raise TimeoutError("no matching WS-Discovery response")
    return out
def arp_mac(host):
    r=run_cmd(["arp","-a",host],6);m=re.search(r"(?:[0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}",r["stdout"])
    return {"mac":m.group(0).upper() if m else None,"raw":r}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--host",required=True);ap.add_argument("--username",default="admin");ap.add_argument("--password",default="")
    ap.add_argument("--timeout",type=float,default=3.0);ap.add_argument("--delay",type=float,default=.6);ap.add_argument("--ports",default=",".join(map(str,DEFAULT_PORTS)))
    ap.add_argument("--output",default="zero_type_logs");ap.add_argument("--arm-motion",action="store_true");ap.add_argument("--version",action="version",version=VERSION)
    a=ap.parse_args();a.timeout=max(.4,min(a.timeout,15));a.delay=max(.2,min(a.delay,5));ports=sorted(set(int(x) for x in a.ports.split(",") if x.strip()))
    ip=ipaddress.ip_address(a.host)
    if not ip.is_private:raise SystemExit("Safety lock: only private/local IP addresses are accepted.")
    ui=TUI(a.host,Path(a.output));summary={"host":a.host,"open_ports":[],"xaddrs":[],"verified_onvif":False,"authenticated":False,"media":False,"ptz":False,"position":False,"presets":False,"rtsp_candidates":[],"recommended_next":"collect evidence"}
    ui.phase(0,"SAFETY AND RUNTIME");ui.add("safety","private_ip_lock",a.host,"PASS","Z000","private target accepted",{"python":sys.version,"platform":platform.platform(),"motion_armed":a.arm_motion})
    ui.phase(1,"HOST AND ROUTE");attempt(ui,"host","getaddrinfo",a.host,lambda:socket.getaddrinfo(a.host,None),"Z101");attempt(ui,"host","ping",a.host,lambda:run_cmd(["ping","-n" if os.name=="nt" else "-c","1",a.host],8),"Z101")
    ui.phase(2,"ARP AND MAC");attempt(ui,"identity","arp_table",a.host,lambda:arp_mac(a.host),"Z103")
    ui.phase(3,"WS-DISCOVERY");ok,disc=attempt(ui,"discovery","ws_discovery_multicast",f"{a.host}:3702/udp",lambda:ws_discovery(a.host,a.timeout),"Z104")
    if ok:
        for item in disc:
            summary["xaddrs"]+=re.findall(r"https?://[^<\s]+",item["xml"])
    ui.phase(4,"ORDERED TCP PORT TEST")
    for p in ports:
        ok,_=attempt(ui,"tcp",f"connect_{p}",f"{a.host}:{p}",lambda p=p:tcp(a.host,p,a.timeout),"Z101")
        if ok:summary["open_ports"].append(p)
        time.sleep(a.delay)
    ui.phase(5,"HTTP AND HTTPS FINGERPRINT")
    for p in summary["open_ports"]:
        if p in [80,81,88,443,8000,8080,8081,8899,2020,5000]:attempt(ui,"http",f"GET_root_{p}",f"{a.host}:{p}/",lambda p=p:http_get(a.host,p,"/",a.timeout),"Z202");time.sleep(a.delay)
    ui.phase(6,"RAW ONVIF ENDPOINT MATRIX")
    endpoints=[]
    candidate_ports=sorted(set([p for p in summary["open_ports"] if p not in [554,8554,34567,37777]]+[urllib.parse.urlparse(x).port or (443 if x.startswith("https") else 80) for x in summary["xaddrs"]]))
    for p in candidate_ports:
        for path in ONVIF_PATHS:
            ok,r=attempt(ui,"raw_onvif","GetSystemDateAndTime",f"{a.host}:{p}{path}",lambda p=p,path=path:raw_onvif(a.host,p,path,a.timeout),"Z203")
            if ok and ("Envelope" in str(r) or r.get("status") in [200,400,401,500]):endpoints.append((p,path));summary["verified_onvif"]=True
            time.sleep(a.delay)
    ui.phase(7,"ONVIF LIBRARY A: ONVIF-ZEEP")
    clients=[]
    try:
        from onvif import ONVIFCamera
        for p,_ in endpoints or [(p,"/onvif/device_service") for p in candidate_ports]:
            ok,cam=attempt(ui,"onvif_zeep","construct_client",f"{a.host}:{p}",lambda p=p:ONVIFCamera(a.host,p,a.username,a.password),"Z204")
            if not ok:continue
            ok,info=attempt(ui,"onvif_zeep","GetDeviceInformation",f"{a.host}:{p}",lambda cam=cam:cam.devicemgmt.GetDeviceInformation(),"Z205")
            if ok:clients.append((p,cam));summary["authenticated"]=True;break
    except Exception as e:ui.add("onvif_zeep","import","local","SKIP","Z206",f"onvif-zeep unavailable: {e}")
    ui.phase(8,"ONVIF LIBRARY B: MODERN ONVIF-PYTHON")
    try:
        from onvif import ONVIFClient
        for p,_ in endpoints:
            ok,client=attempt(ui,"onvif_python","construct_client",f"{a.host}:{p}",lambda p=p:ONVIFClient(host=a.host,port=p,username=a.username,password=a.password),"Z204")
            if ok:attempt(ui,"onvif_python","devicemgmt_service",str(p),lambda client=client:client.devicemgmt(),"Z205")
    except Exception as e:ui.add("onvif_python","import_or_api","local","SKIP","Z207",f"modern onvif-python API unavailable/conflicts with onvif-zeep: {e}")
    profiles=[];media=None;ptz=None
    ui.phase(9,"MEDIA, PROFILES, STREAM AND SNAPSHOT URI")
    if clients:
        p,cam=clients[0]
        ok,media=attempt(ui,"media","create_media_service",str(p),lambda:cam.create_media_service(),"Z301");summary["media"]=ok
        if ok:
            ok,profiles=attempt(ui,"media","GetProfiles",str(p),lambda:media.GetProfiles(),"Z302")
            if ok:
                for i,pr in enumerate(profiles):
                    token=str(getattr(pr,"token","") or getattr(pr,"_token",""));
                    attempt(ui,"media",f"GetStreamUri_profile_{i}",token,lambda token=token:media.GetStreamUri({"StreamSetup":{"Stream":"RTP-Unicast","Transport":{"Protocol":"RTSP"}},"ProfileToken":token}),"Z303")
                    attempt(ui,"media",f"GetSnapshotUri_profile_{i}",token,lambda token=token:media.GetSnapshotUri({"ProfileToken":token}),"Z304")
    else:ui.add("media","all_media_operations",a.host,"SKIP","Z210","no authenticated ONVIF client")
    ui.phase(10,"RTSP OPTIONS PATH MATRIX")
    for p in [x for x in summary["open_ports"] if x in [554,8554]]:
        for path in RTSP_PATHS:
            ok,r=attempt(ui,"rtsp",f"OPTIONS_{path[:22]}",f"{a.host}:{p}{path}",lambda p=p,path=path:rtsp_options(a.host,p,path,a.timeout,a.username,a.password),"Z401")
            if ok and "RTSP/1.0" in str(r):summary["rtsp_candidates"].append(f"rtsp://{a.host}:{p}{path}")
            time.sleep(a.delay)
    ui.phase(11,"FFPROBE STREAM VALIDATION")
    ffprobe=shutil.which("ffprobe")
    if ffprobe:
        for uri in summary["rtsp_candidates"][:12]:
            auth_uri=uri.replace("rtsp://",f"rtsp://{urllib.parse.quote(a.username)}:{urllib.parse.quote(a.password)}@",1)
            attempt(ui,"ffprobe","probe_stream",uri,lambda auth_uri=auth_uri:run_cmd([ffprobe,"-v","error","-rtsp_transport","tcp","-show_entries","stream=codec_name,width,height","-of","json",auth_uri],15),"Z402")
    else:ui.add("ffprobe","executable","PATH","SKIP","Z403","ffprobe not installed or not on PATH")
    ui.phase(12,"PTZ READ-ONLY CAPABILITY AND STATE")
    if clients and profiles:
        p,cam=clients[0];ok,ptz=attempt(ui,"ptz","create_ptz_service",str(p),lambda:cam.create_ptz_service(),"Z501");summary["ptz"]=ok
        if ok:
            attempt(ui,"ptz","GetNodes",str(p),lambda:ptz.GetNodes(),"Z502");attempt(ui,"ptz","GetConfigurations",str(p),lambda:ptz.GetConfigurations(),"Z503")
            for i,pr in enumerate(profiles):
                token=str(getattr(pr,"token","") or getattr(pr,"_token",""));ok_s,status=attempt(ui,"ptz",f"GetStatus_{i}",token,lambda token=token:ptz.GetStatus({"ProfileToken":token}),"Z504");summary["position"]|=bool(ok_s and getattr(status,"Position",None))
                ok_p,presets=attempt(ui,"ptz",f"GetPresets_{i}",token,lambda token=token:ptz.GetPresets({"ProfileToken":token}),"Z505");summary["presets"]|=bool(ok_p and presets)
    else:ui.add("ptz","read_only_matrix",a.host,"SKIP","Z506","missing authenticated client or media profile")
    ui.phase(13,"OPTIONAL BOUNDED MOTION")
    if not a.arm_motion:ui.add("motion","motion_matrix",a.host,"SKIP","Z601","not armed; read-only run")
    elif not (ptz and profiles):ui.add("motion","motion_matrix",a.host,"SKIP","Z602","PTZ/profile prerequisite absent")
    else:
        token=str(getattr(profiles[0],"token","") or getattr(profiles[0],"_token",""));attempt(ui,"motion","Stop_before",token,lambda:ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True}),"Z603")
        for speed in [.08,.18,.35]:
            def mv(speed=speed):
                ptz.ContinuousMove({"ProfileToken":token,"Velocity":{"PanTilt":{"x":speed,"y":0.0},"Zoom":{"x":0.0}}});time.sleep(.20);return ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True})
            attempt(ui,"motion",f"ContinuousMove_{speed:.2f}",token,mv,"Z604");time.sleep(1.2)
        attempt(ui,"motion","Final_Stop",token,lambda:ptz.Stop({"ProfileToken":token,"PanTilt":True,"Zoom":True}),"Z603")
    if summary["authenticated"] and summary["ptz"] and summary["presets"]:summary["recommended_next"]="verified ONVIF; configure preset-only first"
    elif summary["authenticated"] and summary["media"]:summary["recommended_next"]="ONVIF media works; PTZ absent/failed; inspect vendor/PTZ service"
    elif summary["verified_onvif"]:summary["recommended_next"]="ONVIF endpoint reached but auth/library failed; verify ONVIF user, password, clock, and service port"
    elif summary["rtsp_candidates"]:summary["recommended_next"]="RTSP evidence only; camera may expose video without ONVIF control"
    else:summary["recommended_next"]="no standard control link proven; use original app packet capture only with your own device, then add a verified vendor adapter"
    ui.finish(summary);return 0
if __name__=="__main__":raise SystemExit(main())
