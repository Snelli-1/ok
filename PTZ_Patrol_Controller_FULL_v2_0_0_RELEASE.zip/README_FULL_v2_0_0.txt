PTZ PATROL CONTROLLER v2.0.0-full
================================
This release uses the uploaded full v1.py as its base. It does not replace the
large v1 interface with the reduced v1.5 test dashboard.

RESTORED/PRESERVED V1 FEATURES
- Add, Discover, Delete, Probe, Save.
- Authorized LAN WS-Discovery dialog with QUICK/STANDARD/EXTENDED modes.
- ARP evidence, bounded candidate-port probing, ONVIF identity checks.
- Device classification, stable IDs, discovery reports and profile hints.
- Full patrol editor, presets, per-camera workers, mock mode and dry-run.
- Pause/resume, test one cycle, home, manual PTZ, global Emergency Stop.
- Eight camera/status tiles and configuration backup/atomic save behavior.

NEW VIDEO SYSTEM
- SELECTED and MULTIVIEW modes.
- Up to 8 independent live RTSP decoder workers.
- MAIN/SUB selection and automatic fallback to the other configured stream.
- Per-camera Video Settings dialog.
- Test Sources button reports whether an actual frame can be decoded.
- Explicit OPENING/LIVE/ERROR state per camera, never a false LIVE label.
- Credentials are injected at runtime and removed from displayed URIs.
- Video decoding never calls Tkinter and never sends PTZ commands.
- Clicking a tile selects the same camera for PTZ/patrol editing.
- Keys 1-8 select Camera 1-8.

FIRST START
1. Extract every file into one folder.
2. Run INSTALL_VIDEO_DEPENDENCIES.bat once.
3. Run RUN_FULL_v2_0_0.bat.
4. Select the real camera.
5. Open Video Settings and verify the exact MAIN/SUB RTSP paths.
6. Press Test Sources. At least one source must say FRAME OK.
7. Select Selected or Multiview and press Start Video.

DEFAULT VIDEO PATHS
MAIN: rtsp://CAMERA_IP:554/live/ch00_0
SUB:  rtsp://CAMERA_IP:554/live/ch00_1
These defaults fit the camera information available in this project. If camera
firmware uses another path, Video Settings stores the correct per-camera path in
runtime/video_sources.json without exposing credentials in GUI status text.

IMPORTANT
- The included config defaults remain mock_mode=true and dry_run=true.
- Real PTZ still follows the full v1 bridge/config design. Configure and test the
  companion ptz_commands.bat/CLI templates before disabling the safety defaults.
- This environment could perform Python syntax/AST and static integration tests,
  but cannot open Tk because the Linux test container lacks _tkinter. Windows
  Python normally includes Tkinter. Final GUI/video behavior must be verified on
  the target Windows computer and real camera.
