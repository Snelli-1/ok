@echo off
setlocal
cd /d "%~dp0"
echo Installing/upgrading video dependencies...
py -3 -m pip install --upgrade pip
py -3 -m pip install --upgrade pillow opencv-python
if errorlevel 1 (
  echo Installation failed. Check Internet access and Python installation.
  pause
  exit /b 1
)
echo Video dependencies installed successfully.
pause
endlocal
