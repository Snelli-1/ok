from pathlib import Path
import ast, re, sys
p=Path(__file__).with_name('PTZ_Patrol_Controller_FULL_v2_0_0.py')
s=p.read_text(encoding='utf-8')
ast.parse(s)
checks={
 'full_v1_discovery':'class DiscoveryDialog' in s and 'class DiscoveryWorker' in s,
 'main_gui':'class PTZPatrolGUI' in s,
 'enhanced_gui':'class EnhancedPTZPatrolGUI' in s,
 'multiview':'value="MULTIVIEW"' in s and 'MAX_PREVIEW_TILES' in s,
 'selected_view':'value="SELECTED"' in s,
 'video_worker':'class LiveVideoWorker' in s and 'cv2.VideoCapture' in s,
 'main_sub_fallback':'self.source.main_uri' in s and 'self.source.sub_uri' in s,
 'source_test':'def _test_video_sources' in s,
 'safe_uri':'def _safe_video_uri' in s,
 'emergency_stop':'def _on_emergency_stop' in s,
 'atomic_config':'os.replace(str(tmp_path), str(path))' in s,
 'v2_instantiated':'app = EnhancedPTZPatrolGUI(cfg, doc, issues)' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
failed=[k for k,v in checks.items() if not v]
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
