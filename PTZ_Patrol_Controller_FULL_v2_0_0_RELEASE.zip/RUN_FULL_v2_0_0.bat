@echo off
setlocal
cd /d "%~dp0"
py -3 PTZ_Patrol_Controller_FULL_v2_0_0.py
if errorlevel 1 pause
endlocal
