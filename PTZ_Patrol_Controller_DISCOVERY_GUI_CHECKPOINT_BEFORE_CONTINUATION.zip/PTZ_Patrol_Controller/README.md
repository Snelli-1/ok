# PTZ Patrol Controller

A local-first Windows desktop application that runs independent, repeating
PTZ ("pan / tilt / zoom") patrol loops on multiple ONVIF cameras over your
LAN — the capability missing from viewer apps like Onvier or tinyCam, which
can drive a camera manually but can't run a reusable cyclic patrol such as
"MAIN for 2 min, LEFT for 15 s, MAIN for 2 min, RIGHT for 15 s, repeat
forever" independently per camera.

**This tool supervises lower-priority blind spots. It does not replace
fixed cameras at entrances, cash points, or any other critical area** — a
single PTZ camera on patrol is, by definition, not looking at the rest of
its range while it's parked on one preset.

## Status

This is a working **compact prototype**:

- The Tkinter GUI, config system, threading/patrol engine, and **mock
  mode are fully functional** and have been exercised with an automated
  self-test (`--mock-test`, 10/10 checks passing, including a
  Pillow-removed run — see "Validation performed" below).
- **Real-camera control goes through an external ONVIF CLI tool that you
  install and configure** (see "Switching from mock mode to a real
  camera"). That bridge is structurally complete and has been reviewed
  carefully, but the exact command syntax is a placeholder until you fill
  it in and test it — no specific ONVIF CLI's syntax is assumed or
  invented here.
- The BAT file was authored and statically reviewed (labels, argument
  order, quoting, and the `RESULT:` output contract were all cross-checked
  against the Python source) but **has not been executed on a real
  Windows machine** as part of building this project — only Python was
  available for that. Run `ptz_commands.bat diagnose` and one manual
  `probe` call first, before relying on it.
- `config.txt` ships with **`dry_run = true`, `mock_mode = true`, `[CLI]
  enabled = false`**, so the whole application is safe to explore with no
  camera and no ONVIF CLI installed.

## Requirements

- Windows 10 or 11.
- Python 3.10 or newer from [python.org](https://www.python.org/downloads/windows/)
  — during install, keep **"tcl/tk and IDLE"** checked (this is what
  provides `tkinter`; it's included by default).
- Optional: [Pillow](https://pypi.org/project/pillow/), only for decoding
  camera preview-tile snapshot images. Everything else, including mock
  mode and `--mock-test`, works with zero third-party packages — this was
  verified directly by running the app with Pillow removed.

## Install

Open a command prompt in the project folder (the one containing
`ptz_patrol_gui.py`):

```bat
py -3 -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

If `py` is not recognized, use `python` instead of `py -3` throughout this
document.

## First run (mock mode — safe, no camera needed)

```bat
python ptz_patrol_gui.py
```

or, using the BAT bridge:

```bat
ptz_commands.bat run
```

`config.txt` is created automatically on first run if it doesn't exist
yet, already set to `dry_run = true` / `mock_mode = true` with three demo
cameras (see "The three mock cameras" below). Select a camera in the left
list, press **Start** in the patrol editor, and watch its tile in the
bottom-right grid cycle through states — nothing on your network is
touched.

## Command-line options

```bat
python ptz_patrol_gui.py                 REM normal GUI start
python ptz_patrol_gui.py --version       REM print version and exit
python ptz_patrol_gui.py --check-config  REM validate config.txt only, no GUI, no network
python ptz_patrol_gui.py --diagnose      REM validate config.txt + TCP-reachability check per camera, no GUI
python ptz_patrol_gui.py --mock-test     REM headless, finite self-test of the mock engine (~15-20s)
```

None of these open a window; all are safe to run with no camera attached.
`--diagnose` opens a plain TCP connection to each configured camera's
ONVIF port to check reachability only — it sends no credentials and no
ONVIF request.

## ptz_commands.bat — the one BAT file

```bat
ptz_commands.bat run                                    REM launch the GUI (refuses a duplicate launch)
ptz_commands.bat stop                                    REM ask a running GUI to shut down gracefully
ptz_commands.bat restart                                 REM stop, then run
ptz_commands.bat diagnose                                REM same as --diagnose above, with its own exit code

ptz_commands.bat probe        CAMERA_ID                  REM read capabilities (no movement)
ptz_commands.bat services     CAMERA_ID
ptz_commands.bat profiles     CAMERA_ID
ptz_commands.bat presets      CAMERA_ID
ptz_commands.bat status       CAMERA_ID
ptz_commands.bat goto         CAMERA_ID PRESET_TOKEN
ptz_commands.bat move         CAMERA_ID PAN TILT ZOOM TIMEOUT_S
ptz_commands.bat stop-camera  CAMERA_ID
ptz_commands.bat home         CAMERA_ID
ptz_commands.bat snapshot     CAMERA_ID OUTPUT_FILE
```

The ten camera-bridge commands are normally invoked by `ptz_patrol_gui.py`
itself (one bounded call per camera action — never a loop, never a
patrol), but are safe to run by hand from a command prompt for testing,
once `[CLI]` is configured (see below). `CAMERA_ID` is the stable ID from
`config.txt`, e.g. `cam_entrance`, not the display name.

Every camera-bridge call prints exactly one final line that
`ptz_patrol_gui.py` parses:

```
RESULT:OK:NONE:<message>
RESULT:ERROR:<CATEGORY>:<message>
```

`run` launches the GUI with `pyw`/`pythonw` when available (no console
window) and never re-launches itself for a camera command — camera
commands always go through the `probe`/`goto`/`move`/... branch, never
through `run`. The BAT file finds Python via `py -3` first, then `python`.
It creates `logs\`, `runtime\`, and `diagnostics\` on first use if they
don't exist, and never prints a password: the one secret involved reaches
it only as the short-lived `ONVIF_PASSWORD` environment variable (cleared
again immediately after that one external call), never written to
`runtime\cli_cache.txt` or echoed anywhere.

## The three mock cameras

`config.txt` ships with three cameras, all using `adapter = auto` (which
resolves to the fully-simulated mock engine while `mock_mode = true`):

| ID | `mock_profile` | What it demonstrates |
|---|---|---|
| `cam_entrance` | `full` | Everything works: presets, status, a 4-step patrol (MAIN/LEFT/MAIN/RIGHT). |
| `cam_gate` | `intermittent` | Periodically fails and reconnects on its own — watch it recover while `cam_entrance` keeps running untouched. |
| `cam_side` | `limited` | Presets work, but `GetStatus` reports no Absolute/Relative/ContinuousMove support, like some real low-end firmware. |

Patrol dwell times are short (a few seconds) on purpose so you can see
state changes immediately instead of waiting minutes.

## The GUI

**Left panel** — scrollable camera list (enabled flag, stable ID, name,
host:port, live connection state), Add / Discover / Delete / Probe / Save
buttons, then a manual PTZ pad (▲▼◀▶, center **STOP**, separate **Home**,
speed slider) below it for whichever camera is selected.

**Upper-right panel** — the patrol editor: one row per step (enabled,
action, target preset / pan-tilt-zoom, move/settle/dwell seconds, and
reorder/duplicate/delete buttons), Add Step, Enable Automation, repeat
Forever/Fixed-count, and the run controls: Test One Cycle, Start, Pause
(with a selectable duration), Resume, Stop, Return Home, Save
Configuration.

**Lower-right panel** — up to 8 status tiles in a 4×2 grid: camera name,
live connection/worker state, current step, next-action countdown, and
(when `[PREVIEW] mode` isn't `off`) a snapshot image on click.

**Bottom bar** — enabled/connected/running/paused/offline counts, the
current MOCK/LIVE and DRY-RUN/ARMED mode, the last error, and a large red
**EMERGENCY STOP**.

**Discover** is honest about a real limitation: live ONVIF WS-Discovery
is not implemented in this compact version (no CLI syntax for it has been
verified), so it shows a short explanation instead of pretending to
scan your network. Add cameras manually, then use **Probe** once `[CLI]`
is configured.

## Manual PTZ — press-and-hold, dead-man protected

Pressing an arrow pauses that camera's patrol, sends one bounded
~0.5-second move, and refreshes it roughly every 0.35s while held.
Releasing, the mouse leaving the button, the button losing focus, or
closing the app all send an explicit **Stop**. The worker itself also
auto-Stops if 1.5s pass with no refresh — a lost `ButtonRelease` event
can't leave a camera moving.

## Patrol steps

Each step in `config.txt` is one `key=value;key=value` line:

```ini
step_1 = action=GOTO_PRESET;target=MAIN;settle_s=1;dwell_s=8;enabled=true
step_2 = action=GOTO_PRESET;target=LEFT;settle_s=1;dwell_s=4;enabled=true
step_3 = action=CONTINUOUS_MOVE;pan=0.20;tilt=0.00;zoom=0.00;move_s=4;settle_s=1;dwell_s=5;enabled=true
step_4 = action=WAIT;dwell_s=5;enabled=true
step_5 = action=STOP;dwell_s=1;enabled=true
step_6 = action=GOTO_HOME;settle_s=1;dwell_s=5;enabled=true
```

Supported actions: `GOTO_PRESET`, `WAIT`, `CONTINUOUS_MOVE`, `STOP`,
`GOTO_HOME`. `move_s`, `settle_s`, and `dwell_s` are always seconds and
always kept separate. Every `CONTINUOUS_MOVE` is bounded (`move_s` is
required and capped) and is **always** followed internally by an explicit
Stop — regardless of what the external CLI already does — so a camera
can never be left drifting. `arrival_policy` (per camera) defaults to
`fixed_settle`: dwell begins after `settle_s` elapses, not at a confirmed
arrival, unless you know your camera's status reporting is reliable
enough to use `status_idle` instead.

## config.txt

The only authoritative, user-editable configuration file, INI-style. Key
sections: `[META]`, `[APPLICATION]` (`dry_run`, `mock_mode`, log
settings), `[SECURITY]`, `[PREVIEW]`, `[MANUAL_OVERRIDE]`, `[CLI]`,
`[SHUTDOWN]`, then per camera: `[CAMERA_<id>]`, `[CAMERA_<id>_PRESETS]`,
`[CAMERA_<id>_CALIBRATION]` (placeholders for a future time-calibrated
fallback — intentionally unused and disabled by default in this version),
and `[PATROL_<name>]`.

**Stable camera IDs**: the section name suffix (`CAMERA_cam_entrance`)
and the `id = cam_entrance` key inside it must match. This ID is used for
logs (`logs/camera_<id>.log`), the `runtime/cli_cache.txt` entries, GUI
selection, and diagnostic report filenames — renaming the *display* `name`
never breaks any of that.

**Saving**: clicking Save (either Save button) stops every worker, writes
a temp file, re-parses and re-validates *that* temp file, takes a
timestamped backup of the current `config.txt` into `runtime/backups/`,
then atomically replaces `config.txt` — only after all of that succeeds.
If validation fails, your original `config.txt` is left completely
untouched and you get a specific `[SECTION] key: 'value' -- reason`
error. Comments, section order and unknown keys are preserved on save;
only the lines the GUI actually manages are rewritten.

## Switching from mock mode to a real camera

1. In `config.txt`, confirm the candidate ONVIF port. **ONVIF and RTSP
   are different ports** — the sketch this project started from showed
   `8899`, but that's only ever a starting guess, never assumed correct;
   RTSP is typically `554`. Check your camera's own documentation or app.
2. Create a **restricted ONVIF account** on the camera rather than using
   its administrator login, if the camera supports it.
3. Install and verify an external ONVIF CLI (onvif-python's CLI, Easy
   ONVIF CLI, `camelcamro/onvif_control`, or another) **by itself, at a
   command prompt, before touching this project** — confirm its exact
   argument syntax.
4. Fill in `[CLI]` in `config.txt`: `enabled = true`, `executable = ...`,
   and the `*_template` keys, using these placeholders exactly as
   written: `{executable} {host} {onvif_port} {username} {password}
   {profile_token} {preset_token} {pan} {tilt} {zoom} {timeout_s}
   {output_file}`. For example:
   ```ini
   goto_template = {executable} goto --host {host} --port {onvif_port} --user {username} --pass {password} --profile {profile_token} --preset {preset_token}
   ```
   `{password}` is special: it is substituted only at the last moment,
   from the `ONVIF_PASSWORD` environment variable, directly by
   `ptz_commands.bat` — it is never written to `runtime/cli_cache.txt`.
5. Set that camera's `adapter = cli` (or leave `auto` and set the global
   `mock_mode = false` once you're ready to move every camera off mock).
6. **Test one preset safely**: with `dry_run` still `true`, select the
   camera, click **Probe** first and read the report under
   `diagnostics/`. Only once that looks right, set `dry_run = false`,
   select one preset in the manual area or add one `GOTO_PRESET` step and
   use **Test One Cycle** — you'll be asked to confirm before anything
   moves for real.
7. Keep `dry_run = true` on any camera/template you haven't verified yet;
   it blocks `goto`/`move`/`home` from being sent for real while still
   allowing read-only probing. **Stop is always sent regardless of
   `dry_run`** — Stop can't move a camera, so blocking it would only make
   the system less safe, not more.

**Reverting to mock mode** at any time: set `mock_mode = true` (or that
camera's `adapter = mock`) and Save — no need to remove your `[CLI]`
configuration, it's simply not used while mocked.

**V380 Pro / WET2440 note**: this camera family varies significantly
between firmware builds and sellers. Nothing here assumes ONVIF behavior
from the model name — **Probe** before trusting any capability, and
expect to need firmware-specific adjustments to your CLI templates.

## Capability probe

**Probe** (left panel) runs read-only `GetServices` / `GetProfiles` /
`GetPresets` / `GetStatus`-equivalent calls for the selected camera and
saves a redacted JSON + human-readable TXT report under `diagnostics/`,
including a recommended automation tier (presets → absolute/relative →
bounded continuous-move → "estimation required", in that preference
order) and warnings. It never changes camera firmware or settings. In
mock mode this is fully populated; in CLI mode, fields stay blank/default
until your configured CLI's real output is parsed — this project doesn't
invent a parser for a tool's output format it hasn't seen.

## Emergency Stop and shutdown

The red **EMERGENCY STOP** immediately interrupts every camera's current
wait (settle or dwell) and sends Stop to all of them in parallel — one
thread per camera, never two threads sharing one camera's connection.
Closing the window (or `ptz_commands.bat stop`, which writes
`runtime/stop.request` for a running GUI to notice) does the same, then
optionally returns each camera to its home preset if `[SHUTDOWN]
return_home_on_stop = true`, saves non-sensitive runtime state (no
credentials) to `runtime/state.json`, and joins every worker thread with
a bounded timeout before closing.

## Logs and diagnostics

```
logs/application.log          general application log (GUI session only)
logs/camera_<id>.log          one rotating log per camera
logs/startup.log              captures failures even before normal logging is up
logs/diagnostics.log          activity log for --diagnose / --check-config / --mock-test
diagnostics/probe_<id>_*.json / .txt   capability probe reports
diagnostics/diagnose_*.txt            --diagnose / `ptz_commands.bat diagnose` reports
runtime/state.json             non-sensitive state saved on shutdown
runtime/backups/config_*.txt.bak      timestamped config.txt backups
runtime/cli_cache.txt          BAT-readable CLI config (never contains the password)
```

Passwords, and anything that happens to echo one back from an external
CLI's output, are redacted before being written to any of these files.

## Troubleshooting

- **"already running"**: check `runtime/app.pid`; if the app really
  isn't running, delete that file and try again.
- **A camera won't connect**: run `ptz_commands.bat diagnose` (or
  `--diagnose`) first — it checks plain TCP reachability to the
  configured ONVIF port with no credentials involved, which rules out
  basic network/firewall/wrong-port problems before you debug ONVIF
  itself.
- **Save refuses to apply a change**: the error message names the exact
  `[section] key` and why; your `config.txt` on disk is guaranteed
  unchanged until that's fixed.
- **Recovering after a camera drops mid-patrol**: this is automatic —
  the worker moves to `RECOVERING`, backs off and retries on its own,
  then sends Stop, optionally returns home, and resumes per your
  `[MANUAL_OVERRIDE] resume_policy` once reconnected.

## Known limitations

- Live ONVIF WS-Discovery is not implemented (see "Discover" above).
- `ptz_commands.bat` has been statically reviewed but not executed on a
  real Windows machine as part of this build.
- The real-camera CLI bridge is structurally complete but not proven
  against any specific camera; expect to iterate on your `[CLI]`
  templates.
- The time-calibrated fallback position estimator described in the
  original planning notes is **not implemented** in this compact
  version — only presets (and, once templates are verified,
  absolute/relative/bounded-continuous movement) are supported. Its
  config placeholders exist (`[CAMERA_<id>_CALIBRATION]`) but stay
  disabled.
- This tool is for periodic observation of lower-priority blind spots —
  **it does not replace fixed cameras at entrances or other critical
  areas.**

## Validation performed

Run directly, in order, from a clean checkout:

```
python3 -m py_compile ptz_patrol_gui.py     -> passed
python3 ptz_patrol_gui.py --version         -> passed
python3 ptz_patrol_gui.py --check-config    -> 0 errors, 0 warnings against this config.txt
python3 ptz_patrol_gui.py --diagnose        -> passed (cameras correctly reported unreachable on a non-camera network)
python3 ptz_patrol_gui.py --mock-test       -> 10/10 checks passed, including with Pillow removed from the environment
```

`ptz_commands.bat` was reviewed statically (every `goto`/`call` target
resolves to a real label, every `RESULT:` line matches the parser regex,
every camera-bridge action name and argument order matches
`CliCameraBridge` exactly) but **not executed on Windows** — there is no
Windows machine in the environment this project was built in.
