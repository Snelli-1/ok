@echo off
setlocal enabledelayedexpansion
rem ======================================================================
rem ptz_commands.bat - PTZ Patrol Controller command bridge (Windows)
rem ======================================================================
rem This is the ONLY .bat file in this project. It never implements
rem SOAP, WS-Security, nonce generation, XML signing, ONVIF
rem authentication, or patrol loops -- all of that lives in
rem ptz_patrol_gui.py (Python) or in the external ONVIF CLI tool you
rem configure. This script only launches the app or runs ONE bounded
rem camera command per invocation.
rem
rem APPLICATION MANAGEMENT:
rem   ptz_commands.bat run
rem   ptz_commands.bat stop
rem   ptz_commands.bat restart
rem   ptz_commands.bat diagnose
rem
rem CAMERA COMMAND BRIDGE (called by ptz_patrol_gui.py; also safe to
rem run by hand from a command prompt for manual testing):
rem   ptz_commands.bat probe        CAMERA_ID
rem   ptz_commands.bat services     CAMERA_ID
rem   ptz_commands.bat profiles     CAMERA_ID
rem   ptz_commands.bat presets      CAMERA_ID
rem   ptz_commands.bat status       CAMERA_ID
rem   ptz_commands.bat goto         CAMERA_ID PRESET_TOKEN
rem   ptz_commands.bat move         CAMERA_ID PAN TILT ZOOM TIMEOUT_S
rem   ptz_commands.bat stop-camera  CAMERA_ID
rem   ptz_commands.bat home         CAMERA_ID
rem   ptz_commands.bat snapshot     CAMERA_ID OUTPUT_FILE
rem
rem WHERE TO CONFIGURE THE REAL ONVIF CLI
rem ---------------------------------------------------------------------
rem Edit the [CLI] section of config.txt: set enabled = true, point
rem "executable" at your installed ONVIF CLI tool, and fill in the
rem *_template keys using {placeholder} tokens (see config.txt's own
rem comments for the full placeholder list). ptz_patrol_gui.py reads
rem config.txt and regenerates runtime\cli_cache.txt every time it
rem starts and every time you click Save -- THIS SCRIPT ONLY EVER READS
rem THAT CACHE FILE. It never reads config.txt directly, so it never
rem needs to parse INI syntax or handle credentials-in-config.txt
rem directly: the one secret involved (the camera password) reaches
rem this script only as the ONVIF_PASSWORD environment variable that
rem Python sets for this one process call, and is substituted into the
rem external command line only at the final execution step below, so
rem it never sits in an intermediate variable this script might echo.
rem
rem MACHINE-READABLE OUTPUT CONTRACT
rem ---------------------------------------------------------------------
rem Every camera-command invocation prints exactly one final line in
rem one of these two forms, which ptz_patrol_gui.py parses:
rem   RESULT:OK:NONE:<short message>
rem   RESULT:ERROR:<CATEGORY>:<short message>
rem CATEGORY is one of: TIMEOUT AUTHENTICATION NETWORK UNSUPPORTED
rem INVALID_RESPONSE CLI_MISSING CONFIGURATION UNKNOWN
rem
rem HONESTY NOTE: this script has been written carefully but has not
rem been executed on a real Windows machine as part of generating this
rem project (it was authored and statically reviewed in a Linux
rem container). Run `ptz_commands.bat diagnose` first, and test one
rem `probe` call by hand, before relying on it. See README.md.
rem ======================================================================

set "SCRIPT_DIR=%~dp0"
set "LOG_DIR=%SCRIPT_DIR%logs"
set "RUNTIME_DIR=%SCRIPT_DIR%runtime"
set "DIAG_DIR=%SCRIPT_DIR%diagnostics"
set "CACHE_FILE=%RUNTIME_DIR%\cli_cache.txt"
set "PID_FILE=%RUNTIME_DIR%\app.pid"
set "STOP_FILE=%RUNTIME_DIR%\stop.request"
set "GUI_SCRIPT=%SCRIPT_DIR%ptz_patrol_gui.py"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%" >nul 2>&1
if not exist "%DIAG_DIR%" mkdir "%DIAG_DIR%" >nul 2>&1

rem Ensure ONVIF_PASSWORD is always at least a defined-but-empty
rem variable, so an unconfigured password expands to nothing rather
rem than surviving as the literal text "%ONVIF_PASSWORD%".
if not defined ONVIF_PASSWORD set "ONVIF_PASSWORD="

set "ACTION=%~1"
if "%ACTION%"=="" (
    echo Usage: ptz_commands.bat ^<run^|stop^|restart^|diagnose^|probe^|services^|profiles^|presets^|status^|goto^|move^|stop-camera^|home^|snapshot^> [args] 1>&2
    echo RESULT:ERROR:CONFIGURATION:no action given
    exit /b 3
)

if /i "%ACTION%"=="run"          goto :CmdRun
if /i "%ACTION%"=="stop"         goto :CmdStop
if /i "%ACTION%"=="restart"      goto :CmdRestart
if /i "%ACTION%"=="diagnose"     goto :CmdDiagnose
if /i "%ACTION%"=="probe"        goto :CmdCameraQuery
if /i "%ACTION%"=="services"     goto :CmdCameraQuery
if /i "%ACTION%"=="profiles"     goto :CmdCameraQuery
if /i "%ACTION%"=="presets"      goto :CmdCameraQuery
if /i "%ACTION%"=="status"       goto :CmdCameraQuery
if /i "%ACTION%"=="stop-camera"  goto :CmdCameraQuery
if /i "%ACTION%"=="home"         goto :CmdCameraQuery
if /i "%ACTION%"=="goto"         goto :CmdGoto
if /i "%ACTION%"=="move"         goto :CmdMove
if /i "%ACTION%"=="snapshot"     goto :CmdSnapshot

echo Unknown action: %ACTION% 1>&2
echo RESULT:ERROR:CONFIGURATION:unknown action "%ACTION%"
exit /b 2


rem ======================================================================
rem Application management
rem ======================================================================

:CmdRun
rem Refuse a duplicate GUI launch (best-effort; ptz_patrol_gui.py's own
rem single-instance PID guard is the authoritative check -- this is a
rem fast, convenient early check so a double-click doesn't even try).
if exist "%PID_FILE%" (
    set "EXISTING_PID="
    set /p EXISTING_PID=<"%PID_FILE%"
    if defined EXISTING_PID (
        tasklist /FI "PID eq !EXISTING_PID!" 2>nul | find "!EXISTING_PID!" >nul
        if not errorlevel 1 (
            echo PTZ Patrol Controller already appears to be running ^(PID !EXISTING_PID!^). 1>&2
            echo RESULT:ERROR:CONFIGURATION:already running
            exit /b 1
        )
    )
)
call :FindPythonW
if "%PYW%"=="" (
    echo Could not find pyw.exe, pythonw.exe, py.exe or python.exe on PATH. 1>&2
    echo RESULT:ERROR:CONFIGURATION:python not found
    exit /b 4
)
echo Starting PTZ Patrol Controller using "%PYW% %PYWARG%" ...
start "PTZ Patrol Controller" /D "%SCRIPT_DIR%" "%PYW%" %PYWARG% "%GUI_SCRIPT%"
echo RESULT:OK:NONE:launch requested
exit /b 0


:CmdStop
if not exist "%PID_FILE%" (
    echo No running instance found ^(no runtime\app.pid^). 1>&2
    echo RESULT:OK:NONE:nothing to stop
    exit /b 0
)
set "STOP_PID="
set /p STOP_PID=<"%PID_FILE%"
if not defined STOP_PID (
    echo RESULT:OK:NONE:nothing to stop ^(empty PID file^)
    exit /b 0
)
echo.>"%STOP_FILE%"
echo Requested graceful stop for PID %STOP_PID% ^(this lets the app send Stop to every camera first^) ...
set /a WAITED=0

:StopWaitLoop
tasklist /FI "PID eq %STOP_PID%" 2>nul | find "%STOP_PID%" >nul
if errorlevel 1 (
    echo RESULT:OK:NONE:stopped gracefully
    exit /b 0
)
if %WAITED% GEQ 20 goto :StopForce
timeout /t 1 /nobreak >nul
set /a WAITED+=1
goto :StopWaitLoop

:StopForce
echo Graceful stop timed out after 20s -- forcing termination. Camera Stop is NOT guaranteed by this fallback. 1>&2
taskkill /PID %STOP_PID% /F >nul 2>&1
del /q "%PID_FILE%" >nul 2>&1
echo RESULT:ERROR:TIMEOUT:forced termination after graceful-stop timeout
exit /b 1


:CmdRestart
call :CmdStop
call :CmdRun
exit /b %ERRORLEVEL%


:CmdDiagnose
call :FindPython
if "%PYEXE%"=="" (
    echo Could not find py.exe or python.exe on PATH. 1>&2
    echo RESULT:ERROR:CONFIGURATION:python not found
    exit /b 4
)
rem Headless, read-only: config validation + TCP reachability only.
rem Never moves a camera, mock mode or real.
"%PYEXE%" %PYARG% "%GUI_SCRIPT%" --diagnose
set "RC=%ERRORLEVEL%"
if %RC% EQU 0 (
    echo RESULT:OK:NONE:diagnostics completed, see diagnostics folder
) else (
    echo RESULT:ERROR:CONFIGURATION:diagnostics reported configuration errors, see diagnostics folder
)
exit /b %RC%


rem ======================================================================
rem Camera command bridge
rem ======================================================================

:CmdCameraQuery
rem Handles the seven single-CAMERA_ID actions: probe, services,
rem profiles, presets, status, stop-camera, home.
set "CAMERA_ID=%~2"
if "%CAMERA_ID%"=="" (
    echo Usage: ptz_commands.bat %ACTION% CAMERA_ID 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing CAMERA_ID
    exit /b 3
)
set "TPL_NAME="
if /i "%ACTION%"=="probe"       set "TPL_NAME=TPL_PROBE"
if /i "%ACTION%"=="services"    set "TPL_NAME=TPL_SERVICES"
if /i "%ACTION%"=="profiles"    set "TPL_NAME=TPL_PROFILES"
if /i "%ACTION%"=="presets"     set "TPL_NAME=TPL_PRESETS"
if /i "%ACTION%"=="status"      set "TPL_NAME=TPL_STATUS"
if /i "%ACTION%"=="stop-camera" set "TPL_NAME=TPL_STOP"
if /i "%ACTION%"=="home"        set "TPL_NAME=TPL_HOME"
call :RunCameraAction "%TPL_NAME%" "%CAMERA_ID%" "" "" "" "" "" ""
exit /b %ERRORLEVEL%


:CmdGoto
set "CAMERA_ID=%~2"
set "PRESET_TOKEN=%~3"
if "%CAMERA_ID%"=="" (
    echo Usage: ptz_commands.bat goto CAMERA_ID PRESET_TOKEN 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing CAMERA_ID
    exit /b 3
)
if "%PRESET_TOKEN%"=="" (
    echo Usage: ptz_commands.bat goto CAMERA_ID PRESET_TOKEN 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing PRESET_TOKEN
    exit /b 3
)
call :RunCameraAction "TPL_GOTO" "%CAMERA_ID%" "%PRESET_TOKEN%" "" "" "" "" ""
exit /b %ERRORLEVEL%


:CmdMove
set "CAMERA_ID=%~2"
set "ARG_PAN=%~3"
set "ARG_TILT=%~4"
set "ARG_ZOOM=%~5"
set "ARG_TIMEOUT=%~6"
if "%CAMERA_ID%"=="" (
    echo Usage: ptz_commands.bat move CAMERA_ID PAN TILT ZOOM TIMEOUT_S 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing CAMERA_ID
    exit /b 3
)
if "%ARG_TIMEOUT%"=="" (
    echo Usage: ptz_commands.bat move CAMERA_ID PAN TILT ZOOM TIMEOUT_S 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing PAN/TILT/ZOOM/TIMEOUT_S
    exit /b 3
)
call :RunCameraAction "TPL_MOVE" "%CAMERA_ID%" "" "%ARG_PAN%" "%ARG_TILT%" "%ARG_ZOOM%" "%ARG_TIMEOUT%" ""
exit /b %ERRORLEVEL%


:CmdSnapshot
set "CAMERA_ID=%~2"
set "ARG_OUTPUT=%~3"
if "%CAMERA_ID%"=="" (
    echo Usage: ptz_commands.bat snapshot CAMERA_ID OUTPUT_FILE 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing CAMERA_ID
    exit /b 3
)
if "%ARG_OUTPUT%"=="" (
    echo Usage: ptz_commands.bat snapshot CAMERA_ID OUTPUT_FILE 1>&2
    echo RESULT:ERROR:CONFIGURATION:missing OUTPUT_FILE
    exit /b 3
)
call :RunCameraAction "TPL_SNAPSHOT" "%CAMERA_ID%" "" "" "" "" "" "%ARG_OUTPUT%"
exit /b %ERRORLEVEL%


:RunCameraAction
rem %1=TemplateVarName  %2=CameraId  %3=PresetToken  %4=Pan  %5=Tilt
rem %6=Zoom  %7=TimeoutS  %8=OutputFile
rem This is the one isolated subroutine that actually builds and runs
rem an external ONVIF CLI command line. Nothing else in this file does.
set "TPL_NAME=%~1"
set "CAMERA_ID=%~2"
set "ARG_PRESET=%~3"
set "ARG_PAN=%~4"
set "ARG_TILT=%~5"
set "ARG_ZOOM=%~6"
set "ARG_TIMEOUT=%~7"
set "ARG_OUTPUT=%~8"

if "%TPL_NAME%"=="" (
    echo RESULT:ERROR:CONFIGURATION:internal error -- no template selected for action "%ACTION%"
    exit /b 14
)

call :LoadCache

if /i not "%CLI_ENABLED%"=="true" (
    echo [CLI] enabled is not "true" in config.txt -- this camera's adapter resolved to cli but no external ONVIF CLI is armed. 1>&2
    echo RESULT:ERROR:CLI_MISSING:CLI not enabled in config.txt
    exit /b 10
)
if "%CLI_EXECUTABLE%"=="" (
    echo [CLI] executable is empty in config.txt. 1>&2
    echo RESULT:ERROR:CLI_MISSING:no CLI executable configured
    exit /b 11
)

set "camhostvar=CAM.%CAMERA_ID%.HOST"
call set "CAM_HOST=%%!camhostvar!%%"
if "%CAM_HOST%"=="" (
    echo Unknown or disabled camera id "%CAMERA_ID%" ^(not found in runtime\cli_cache.txt^). 1>&2
    echo RESULT:ERROR:CONFIGURATION:unknown camera id "%CAMERA_ID%"
    exit /b 12
)
set "camportvar=CAM.%CAMERA_ID%.PORT"
call set "CAM_PORT=%%!camportvar!%%"
set "camuservar=CAM.%CAMERA_ID%.USER"
call set "CAM_USER=%%!camuservar!%%"
set "camprofilevar=CAM.%CAMERA_ID%.PROFILE"
call set "CAM_PROFILE=%%!camprofilevar!%%"
set "camhomevar=CAM.%CAMERA_ID%.HOME_PRESET"
call set "CAM_HOME_PRESET=%%!camhomevar!%%"
if /i "%TPL_NAME%"=="TPL_HOME" if "%ARG_PRESET%"=="" set "ARG_PRESET=%CAM_HOME_PRESET%"

set "tplvar=%TPL_NAME%"
call set "TEMPLATE=%%!tplvar!%%"
if "%TEMPLATE%"=="" (
    echo %TPL_NAME% is empty in config.txt [CLI] section -- configure it before using "%ACTION%". 1>&2
    echo RESULT:ERROR:CLI_MISSING:%TPL_NAME% is empty
    exit /b 13
)

set "CMDLINE=%TEMPLATE%"
call :SubstToken CMDLINE "{executable}" "%CLI_EXECUTABLE%"
call :SubstToken CMDLINE "{host}" "%CAM_HOST%"
call :SubstToken CMDLINE "{onvif_port}" "%CAM_PORT%"
call :SubstToken CMDLINE "{username}" "%CAM_USER%"
call :SubstToken CMDLINE "{password}" "%%ONVIF_PASSWORD%%"
call :SubstToken CMDLINE "{profile_token}" "%CAM_PROFILE%"
call :SubstToken CMDLINE "{preset_token}" "%ARG_PRESET%"
call :SubstToken CMDLINE "{pan}" "%ARG_PAN%"
call :SubstToken CMDLINE "{tilt}" "%ARG_TILT%"
call :SubstToken CMDLINE "{zoom}" "%ARG_ZOOM%"
call :SubstToken CMDLINE "{timeout_s}" "%ARG_TIMEOUT%"
call :SubstToken CMDLINE "{output_file}" "%ARG_OUTPUT%"

echo [ptz_commands] camera=%CAMERA_ID% action=%ACTION% template=%TPL_NAME% 1>&2
rem Run via a fresh "cmd /c" so %ONVIF_PASSWORD% is expanded here, from
rem the environment, at the last possible moment -- it is never stored
rem in CMDLINE itself (CMDLINE only ever holds the literal text
rem "%ONVIF_PASSWORD%" until this exact line).
cmd /c "!CMDLINE!"
set "EXTRC=%ERRORLEVEL%"
rem Clear the secret from this process's own environment now that the
rem one call that needed it has finished.
set "ONVIF_PASSWORD="
if "%EXTRC%"=="0" (
    echo RESULT:OK:NONE:external CLI exited 0
) else (
    echo RESULT:ERROR:UNKNOWN:external CLI exited %EXTRC%
)
exit /b %EXTRC%


:SubstToken
rem %1=name of variable to modify  %2=literal token e.g. "{host}"
rem %3=replacement text (already resolved by the caller, OR the
rem escaped-percent literal "%%ONVIF_PASSWORD%%" for the password case)
setlocal enabledelayedexpansion
set "_src=!%~1!"
set "_tok=%~2"
set "_rep=%~3"
if not "!_tok!"=="" set "_src=!_src:%_tok%=%_rep%!"
endlocal & set "%~1=%_src%"
goto :eof


:LoadCache
set "CLI_ENABLED=false"
set "CLI_EXECUTABLE="
if not exist "%CACHE_FILE%" (
    echo runtime\cli_cache.txt does not exist yet -- start ptz_patrol_gui.py once (even in mock mode) to generate it, or click Save in the GUI. 1>&2
    goto :eof
)
for /f "usebackq delims=" %%L in ("%CACHE_FILE%") do call :LoadCacheLine "%%L"
goto :eof

:LoadCacheLine
set "kvline=%~1"
if "%kvline%"=="" goto :eof
set "kvkey="
set "kvval="
for /f "tokens=1,* delims==" %%A in ("%kvline%") do (
    set "kvkey=%%A"
    set "kvval=%%B"
)
if defined kvkey set "%kvkey%=%kvval%"
goto :eof


:FindPython
rem Console Python, for --diagnose (we want to see its stdout).
set "PYEXE="
set "PYARG="
where py >nul 2>&1
if not errorlevel 1 (
    set "PYEXE=py"
    set "PYARG=-3"
    goto :eof
)
where python >nul 2>&1
if not errorlevel 1 (
    set "PYEXE=python"
    set "PYARG="
    goto :eof
)
goto :eof


:FindPythonW
rem Windowed Python (no console), for the long-running GUI. Falls back
rem to the console launcher as a last resort so `run` still works even
rem on a Python install without pyw/pythonw (a console window will
rem then stay open for the lifetime of the GUI).
set "PYW="
set "PYWARG="
where pyw >nul 2>&1
if not errorlevel 1 (
    set "PYW=pyw"
    set "PYWARG=-3"
    goto :eof
)
where pythonw >nul 2>&1
if not errorlevel 1 (
    set "PYW=pythonw"
    set "PYWARG="
    goto :eof
)
where py >nul 2>&1
if not errorlevel 1 (
    set "PYW=py"
    set "PYWARG=-3"
    goto :eof
)
where python >nul 2>&1
if not errorlevel 1 (
    set "PYW=python"
    set "PYWARG="
    goto :eof
)
goto :eof
