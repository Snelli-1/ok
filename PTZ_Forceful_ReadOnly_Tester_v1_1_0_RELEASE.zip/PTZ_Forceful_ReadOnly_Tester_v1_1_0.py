#!/usr/bin/env python3
"""Aggressive but read-only ONVIF request matrix. Log is saved beside this script/BAT."""
import argparse,http.client,ipaddress,json,os,socket,time,traceback,urllib.parse,xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path
S12='http://www.w3.org/2003/05/soap-envelope';S11='http://schemas.xmlsoap.org/soap/envelope/'
TDS='http://www.onvif.org/ver10/device/wsdl';TRT='http://www.onvif.org/ver10/media/wsdl';TPTZ='http://www.onvif.org/ver20/ptz/wsdl';TT='http://www.onvif.org/ver10/schema'
def loc(t):return t.rsplit('}',1)[-1]
def esc(s):return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def envelope(body,soap):return f'<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{soap}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'
def txts(root,name):return [(e.text or '').strip() for e in root.iter() if loc(e.tag)==name and (e.text or '').strip()]
def toks(root,names):
 out=[]
 for e in root.iter():
  if loc(e.tag) in names:
   v=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
   if v and v not in out:out.append(v)
 return out
class Log:
 def __init__(self,d,host):
  d=Path(d).resolve();d.mkdir(parents=True,exist_ok=True);self.path=d/f'PTZ_FORCEFUL_READONLY_{host}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt';self.f=self.path.open('w',encoding='utf-8',buffering=1);self.n=0;self.start=time.monotonic();self.w(f'PTZ FORCEFUL READ-ONLY TESTER v1.1.0\nTarget: {host}\nUTC start: {datetime.now(timezone.utc).isoformat()}\nLog: {self.path}\nNo movement, reboot, reset, Home, preset write, auxiliary or configuration-write requests.\n')
 def w(self,s):print(s,flush=True);self.f.write(s+'\n');self.f.flush()
 def add(self,name,status,detail='',req='',resp=''):
  self.n+=1;self.w(f'[{self.n:04d}] +{time.monotonic()-self.start:8.3f} s {name:<48} {status:<12} {detail}')
  if req:self.w('REQUEST:\n'+req)
  if resp:self.w('RESPONSE:\n'+resp)
 def close(self):self.f.flush();os.fsync(self.f.fileno());self.f.close()
def send(url,body,soap12,action,timeout):
 u=urllib.parse.urlparse(url);xml=envelope(body,S12 if soap12 else S11);h={'Connection':'close','User-Agent':'PTZ-Forceful-ReadOnly/1.1'}
 if soap12:h['Content-Type']='application/soap+xml; charset=utf-8'+(f'; action="{action}"' if action else '')
 else:h.update({'Content-Type':'text/xml; charset=utf-8','SOAPAction':f'"{action or ""}"'})
 c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=timeout);st=time.monotonic()
 try:c.request('POST',u.path or '/',xml.encode(),h);r=c.getresponse();data=r.read(2097152).decode(errors='replace')
 finally:c.close()
 return r.status,r.reason,data,xml,int((time.monotonic()-st)*1000)
def one(log,name,url,body,soap12,action,timeout):
 try:
  code,reason,data,req,ms=send(url,body,soap12,action,timeout)
  try:root=ET.fromstring(data)
  except Exception:log.add(name,'HTTP_ONLY',f'HTTP {code} {reason}, {ms} ms',req,data[:16000]);return None
  if any(loc(e.tag)=='Fault' for e in root.iter()):
   fault=' | '.join(txts(root,'Text')+txts(root,'Value'));log.add(name,'SOAP_FAULT',f'HTTP {code}, {ms} ms, {fault}',req,data);return root
  log.add(name,'SOAP_OK',f'HTTP {code}, {ms} ms',req,data);return root
 except Exception as e:log.add(name,'EXCEPTION',f'{type(e).__name__}: {e}',resp=traceback.format_exc());return None
def matrix(log,name,url,body,action,timeout):
 roots=[]
 for label,s12,act in [('S12_ACTION',1,action),('S12_NO_ACTION',1,None),('S11_ACTION',0,action),('S11_EMPTY',0,'')]:roots.append(one(log,name+'_'+label,url,body,bool(s12),act,timeout))
 return roots
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='192.168.1.102');ap.add_argument('--port',type=int,default=8899);ap.add_argument('--timeout',type=float,default=4);ap.add_argument('--log-dir',default=str(Path(__file__).resolve().parent));a=ap.parse_args()
 if not ipaddress.ip_address(a.host).is_private:raise SystemExit('Private LAN only')
 log=Log(a.log_dir,a.host);base=f'http://{a.host}:{a.port}';device=base+'/onvif/device_service';media=base+'/onvif/media_service';ptz=base+'/onvif/ptz_service';profiles=[];nodes=[];cfgs=[];xaddrs=[]
 try:
  log.add('POLICY','INFO','Aggressive standards-compliance variations, still strictly read-only.')
  for path in ['/onvif/device_service','/onvif/Device_service','/onvif/services','/device_service','/onvif/device_service/']:
   matrix(log,'PATH_'+path.replace('/','_'),base+path,'<tds:GetSystemDateAndTime/>',TDS+'/GetSystemDateAndTime',a.timeout)
  ops=[('GetSystemDateAndTime','<tds:GetSystemDateAndTime/>'),('GetDeviceInformation','<tds:GetDeviceInformation/>'),('GetCapabilitiesAll','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>'),('GetCapabilitiesPTZ','<tds:GetCapabilities><tds:Category>PTZ</tds:Category></tds:GetCapabilities>'),('GetServicesTrue','<tds:GetServices><tds:IncludeCapability>true</tds:IncludeCapability></tds:GetServices>'),('GetServicesFalse','<tds:GetServices><tds:IncludeCapability>false</tds:IncludeCapability></tds:GetServices>')]
  for name,body in ops:
   for root in matrix(log,name,device,body,TDS+'/'+name,a.timeout):
    if root:
     for x in txts(root,'XAddr'):
      if x not in xaddrs:xaddrs.append(x)
  media=next((x for x in xaddrs if 'media' in x.lower() and 'media2' not in x.lower()),media);ptz=next((x for x in xaddrs if 'ptz' in x.lower()),ptz);log.add('XADDRS','INFO',json.dumps(xaddrs))
  for name,body in [('GetServiceCapabilities','<tptz:GetServiceCapabilities/>'),('GetNodes','<tptz:GetNodes/>'),('GetConfigurations','<tptz:GetConfigurations/>')]:
   for root in matrix(log,name,ptz,body,TPTZ+'/'+name,a.timeout):
    if root:nodes+=toks(root,{'PTZNode'});cfgs+=toks(root,{'PTZConfiguration'})
  nodes=list(dict.fromkeys(nodes));cfgs=list(dict.fromkeys(cfgs))
  for n in nodes:matrix(log,'GetNode_'+n,ptz,f'<tptz:GetNode><tptz:NodeToken>{esc(n)}</tptz:NodeToken></tptz:GetNode>',TPTZ+'/GetNode',a.timeout)
  for c in cfgs:
   matrix(log,'GetConfiguration_'+c,ptz,f'<tptz:GetConfiguration><tptz:PTZConfigurationToken>{esc(c)}</tptz:PTZConfigurationToken></tptz:GetConfiguration>',TPTZ+'/GetConfiguration',a.timeout)
   matrix(log,'GetConfigurationOptions_'+c,ptz,f'<tptz:GetConfigurationOptions><tptz:ConfigurationToken>{esc(c)}</tptz:ConfigurationToken></tptz:GetConfigurationOptions>',TPTZ+'/GetConfigurationOptions',a.timeout)
  for root in matrix(log,'GetProfiles',media,'<trt:GetProfiles/>',TRT+'/GetProfiles',a.timeout):
   if root:profiles+=toks(root,{'Profiles','Profile'})
  profiles=list(dict.fromkeys(profiles))
  for p in profiles:
   matrix(log,'Compatible_'+p,ptz,f'<tptz:GetCompatibleConfigurations><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetCompatibleConfigurations>',TPTZ+'/GetCompatibleConfigurations',a.timeout)
   for label,body in [('PLAIN',f'<tptz:GetStatus><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetStatus>'),('SCHEMA',f'<tptz:GetStatus><tt:ProfileToken>{esc(p)}</tt:ProfileToken></tptz:GetStatus>'),('SPACE',f'<tptz:GetStatus><tptz:ProfileToken> {esc(p)} </tptz:ProfileToken></tptz:GetStatus>')]:matrix(log,'GetStatus_'+p+'_'+label,ptz,body,TPTZ+'/GetStatus',a.timeout)
   matrix(log,'GetPresets_'+p,ptz,f'<tptz:GetPresets><tptz:ProfileToken>{esc(p)}</tptz:ProfileToken></tptz:GetPresets>',TPTZ+'/GetPresets',a.timeout)
  matrix(log,'NEG_UNKNOWN_NODE',ptz,'<tptz:GetNode><tptz:NodeToken>__UNKNOWN__</tptz:NodeToken></tptz:GetNode>',TPTZ+'/GetNode',a.timeout)
  matrix(log,'NEG_UNKNOWN_PROFILE',ptz,'<tptz:GetStatus><tptz:ProfileToken>__UNKNOWN__</tptz:ProfileToken></tptz:GetStatus>',TPTZ+'/GetStatus',a.timeout)
  matrix(log,'NEG_UNKNOWN_CFG',ptz,'<tptz:GetConfiguration><tptz:PTZConfigurationToken>__UNKNOWN__</tptz:PTZConfigurationToken></tptz:GetConfiguration>',TPTZ+'/GetConfiguration',a.timeout)
  log.add('FINAL','INFO',json.dumps({'profiles':profiles,'nodes':nodes,'configurations':cfgs,'xaddrs':xaddrs},indent=2))
  return 0
 finally:
  log.add('LOG_PATH','INFO',str(log.path));log.close();print('\nLOG FILE:',log.path)
if __name__=='__main__':raise SystemExit(main())
