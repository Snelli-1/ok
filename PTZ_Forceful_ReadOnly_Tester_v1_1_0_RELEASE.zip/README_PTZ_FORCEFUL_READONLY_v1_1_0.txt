PTZ FORCEFUL READ-ONLY TESTER v1.1.0
====================================

PURPOSE
Aggressively query every useful standard read-only ONVIF Device, Media and PTZ operation
using multiple standards-compliant request forms. The full TXT log is created directly
beside the BAT file, not in a subdirectory.

RUN
1. Extract the ZIP into a normal writable folder.
2. Rename RUN_PTZ_FORCEFUL_READONLY_TEST_v1_1_0.bat.txt to .bat.
3. Keep the BAT and Python file together.
4. Double-click the BAT.
5. The newest PTZ_FORCEFUL_READONLY_192.168.1.102_*.txt opens in Notepad automatically.

LOG GUARANTEE
The BAT explicitly passes its own directory through:
  --log-dir "%~dp0"
The Python script resolves that directory and creates the log there before camera tests.
Every line is flushed immediately and fsync is used before closing.

FORCEFUL, BUT READ-ONLY
The matrix tries SOAP 1.2/1.1, action/no-action, alternate endpoint paths, all discovered
real tokens, token representation variations, and safe unknown-token controls.

It never sends movement, Home, preset writes, auxiliary commands, configuration writes,
reboot, reset, credential guesses, malformed XML attacks, or exploit payloads.
