@echo off
rem PTZ Patrol Controller v2.1.0 Unified external CLI bridge.
rem The Python controller passes sanitized, bounded commands here only when adapter=cli.
rem Configure ONVIF_CLI to an operator-approved executable before arming physical motion.
setlocal
set "ONVIF_CLI=%~dp0onvif-cli.exe"
if not exist "%ONVIF_CLI%" (
  echo ERROR E-CLI-001 external ONVIF CLI not configured 1>&2
  exit /b 20
)
"%ONVIF_CLI%" %*
exit /b %errorlevel%
