from pathlib import Path
import ast, configparser, hashlib, zipfile
root=Path(__file__).resolve().parent
src=(root/'PTZ_Patrol_Controller_v2_1_0_Unified.py').read_text(encoding='utf-8')
ast.parse(src)
checks={
'10 tabs': all(x in src for x in ('DASHBOARD','LIVE VIEW','PTZ CONTROL','PATROL & AUTOMATION','DISCOVERY','CAMERA SETUP','DIAGNOSTICS','LOGS & REPORTS','SETTINGS','DEVELOPER TOOLS')),
'v1 discovery retained':'class DiscoveryDialog' in src and 'class DiscoveryWorker' in src,
'v1 worker retained':'class CameraWorker' in src and 'PriorityQueue' in src,
'emergency stop':'def _on_emergency_stop' in src,
'frame based live':'kind=="FRAME"' in src,
'GetStreamUri resolver':'GetStreamUri' in src and 'class VideoSourceResolver' in src,
'FFmpeg fallback':'class FFmpegFrameWorker' in src,
'credential sanitization':'def _safe_video_uri' in src,
'only real default': '192.168.1.102' in (root/'config.txt').read_text() and all(x not in (root/'config.txt').read_text() for x in ('192.168.1.50','192.168.1.51','192.168.1.52','192.168.1.53')),
'mock lab isolated':'NON-PRODUCTION - MOCK LABORATORY' in src,
}
cp=configparser.ConfigParser(interpolation=None,strict=False); cp.read(root/'config.txt',encoding='utf-8')
checks['config parse']=bool(cp.sections())
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
print(f"{sum(checks.values())}/{len(checks)} checks passed")
raise SystemExit(0 if all(checks.values()) else 1)
