@echo off
setlocal
cd /d "%~dp0"
py -3 PTZ_Patrol_Controller_v2_1_0_Unified.py
if errorlevel 1 pause
