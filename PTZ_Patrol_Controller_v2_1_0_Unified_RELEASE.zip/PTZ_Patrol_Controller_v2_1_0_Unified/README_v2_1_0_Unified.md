# PTZ Patrol Controller v2.1.0 Unified

This release uses the complete v1 controller as the structural base and adds a task-oriented 10-tab GUI, selected/multiview video, ONVIF Media1 `GetStreamUri` discovery, FFmpeg fallback, a dependency report, and a production configuration containing only `192.168.1.102`.

## Safety defaults

- `dry_run=true`
- `mock_mode=false`
- patrol disabled
- autostart movement disabled
- no `.50`, `.51`, `.52`, or `.53` demonstration cameras
- mock laboratory isolated under **DEVELOPER TOOLS**

## Start

1. Extract the complete ZIP.
2. Run `INSTALL_DEPENDENCIES.bat`.
3. Place `ffmpeg.exe` in PATH or beside the controller if FFmpeg decoding is desired.
4. Edit `config.txt` and replace `CHANGE_ME` with the physical camera password.
5. Run `RUN_v2_1_0_Unified.bat`.
6. Use **CAMERA SETUP** and **DIAGNOSTICS** before disabling dry-run.
7. In **LIVE VIEW**, use source testing before starting multiview.

## Video resolution order

Configured URI, optional ONVIF Media1 profiles and `GetStreamUri`, then a bounded set of common RTSP candidates. A status never becomes `LIVE` until a frame was decoded. Missing OpenCV is not fatal when FFmpeg is available.

## Important truthfulness note

Linux static tests passed, but the test container lacks `_tkinter` and cannot access the physical `192.168.1.102` camera. Windows GUI, ONVIF authentication, RTSP paths, and physical motion remain target-machine tests. Do not interpret static verification as a real-camera pass.
