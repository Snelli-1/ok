@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install --upgrade pip
py -3 -m pip install -r requirements.txt
where ffmpeg >nul 2>nul || echo NOTE: ffmpeg.exe was not found in PATH. PyAV/OpenCV/snapshot fallback may still work.
pause
