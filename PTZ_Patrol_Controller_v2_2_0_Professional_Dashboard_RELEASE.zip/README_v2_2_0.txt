PTZ Patrol Controller v2.2.0 Professional Dashboard

New dashboard functions:
- One live video stream for the selected camera only.
- Responsive selected-camera video area that follows window resizing.
- Radar-like limited direction indicator with forward at the top.
- Separate display-forward and calibration-zero settings.
- Per-camera manual hard limits, default pan/tilt limits: -26 to +26 steps.
- Dynamic fleet tile layout: only existing cameras consume space; 1/2/3/4 columns chosen automatically.
- Per-camera custom RTSP URL; otherwise rtsp://user:password@host:rtsp_port/stream1 is tried.
- Existing patrol, camera, discovery, diagnostics and mock safety features remain in the same full script.

Important:
The step position is an estimate based on accepted manual button commands, not a measured ONVIF coordinate. Calibrate it before relying on the boundary display. Camera firmware may still apply motion differently, so keep dry-run/mock mode enabled until verified.

Optional live-video dependency:
  pip install opencv-python pillow

Run:
  python PTZ_Patrol_Controller_v2_2_0_Professional_Dashboard.py
