@echo off
cd /d "%~dp0"
py -3 ptz_patrol_gui.py
if errorlevel 1 pause
