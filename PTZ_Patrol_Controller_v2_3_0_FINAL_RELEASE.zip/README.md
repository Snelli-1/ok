# PTZ Patrol Controller v2.3.0

Production-only Windows ONVIF PTZ controller. Extract, run INSTALL_REQUIREMENTS.bat, edit config.txt, then run ptz_commands.bat. The release contains task tabs, Active Camera selection, finite ContinuousMove pulses with explicit Stop, hard limits, UNSYNCED handling, calibrated-estimate radar, EXEC patrol, PING_PONG, office-fan template, selected-camera video, safe discovery and read-only diagnostics.

Static tests passed. Windows, network, video and physical movement tests remain required for this exact build. Keep the camera visible during the first low-speed 200 ms pulse. Space or Escape sends Emergency Stop.
