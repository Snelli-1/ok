from pathlib import Path
import ast,configparser,sys
b=Path(__file__).parent;s=(b/"ptz_patrol_gui.py").read_text(encoding="utf-8");checks=[]
def ck(n,o):checks.append((n,o));print("PASS" if o else "FAIL",n)
ck("AST",ast.parse(s) is not None)
for x in ["ttk.Notebook","ContinuousMove","UNSYNCED","PING_PONG","class Worker","class Video","hard limit","explicit Stop"]:ck(x,x in s)
for x in ["MockCameraBridge","mock_mode","--mock-test"]:ck("forbidden "+x,x not in s)
c=configparser.ConfigParser();c.read(b/"config.txt");ck("production config",c.getboolean("APPLICATION","production_mode"));ck("PING_PONG semantics",[1,2,3,4]+[1,2,3,4][-2:0:-1]==[1,2,3,4,3,2]);(b/"TEST_RESULTS.txt").write_text("\n".join(("PASS" if o else "FAIL")+" | "+n for n,o in checks)+"\n");sys.exit(any(not o for _,o in checks))
