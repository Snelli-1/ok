#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PTZ Patrol Controller v2.3.0 - production-only ONVIF controller."""
from __future__ import annotations
import configparser, dataclasses, datetime as dt, json, logging, math, os, queue, re, socket, sys, threading, time, urllib.parse, xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
try:
 import requests
except Exception as exc: raise SystemExit("Install requirements first") from exc
try:
 from PIL import Image, ImageTk
except Exception: Image=ImageTk=None
try:
 import cv2
except Exception: cv2=None
VERSION="2.3.0"; BASE=Path(__file__).resolve().parent; CONFIG=BASE/"config.txt"
LOGS=BASE/"logs"; DIAG=BASE/"diagnostics"; RUNTIME=BASE/"runtime"
for p in (LOGS,DIAG,RUNTIME): p.mkdir(exist_ok=True)
logging.basicConfig(filename=LOGS/"application.log",level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s")
NS={"s":"http://www.w3.org/2003/05/soap-envelope","trt":"http://www.onvif.org/ver10/media/wsdl","tptz":"http://www.onvif.org/ver20/ptz/wsdl","tt":"http://www.onvif.org/ver10/schema"}
def now(): return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
def mask_uri(v):
 try:
  u=urllib.parse.urlsplit(v)
  if not u.username:return v
  host=u.hostname or ""; host+=f":{u.port}" if u.port else ""
  return urllib.parse.urlunsplit((u.scheme,f"***:***@{host}",u.path,u.query,u.fragment))
 except Exception:return re.sub(r"//[^/@:]+:[^/@]+@","//***:***@",str(v))
@dataclasses.dataclass
class Camera:
 camera_id:str; name:str; host:str; onvif_port:int=8899; rtsp_port:int=554; username:str=""; password:str=""; profile_token:str="PROFILE_000"; ptz_endpoint:str=""; media_endpoint:str=""; stream_uri:str=""; enabled:bool=True; pan_speed:float=.15; tilt_speed:float=.15; zoom_speed:float=.15; pulse_ms:int=200; gap_ms:int=100; pan_min:int=-26; pan_max:int=26; tilt_min:int=-26; tilt_max:int=26; pan_step:int=0; tilt_step:int=0; display_forward_step:int=0; calibration_zero_step:int=0; calibration_speed:float=.15; calibration_pulse_ms:int=200; reliability:str="ESTIMATED"
 def normalize(self):
  self.onvif_port=max(1,min(65535,int(self.onvif_port))); self.rtsp_port=max(1,min(65535,int(self.rtsp_port)))
  self.pan_speed=max(.01,min(1,float(self.pan_speed))); self.tilt_speed=max(.01,min(1,float(self.tilt_speed))); self.zoom_speed=max(.01,min(1,float(self.zoom_speed)))
  self.pulse_ms=max(50,min(5000,int(self.pulse_ms))); self.gap_ms=max(0,min(5000,int(self.gap_ms)))
  self.ptz_endpoint=self.ptz_endpoint or f"http://{self.host}:{self.onvif_port}/onvif/ptz_service"; self.media_endpoint=self.media_endpoint or f"http://{self.host}:{self.onvif_port}/onvif/media_service"
@dataclasses.dataclass
class Step: exec_no:int; pan:int=0; tilt:int=0; dwell_s:float=2; label:str=""; enabled:bool=True
@dataclasses.dataclass
class Result: ok:bool; state:str; message:str; elapsed_ms:int=0
class Store:
 def __init__(self,path):self.path=path
 def load(self):
  c=configparser.ConfigParser(interpolation=None); c.optionxform=str; c.read(self.path,encoding="utf-8")
  cams={}; active=c.get("APPLICATION","active_camera",fallback="")
  for sec in c.sections():
   if not sec.startswith("CAMERA_"):continue
   q=c[sec]; cid=sec[7:]; kw={}
   for f in dataclasses.fields(Camera):
    if f.name=="camera_id":continue
    raw=q.get(f.name,str(f.default))
    if f.type in (int,"int"):raw=int(float(raw))
    elif f.type in (float,"float"):raw=float(raw)
    elif f.type in (bool,"bool"):raw=str(raw).lower() in ("1","true","yes","on")
    kw[f.name]=raw
   cam=Camera(cid,**kw); cam.normalize(); cams[cid]=cam
  steps=[]
  if c.has_section("PATROL_DEFAULT"):
   for _,v in c.items("PATROL_DEFAULT"):
    d=dict(x.split("=",1) for x in v.split(";") if "=" in x)
    steps.append(Step(int(d.get("EXEC",10)),int(d.get("pan",0)),int(d.get("tilt",0)),float(d.get("dwell_s",2)),d.get("label",""),d.get("enabled","true").lower()=="true"))
  return cams,sorted(steps,key=lambda x:x.exec_no),active
 def save(self,cams,steps,active):
  if self.path.exists():self.path.with_suffix(".txt.bak").write_bytes(self.path.read_bytes())
  c=configparser.ConfigParser(interpolation=None); c.optionxform=str; c["META"]={"version":VERSION,"saved_utc":now()};c["APPLICATION"]={"active_camera":active,"production_mode":"true"}
  for cam in cams.values():c[f"CAMERA_{cam.camera_id}"]={f.name:str(getattr(cam,f.name)) for f in dataclasses.fields(Camera) if f.name!="camera_id"}
  c["PATROL_DEFAULT"]={f"step_{i}":f"EXEC={s.exec_no};pan={s.pan};tilt={s.tilt};dwell_s={s.dwell_s};label={s.label};enabled={str(s.enabled).lower()}" for i,s in enumerate(sorted(steps,key=lambda x:x.exec_no),1)}
  tmp=self.path.with_suffix(".tmp");f=tmp.open("w",encoding="utf-8");c.write(f);f.close();os.replace(tmp,self.path)
class Soap:
 def __init__(self,cam): self.cam=cam; self.s=requests.Session(); self.s.auth=(cam.username,cam.password) if cam.username else None; self.lock=threading.RLock()
 def call(self,endpoint,action,body,timeout=5):
  xml=f'<?xml version="1.0"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:trt="http://www.onvif.org/ver10/media/wsdl" xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl" xmlns:tt="http://www.onvif.org/ver10/schema"><s:Body>{body}</s:Body></s:Envelope>'
  started=time.monotonic()
  try:
   with self.lock:r=self.s.post(endpoint,data=xml.encode(),headers={"Content-Type":f'application/soap+xml; charset=utf-8; action="{action}"'},timeout=timeout)
   ms=int((time.monotonic()-started)*1000)
   return (Result(r.status_code==200,"ACCEPTED" if r.status_code==200 else "REJECTED",f"HTTP {r.status_code}",ms),r.text)
  except requests.Timeout:return Result(False,"TIMEOUT","Request timed out"),""
  except Exception as e:return Result(False,"FAILED",str(e)),""
 def move(self,x,y,z=0):
  b=f'<tptz:ContinuousMove><tptz:ProfileToken>{self.cam.profile_token}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="{x}" y="{y}"/><tt:Zoom x="{z}"/></tptz:Velocity></tptz:ContinuousMove>'
  return self.call(self.cam.ptz_endpoint,"http://www.onvif.org/ver20/ptz/wsdl/ContinuousMove",b)[0]
 def stop(self):
  b=f'<tptz:Stop><tptz:ProfileToken>{self.cam.profile_token}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>'
  return self.call(self.cam.ptz_endpoint,"http://www.onvif.org/ver20/ptz/wsdl/Stop",b)[0]
 def status(self):
  b=f'<tptz:GetStatus><tptz:ProfileToken>{self.cam.profile_token}</tptz:ProfileToken></tptz:GetStatus>';r,t=self.call(self.cam.ptz_endpoint,"http://www.onvif.org/ver20/ptz/wsdl/GetStatus",b);d={"note":"Diagnostic only; not trusted as physical direction until correlated."}
  if r.ok:
   try:
    root=ET.fromstring(t);p=root.find(".//tt:Position/tt:PanTilt",NS);z=root.find(".//tt:Position/tt:Zoom",NS);d.update(pan=p.get("x") if p is not None else None,tilt=p.get("y") if p is not None else None,zoom=z.get("x") if z is not None else None)
   except Exception as e:d["parse_error"]=str(e)
  return r,d
 def stream(self):
  b=f'<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup><trt:ProfileToken>{self.cam.profile_token}</trt:ProfileToken></trt:GetStreamUri>';r,t=self.call(self.cam.media_endpoint,"http://www.onvif.org/ver10/media/wsdl/GetStreamUri",b);u=""
  if r.ok:
   try:
    n=ET.fromstring(t).find(".//tt:Uri",NS);u=n.text.strip() if n is not None and n.text else ""
   except Exception:pass
  return r,u
class Motion:
 def __init__(self,cam,emit):self.cam=cam;self.soap=Soap(cam);self.emit=emit;self.lock=threading.RLock();self.cancel=threading.Event()
 def pulse(self,x,y,z=0):
  with self.lock:
   self.cancel.clear();np=self.cam.pan_step+x;nt=self.cam.tilt_step+y
   if x and not self.cam.pan_min<=np<=self.cam.pan_max:return Result(False,"NOT_SENT",f"Pan hard limit blocks {np}")
   if y and not self.cam.tilt_min<=nt<=self.cam.tilt_max:return Result(False,"NOT_SENT",f"Tilt hard limit blocks {nt}")
   r=self.soap.move(x*self.cam.pan_speed,y*self.cam.tilt_speed,z*self.cam.zoom_speed);self.emit(f"Move {r.state}: {r.message}")
   if not r.ok:return r
   self.cancel.wait(self.cam.pulse_ms/1000);s=self.soap.stop();self.emit(f"Stop {s.state}: {s.message}")
   if not s.ok:self.cam.reliability="UNSYNCED";return Result(False,"FAILED","Stop failed; UNSYNCED")
   self.cam.pan_step=np;self.cam.tilt_step=nt;self.cam.reliability="CALIBRATED_ESTIMATE" if self.cam.pan_speed==self.cam.calibration_speed and self.cam.pulse_ms==self.cam.calibration_pulse_ms else "ESTIMATED";self.cancel.wait(self.cam.gap_ms/1000);return Result(True,"COMPLETED","Finite pulse and explicit Stop completed")
 def emergency(self):self.cancel.set();r=self.soap.stop();self.cam.reliability="UNSYNCED" if not r.ok else self.cam.reliability;self.emit(f"Emergency Stop {r.state}");return r
class Worker(threading.Thread):
 def __init__(self,cam,events):super().__init__(daemon=True,name=f"CameraWorker-{cam.camera_id}");self.cam=cam;self.events=events;self.q=queue.PriorityQueue();self.seq=0;self.live=True;self.motion=Motion(cam,self.emit)
 def emit(self,m):self.events.put(("status",self.cam.camera_id,m))
 def put(self,cmd,data=None,p=50):self.seq+=1;self.q.put((p,self.seq,cmd,data))
 def run(self):
  while self.live:
   try:_,_,cmd,data=self.q.get(timeout=.2)
   except queue.Empty:continue
   if cmd=="pulse":self.emit(self.motion.pulse(*data).message)
   elif cmd=="stop":self.motion.emergency()
   elif cmd=="call":data(self.motion)
   elif cmd=="quit":self.motion.emergency();self.live=False
   self.events.put(("position",self.cam.camera_id,""))
class Video(threading.Thread):
 def __init__(self,uri,frames,events,cid):super().__init__(daemon=True);self.uri=uri;self.frames=frames;self.events=events;self.cid=cid;self.quit=threading.Event()
 def run(self):
  if cv2 is None:self.events.put(("video",self.cid,"VIDEO ERROR: OpenCV unavailable"));return
  cap=cv2.VideoCapture(self.uri)
  if not cap.isOpened():self.events.put(("video",self.cid,"VIDEO ERROR: cannot open stream"));return
  self.events.put(("video",self.cid,"VIDEO ONLINE"))
  while not self.quit.is_set():
   ok,frame=cap.read()
   if not ok:break
   try:
    while True:self.frames.get_nowait()
   except queue.Empty:pass
   try:self.frames.put_nowait(frame)
   except queue.Full:pass
  cap.release();self.events.put(("video",self.cid,"VIDEO OFF"))
class Radar(tk.Canvas):
 def __init__(self,p):super().__init__(p,bg="#101820",highlightthickness=0);self.cam=None;self.bind("<Configure>",lambda e:self.draw())
 def draw(self):
  self.delete("all");w=max(100,self.winfo_width());h=max(100,self.winfo_height());r=min(w,h)/2-30;cx=w/2;cy=h/2;self.create_oval(cx-r,cy-r,cx+r,cy+r,outline="#4aa3df",width=2)
  if not self.cam:self.create_text(cx,cy,text="NO ACTIVE CAMERA",fill="white");return
  a=math.radians(((self.cam.pan_step-self.cam.display_forward_step)/max(1,self.cam.pan_max-self.cam.pan_min))*360-90);self.create_line(cx,cy,cx+math.cos(a)*r*.8,cy+math.sin(a)*r*.8,fill="#49d17d",width=5,arrow="last");self.create_text(cx,cy+r+14,text=f"Pan {self.cam.pan_step} steps | Tilt {self.cam.tilt_step} steps | {self.cam.reliability}",fill="white")
class App(tk.Tk):
 TABS=["DASHBOARD","LIVE VIEW","PTZ CONTROL","PATROL & AUTOMATION","DISCOVERY","CAMERA SETUP","DIAGNOSTICS","LOGS & REPORTS","SETTINGS"]
 def __init__(self):
  super().__init__();self.title(f"PTZ Patrol Controller v{VERSION}");self.geometry("1400x880");self.minsize(1000,650);self.protocol("WM_DELETE_WINDOW",self.close)
  self.store=Store(CONFIG);self.cams,self.steps,self.active=self.store.load();self.events=queue.Queue();self.workers={k:Worker(v,self.events) for k,v in self.cams.items() if v.enabled};[w.start() for w in self.workers.values()];self.frames=queue.Queue(1);self.video=None;self.patrol_stop=threading.Event();self.patrol_pause=threading.Event();self.status=tk.StringVar(value="Ready");self.active_var=tk.StringVar();self.video_var=tk.StringVar(value="VIDEO OFF")
  self.header();self.tabs();ttk.Label(self,textvariable=self.status).pack(fill="x",padx=8,pady=4);self.refresh_cameras();self.active=self.active if self.active in self.cams else (next(iter(self.cams),""));self.activate(self.active,False);self.after(100,self.poll);self.after(50,self.frame);self.bind_all("<Escape>",lambda e:self.estop());self.bind_all("<space>",lambda e:self.estop())
 def header(self):
  f=ttk.Frame(self,padding=8);f.pack(fill="x");ttk.Label(f,text=f"PTZ Patrol Controller v{VERSION}",font=("Segoe UI",16,"bold")).pack(side="left");ttk.Label(f,text="ACTIVE CAMERA").pack(side="left",padx=(30,5));self.combo=ttk.Combobox(f,textvariable=self.active_var,state="readonly",width=30);self.combo.pack(side="left");self.combo.bind("<<ComboboxSelected>>",lambda e:self.activate_name());self.detail=ttk.Label(f,text="No camera");self.detail.pack(side="left",padx=10);ttk.Label(f,textvariable=self.video_var).pack(side="right",padx=10);ttk.Button(f,text="EMERGENCY STOP",command=self.estop).pack(side="right")
 def tabs(self):
  self.nb=ttk.Notebook(self);self.nb.pack(fill="both",expand=True,padx=8);self.t={}
  for n in self.TABS:q=ttk.Frame(self.nb,padding=10);self.nb.add(q,text=n);self.t[n]=q
  self.dashboard();self.live();self.ptz();self.patrol();self.discovery();self.setup();self.diagnostics();self.logs();self.settings()
 def dashboard(self):
  f=self.t["DASHBOARD"];self.tree=ttk.Treeview(f,columns=("name","host","port","active"),show="headings");[(self.tree.heading(c,text=t),self.tree.column(c,width=w)) for c,t,w in (("name","Name",200),("host","Host",140),("port","ONVIF",80),("active","State",90))];self.tree.pack(side="left",fill="both",expand=True);self.tree.bind("<<TreeviewSelect>>",lambda e:self.activate(self.tree.selection()[0]) if self.tree.selection() else None);self.radar=Radar(f);self.radar.pack(side="right",fill="both",expand=True,padx=(10,0))
 def live(self):
  f=self.t["LIVE VIEW"];b=ttk.Frame(f);b.pack(fill="x");ttk.Button(b,text="Start / Reconnect",command=self.start_video).pack(side="left");ttk.Button(b,text="Stop",command=self.stop_video).pack(side="left");ttk.Button(b,text="Discover Stream URI",command=self.stream_uri).pack(side="left");self.vlabel=tk.Label(f,bg="black",fg="white",text="Selected-camera video is OFF",font=("Segoe UI",16));self.vlabel.pack(fill="both",expand=True,pady=8);self.photo=None
 def ptz(self):
  f=self.t["PTZ CONTROL"];g=ttk.LabelFrame(f,text="Finite pulse movement",padding=10);g.pack(side="left")
  for text,x,y,r,c in [("↖",-1,1,0,0),("↑",0,1,0,1),("↗",1,1,0,2),("←",-1,0,1,0),("STOP",0,0,1,1),("→",1,0,1,2),("↙",-1,-1,2,0),("↓",0,-1,2,1),("↘",1,-1,2,2)]:ttk.Button(g,text=text,width=9,command=self.estop if text=="STOP" else lambda x=x,y=y:self.pulse(x,y)).grid(row=r,column=c,padx=3,pady=3,ipady=8)
  ttk.Button(g,text="Zoom +",command=lambda:self.pulse(0,0,1)).grid(row=3,column=0);ttk.Button(g,text="Zoom -",command=lambda:self.pulse(0,0,-1)).grid(row=3,column=2)
  s=ttk.LabelFrame(f,text="Motion profile",padding=10);s.pack(side="left",fill="both",expand=True,padx=10);self.mv={k:tk.StringVar() for k in ("pan_speed","tilt_speed","zoom_speed","pulse_ms","gap_ms","pan_min","pan_max","tilt_min","tilt_max")}
  for i,k in enumerate(self.mv):ttk.Label(s,text=k).grid(row=i,column=0,sticky="w");ttk.Entry(s,textvariable=self.mv[k]).grid(row=i,column=1)
  ttk.Button(s,text="Apply",command=self.apply).grid(row=10,columnspan=2,sticky="ew");ttk.Button(s,text="Set calibration zero",command=self.cal_zero).grid(row=11,columnspan=2,sticky="ew");ttk.Button(s,text="Set display forward",command=self.forward).grid(row=12,columnspan=2,sticky="ew");ttk.Button(s,text="Mark UNSYNCED",command=self.unsync).grid(row=13,columnspan=2,sticky="ew")
 def patrol(self):
  f=self.t["PATROL & AUTOMATION"];top=ttk.Frame(f);top.pack(fill="x");[(ttk.Button(top,text=t,command=c).pack(side="left")) for t,c in (("Start",self.start_patrol),("Pause",lambda:self.patrol_pause.set()),("Resume",lambda:self.patrol_pause.clear()),("Stop",self.stop_patrol),("Office-fan template",self.office))];self.ptree=ttk.Treeview(f,columns=("exec","pan","tilt","dwell","label"),show="headings");[(self.ptree.heading(c,text=c.upper()),self.ptree.column(c,width=110)) for c in ("exec","pan","tilt","dwell","label")];self.ptree.pack(fill="both",expand=True);self.mode=tk.StringVar(value="PING_PONG");ttk.Combobox(f,textvariable=self.mode,values=("ONCE","FOREVER","PING_PONG"),state="readonly").pack(anchor="w");self.refresh_steps()
 @staticmethod
 def ping_pong(s):return s[:] if len(s)<3 else s+s[-2:0:-1]
 def start_patrol(self):
  if getattr(self,"pth",None) and self.pth.is_alive():return
  self.patrol_stop.clear();self.patrol_pause.clear();self.pth=threading.Thread(target=self.patrol_loop,daemon=True);self.pth.start()
 def patrol_loop(self):
  cam=self.cam();w=self.workers.get(self.active);base=[s for s in sorted(self.steps,key=lambda x:x.exec_no) if s.enabled]
  if not cam or not w:return
  while not self.patrol_stop.is_set():
   seq=self.ping_pong(base) if self.mode.get()=="PING_PONG" else base
   for s in seq:
    while self.patrol_pause.is_set() and not self.patrol_stop.wait(.1):pass
    for _ in range(abs(s.pan)):
     if self.patrol_stop.is_set():break
     done=threading.Event();w.put("call",lambda m,d=1 if s.pan>0 else -1,e=done:(m.pulse(d,0),e.set()));done.wait(6)
    for _ in range(abs(s.tilt)):
     if self.patrol_stop.is_set():break
     done=threading.Event();w.put("call",lambda m,d=1 if s.tilt>0 else -1,e=done:(m.pulse(0,d),e.set()));done.wait(6)
    end=time.monotonic()+s.dwell_s
    while time.monotonic()<end and not self.patrol_stop.wait(.1):pass
   if self.mode.get()=="ONCE":break
 def stop_patrol(self):self.patrol_stop.set();self.estop()
 def discovery(self):
  f=self.t["DISCOVERY"];ttk.Label(f,text="Safe local /24 TCP check. No brute force or unrestricted port scan.").pack(anchor="w");r=ttk.Frame(f);r.pack(fill="x");self.subnet=tk.StringVar(value="192.168.1");self.dport=tk.IntVar(value=8899);ttk.Entry(r,textvariable=self.subnet).pack(side="left");ttk.Entry(r,textvariable=self.dport,width=8).pack(side="left");ttk.Button(r,text="QUICK 1-32",command=self.scan).pack(side="left");self.dtext=tk.Text(f);self.dtext.pack(fill="both",expand=True)
 def scan(self):
  self.dtext.delete("1.0","end")
  def x():
   for i in range(1,33):
    h=f"{self.subnet.get()}.{i}"
    try:
     with socket.create_connection((h,self.dport.get()),timeout=.12):self.events.put(("discovery","",f"POSSIBLE ONVIF {h}:{self.dport.get()}\n"))
    except OSError:pass
  threading.Thread(target=x,daemon=True).start()
 def setup(self):
  f=self.t["CAMERA SETUP"];ttk.Button(f,text="Add camera",command=self.add_camera).pack(anchor="w");ttk.Label(f,text="Production cameras only; no mock camera creation.").pack(anchor="w")
 def diagnostics(self):
  f=self.t["DIAGNOSTICS"];ttk.Button(f,text="Read-only report",command=self.diag).pack(anchor="w");self.xtext=tk.Text(f);self.xtext.pack(fill="both",expand=True)
 def logs(self):
  f=self.t["LOGS & REPORTS"];ttk.Button(f,text="Refresh",command=self.log_refresh).pack(anchor="w");self.ltext=tk.Text(f);self.ltext.pack(fill="both",expand=True)
 def settings(self):
  f=self.t["SETTINGS"];ttk.Button(f,text="Save all settings",command=self.save).pack(anchor="w");ttk.Label(f,text="Production behavior only. No simulated hardware success.").pack(anchor="w")
 def cam(self):return self.cams.get(self.active)
 def refresh_cameras(self):
  self.combo["values"]=[f"{c.name} [{c.camera_id}]" for c in self.cams.values()]
  for i in self.tree.get_children():self.tree.delete(i)
  for c in self.cams.values():self.tree.insert("","end",iid=c.camera_id,values=(c.name,c.host,c.onvif_port,"ACTIVE" if c.camera_id==self.active else ""))
 def refresh_steps(self):
  for i in self.ptree.get_children():self.ptree.delete(i)
  for i,s in enumerate(sorted(self.steps,key=lambda x:x.exec_no)):self.ptree.insert("","end",iid=str(i),values=(s.exec_no,s.pan,s.tilt,s.dwell_s,s.label))
 def activate_name(self):
  m=re.search(r"\[([^]]+)\]$",self.active_var.get());self.activate(m.group(1)) if m else None
 def activate(self,cid,start=True):
  if cid not in self.cams:return
  if self.active and self.active!=cid:self.workers.get(self.active).put("stop",p=0) if self.active in self.workers else None;self.stop_video()
  self.active=cid;c=self.cam();self.active_var.set(f"{c.name} [{cid}]");self.detail.config(text=f"{c.host}:{c.onvif_port} | {c.reliability}");self.radar.cam=c;self.radar.draw();self.refresh_cameras();[v.set(str(getattr(c,k))) for k,v in self.mv.items()];self.status.set(f"Active camera: {c.name}");self.start_video() if start else None
 def pulse(self,x,y,z=0):
  w=self.workers.get(self.active);w.put("pulse",(x,y,z),20) if w else self.status.set("COMMAND NOT SENT: no active worker")
 def estop(self):self.patrol_stop.set();[w.put("stop",p=0) for w in self.workers.values()];self.status.set("Emergency Stop queued for every camera")
 def apply(self):
  c=self.cam();old=(c.pan_speed,c.tilt_speed,c.pulse_ms)
  try:
   for k,v in self.mv.items():setattr(c,k,float(v.get()) if "speed" in k else int(v.get()))
   c.normalize();c.reliability="UNSYNCED" if old!=(c.pan_speed,c.tilt_speed,c.pulse_ms) else c.reliability;self.save();self.radar.draw()
  except Exception as e:messagebox.showerror("Invalid",str(e))
 def cal_zero(self):c=self.cam();c.calibration_zero_step=c.pan_step;c.calibration_speed=c.pan_speed;c.calibration_pulse_ms=c.pulse_ms;c.reliability="CALIBRATED_ESTIMATE";self.save();self.radar.draw()
 def forward(self):c=self.cam();c.display_forward_step=c.pan_step;self.save();self.radar.draw()
 def unsync(self):self.cam().reliability="UNSYNCED";self.radar.draw()
 def office(self):self.steps=[Step(10,0,0,120,"MAIN"),Step(20,-6,0,15,"LEFT BLIND"),Step(30,6,0,120,"MAIN"),Step(40,6,0,15,"RIGHT BLIND")];self.refresh_steps();self.save()
 def add_camera(self):
  h=simpledialog.askstring("Host","Camera IPv4 or hostname")
  if not h:return
  cid="cam_"+re.sub(r"\W","_",h);c=Camera(cid,h,h);c.normalize();self.cams[cid]=c;w=Worker(c,self.events);self.workers[cid]=w;w.start();self.activate(cid,False);self.save()
 def stream_uri(self):
  c=self.cam()
  def x():
   r,u=Soap(c).stream()
   if r.ok and u:c.stream_uri=u;self.save();self.events.put(("video",c.camera_id,f"URI discovered: {mask_uri(u)}"))
   else:self.events.put(("video",c.camera_id,f"VIDEO ERROR: {r.message}"))
  threading.Thread(target=x,daemon=True).start()
 def start_video(self):
  c=self.cam();self.stop_video()
  if not c or not c.stream_uri:self.video_var.set("VIDEO ERROR: URI unknown");return
  u=c.stream_uri
  if c.username and "@" not in u:q=urllib.parse.urlsplit(u);u=urllib.parse.urlunsplit((q.scheme,f"{urllib.parse.quote(c.username)}:{urllib.parse.quote(c.password)}@{q.netloc}",q.path,q.query,q.fragment))
  self.video=Video(u,self.frames,self.events,c.camera_id);self.video.start()
 def stop_video(self):
  if self.video:self.video.quit.set();self.video.join(2);self.video=None
  if hasattr(self,"vlabel"):self.vlabel.config(image="",text="Selected-camera video is OFF");self.photo=None
 def diag(self):
  c=self.cam()
  def x():
   s=Soap(c);r,d=s.status();ur,u=s.stream();rep={"utc":now(),"camera":c.camera_id,"status_result":dataclasses.asdict(r),"position":d,"stream_result":dataclasses.asdict(ur),"stream_uri":mask_uri(u),"note":"Read-only success is not physical movement proof."};p=DIAG/f"report_{c.camera_id}_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json";p.write_text(json.dumps(rep,indent=2),encoding="utf-8");self.events.put(("diag",c.camera_id,json.dumps(rep,indent=2)))
  threading.Thread(target=x,daemon=True).start()
 def log_refresh(self):
  p=LOGS/"application.log";self.ltext.delete("1.0","end");self.ltext.insert("end",p.read_text(errors="replace")[-40000:] if p.exists() else "No log")
 def save(self):self.store.save(self.cams,self.steps,self.active)
 def poll(self):
  try:
   while True:
    k,c,m=self.events.get_nowait()
    if k=="position":self.radar.draw()
    elif k=="video":self.video_var.set(m)
    elif k=="discovery":self.dtext.insert("end",m)
    elif k=="diag":self.xtext.delete("1.0","end");self.xtext.insert("end",m)
    else:self.status.set(f"{c}: {m}")
  except queue.Empty:pass
  self.after(100,self.poll)
 def frame(self):
  try:
   f=self.frames.get_nowait()
   if cv2 is not None and Image is not None:im=Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB));im.thumbnail((max(320,self.vlabel.winfo_width()),max(240,self.vlabel.winfo_height())));self.photo=ImageTk.PhotoImage(im);self.vlabel.config(image=self.photo,text="")
  except queue.Empty:pass
  self.after(50,self.frame)
 def close(self):
  if not messagebox.askokcancel("Exit","Stop cameras and exit?"):return
  self.patrol_stop.set();self.stop_video();[w.put("quit",p=0) for w in self.workers.values()];[w.join(3) for w in self.workers.values()];self.save();self.destroy()
def main():
 if "--version" in sys.argv:print(VERSION);return 0
 App().mainloop();return 0
if __name__=="__main__":raise SystemExit(main())
