@echo off
cd /d "%~dp0"
py -3 self_test_v2_3_0.py
if errorlevel 1 (echo FAILED) else (echo ALL PASSED)
pause
