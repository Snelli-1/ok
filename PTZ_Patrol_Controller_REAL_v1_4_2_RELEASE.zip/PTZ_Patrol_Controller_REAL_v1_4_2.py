#!/usr/bin/env python3
"""PTZ Patrol Controller REAL v1.4.2: multi-camera, round-robin patrol, radar tiles."""
import configparser,logging,math,queue,threading,time,traceback
from dataclasses import dataclass,field
from pathlib import Path
from typing import List,Optional
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from real_onvif_camera_v1_4_2 import RealOnvifCamera,PTZStatus
BASE=Path(__file__).resolve().parent;CFG=BASE/'config_REAL_v1_4_2.ini';LOGDIR=BASE/'logs_real';LOGDIR.mkdir(exist_ok=True)
logging.basicConfig(filename=LOGDIR/'application_REAL_v1_4_2.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(threadName)s %(message)s')
@dataclass
class Point:name:str;pan:float;tilt:float;zoom:float;dwell_s:float=5.0;speed:float=.5
@dataclass
class Cam:
 id:str;name:str;host:str;port:int=8899;rtsp:int=554;enabled:bool=True;points:List[Point]=field(default_factory=list);api:Optional[RealOnvifCamera]=None;state:str='DISCONNECTED';last_error:str='';step:int=0;due:float=0.0;heading_deg:float=0.0;tilt_steps:int=0;zoom_est:float=0.0;confidence:str='UNSYNCED';pan_step:int=0;left_limit:int=26;right_limit:int=26;manual_override:bool=False;camera_status:PTZStatus=field(default_factory=PTZStatus);camera_utc:str='';clock_skew_s:Optional[float]=None;last_ok:float=0.0
class Radar(tk.Canvas):
 def __init__(self,parent,size=180,**kw):super().__init__(parent,width=size,height=size,bg='#071d12',highlightthickness=1,highlightbackground='#488a5d',**kw);self.cam=None;self.bind('<Configure>',lambda e:self.draw())
 def set_cam(self,cam):self.cam=cam;self.draw()
 def draw(self):
  self.delete('all');w=max(self.winfo_width(),80);h=max(self.winfo_height(),80);cx=w/2;cy=h/2+5;r=min(w,h)*.34
  self.create_oval(cx-r,cy-r,cx+r,cy+r,fill='#083b22',outline='#62ff94',width=2)
  for f in (.33,.66):self.create_oval(cx-r*f,cy-r*f,cx+r*f,cy+r*f,outline='#1c7544')
  self.create_line(cx-r,cy,cx+r,cy,fill='#1c7544');self.create_line(cx,cy-r,cx,cy+r,fill='#1c7544')
  for deg,label in [(0,'0°'),(90,'90°'),(180,'180°'),(270,'270°')]:
   a=math.radians(deg);self.create_text(cx+math.cos(a)*r*1.17,cy-math.sin(a)*r*1.17,text=label,fill='#c7ffd5',font=('Segoe UI',8))
  cam=self.cam
  if not cam:self.create_text(cx,cy,text='NO CAM',fill='white');return
  angle=math.radians(max(-180.0,min(180.0,cam.pan_step*(360.0/52.0))));length=r*(.72+.2*max(0,min(1,cam.zoom_est)));x=cx+math.cos(angle)*length;y=cy-math.sin(angle)*length
  color={'CALIBRATED':'#7cff38','ESTIMATED':'#ffd34e','UNSYNCED':'#ff5a5a'}.get(cam.confidence,'#ffd34e')
  self.create_line(cx,cy,x,y,fill=color,width=4,arrow=tk.LAST);self.create_oval(cx-4,cy-4,cx+4,cy+4,fill=color,outline='')
  self.create_text(cx,12,text=cam.name,fill='white',font=('Segoe UI',10,'bold'));self.create_text(cx,h-12,text=f'S{cam.pan_step:+d}  {cam.heading_deg:+06.1f}°  {cam.confidence}',fill=color,font=('Consolas',8,'bold'))
class Controller:
 def __init__(self,cams,emit):self.cams=cams;self.emit=emit;self.stop_evt=threading.Event();self.pause_evt=threading.Event();self.thread=None;self.lock=threading.RLock()
 def connect(self,c):
  c.state='CONNECTING';self.emit(c.id,f'Connecting {c.host}:{c.port}')
  try:
   c.api=RealOnvifCamera(c.host,c.port,c.rtsp,logger=lambda s:self.emit(c.id,s));desc=c.api.connect();c.camera_status=c.api.last_status;c.camera_utc,c.clock_skew_s=c.api.system_time();c.last_ok=time.time();c.state='READY';c.last_error='';self.emit(c.id,'CONNECTED '+str(desc));return True
  except Exception as e:c.state='ERROR';c.last_error=str(e);self.emit(c.id,'CONNECT ERROR '+str(e));logging.error(traceback.format_exc());return False
 def connect_all(self):
  for c in self.cams:
   if c.enabled:self.connect(c)
 def start(self):
  if self.thread and self.thread.is_alive():return
  self.stop_evt.clear();self.thread=threading.Thread(target=self.loop,name='RoundRobinPatrol',daemon=True);self.thread.start()
 def loop(self):
  self.emit('SYSTEM','CONTINUOUS ROUND-ROBIN PATROL STARTED')
  while not self.stop_evt.is_set():
   if self.pause_evt.is_set():time.sleep(.1);continue
   worked=False
   for c in list(self.cams):
    if self.stop_evt.is_set():break
    if not c.enabled or not c.points or c.manual_override:continue
    if not c.api or not c.api.connected:
     if not self.connect(c):time.sleep(.4);continue
    if time.monotonic()<c.due:continue
    p=c.points[c.step%len(c.points)];c.state='MOVING '+p.name;self.emit(c.id,f'PATROL {p.name}: pan={p.pan:.3f}, tilt={p.tilt:.3f}, zoom={p.zoom:.3f}, speed={p.speed:.3f}')
    try:
     target_step=max(-c.left_limit,min(c.right_limit,round(p.pan*26)));bounded_pan=target_step/26.0;c.api.absolute_move(bounded_pan,p.tilt,p.zoom,p.speed);c.pan_step=target_step;c.heading_deg=c.pan_step*(360.0/52.0);c.tilt_steps=round(p.tilt*13);c.zoom_est=p.zoom;c.confidence='ESTIMATED';time.sleep(.25);c.camera_status=c.api.status();c.camera_utc,c.clock_skew_s=c.api.system_time();c.last_ok=time.time();c.step=(c.step+1)%len(c.points);c.due=time.monotonic()+max(.2,p.dwell_s);c.state=f'DWELL {p.dwell_s:.1f} s';worked=True
    except Exception as e:c.state='ERROR';c.last_error=str(e);c.confidence='UNSYNCED';c.api.connected=False;self.emit(c.id,'PATROL ERROR '+str(e));logging.error(traceback.format_exc())
    time.sleep(.05)
   if not worked:time.sleep(.1)
  self.emit('SYSTEM','PATROL STOPPED')
 def pause(self):
  if self.pause_evt.is_set():self.pause_evt.clear();self.emit('SYSTEM','RESUMED')
  else:self.pause_evt.set();self.emit('SYSTEM','PAUSED')
 def stop(self):
  self.stop_evt.set()
  for c in self.cams:
   if c.api:
    try:c.api.stop();c.state='STOPPED'
    except Exception as e:self.emit(c.id,'STOP ERROR '+str(e))
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('PTZ Patrol Controller REAL v1.4.2');self.geometry('1440x900');self.minsize(1120,720);self.q=queue.Queue();self.cams=self.load();self.ctrl=Controller(self.cams,self.emit);self.selected=self.cams[0] if self.cams else None;self.tiles={};self.key_active=set();self.build();self.bind_keyboard();self.after(150,self.tick);self.protocol('WM_DELETE_WINDOW',self.close)
 def defaults(self):return [Cam('camera_1','Macro Video IPCamera','192.168.1.102',points=[Point('CENTER',0,0,0,5,.5),Point('LEFT',-.6,0,0,5,.5),Point('RIGHT',.6,0,0,5,.5)])]
 def load(self):
  if not CFG.exists():return self.defaults()
  cp=configparser.ConfigParser();cp.read(CFG,encoding='utf-8');out=[]
  for s in cp.sections():
   if not s.startswith('CAMERA:'):continue
   c=Cam(s.split(':',1)[1],cp.get(s,'name',fallback=s),cp.get(s,'host'),cp.getint(s,'onvif_port',fallback=8899),cp.getint(s,'rtsp_port',fallback=554),cp.getboolean(s,'enabled',fallback=True),heading_deg=cp.getfloat(s,'heading_deg',fallback=0),tilt_steps=cp.getint(s,'tilt_steps',fallback=0),zoom_est=cp.getfloat(s,'zoom_est',fallback=0),confidence=cp.get(s,'confidence',fallback='UNSYNCED'),pan_step=cp.getint(s,'pan_step',fallback=0),left_limit=cp.getint(s,'left_limit',fallback=26),right_limit=cp.getint(s,'right_limit',fallback=26))
   for raw in cp.get(s,'points',fallback='').split('|'):
    try:n,p,t,z,d,v=[x.strip() for x in raw.split(',')];c.points.append(Point(n,float(p),float(t),float(z),float(d),float(v)))
    except Exception:pass
   out.append(c)
  return out or self.defaults()
 def save(self):
  cp=configparser.ConfigParser()
  for c in self.cams:cp[f'CAMERA:{c.id}']={'name':c.name,'host':c.host,'onvif_port':str(c.port),'rtsp_port':str(c.rtsp),'enabled':str(c.enabled).lower(),'heading_deg':str(c.heading_deg),'tilt_steps':str(c.tilt_steps),'zoom_est':str(c.zoom_est),'confidence':c.confidence,'pan_step':str(c.pan_step),'left_limit':str(c.left_limit),'right_limit':str(c.right_limit),'points':' | '.join(f'{p.name},{p.pan},{p.tilt},{p.zoom},{p.dwell_s},{p.speed}' for p in c.points)}
  with CFG.open('w',encoding='utf-8') as f:cp.write(f)
  self.emit('SYSTEM','Saved '+str(CFG))
 def build(self):
  style=ttk.Style();style.theme_use('clam');style.configure('Treeview',rowheight=25);style.configure('Danger.TButton',foreground='white',background='#9b1c1c');style.configure('Title.TLabel',font=('Segoe UI',11,'bold'))
  self.columnconfigure(0,weight=1);self.rowconfigure(1,weight=1)
  bar=ttk.Frame(self,padding=(8,6));bar.grid(row=0,column=0,sticky='ew')
  buttons=[('CONNECT SELECTED',self.connect_selected,''),('CONNECT ALL',lambda:self.bg(self.ctrl.connect_all),''),('START PATROL',self.ctrl.start,''),('PAUSE / RESUME',self.ctrl.pause,''),('EMERGENCY STOP',self.ctrl.stop,'Danger.TButton'),('SAVE',self.save,''),('ADD CAMERA',self.add_cam,''),('DELETE CAMERA',self.del_cam,'')]
  for col,(text,cmd,sty) in enumerate(buttons):ttk.Button(bar,text=text,command=cmd,style=sty).grid(row=0,column=col,padx=3,sticky='ew')
  ttk.Label(bar,text='Keyboard: arrows=PTZ  |  1-8=select camera  |  Space=STOP  |  +/-=zoom',foreground='#245').grid(row=1,column=0,columnspan=len(buttons),sticky='w',pady=(5,0))
  main=ttk.Panedwindow(self,orient='horizontal');main.grid(row=1,column=0,sticky='nsew',padx=8,pady=(0,8))
  left=ttk.Frame(main,padding=6,width=470);right=ttk.Frame(main,padding=6);main.add(left,weight=2);main.add(right,weight=5)
  left.pack_propagate(False)
  left.columnconfigure(0,weight=1);left.rowconfigure(5,weight=1)
  ttk.Label(left,text='CAMERAS',style='Title.TLabel').grid(row=0,column=0,sticky='w')
  self.tree=ttk.Treeview(left,columns=('key','name','ip','state'),show='headings',height=7)
  for n,w in [('key',42),('name',145),('ip',115),('state',135)]:self.tree.heading(n,text=n.upper());self.tree.column(n,width=w,stretch=n!='key')
  self.tree.grid(row=1,column=0,sticky='nsew',pady=(4,5));self.tree.bind('<<TreeviewSelect>>',self.select)
  ttk.Label(left,text='Protocol: ONVIF SOAP 1.2   |   Mouse hold and keyboard hold supported',font=('Segoe UI',9,'bold')).grid(row=2,column=0,sticky='w',pady=(0,5))
  controls=ttk.LabelFrame(left,text='MANUAL PTZ CONTROL',padding=8);controls.grid(row=3,column=0,sticky='ew',pady=4);controls.columnconfigure(0,weight=1);controls.columnconfigure(1,weight=1)
  pad=ttk.Frame(controls);pad.grid(row=0,column=0,rowspan=2,padx=(0,10));up=ttk.Button(pad,text='▲',width=7);up.grid(row=0,column=1,pady=2);leftb=ttk.Button(pad,text='◀',width=7);leftb.grid(row=1,column=0,padx=2);ttk.Button(pad,text='STOP',width=7,command=self.stop_selected).grid(row=1,column=1,padx=2);rightb=ttk.Button(pad,text='▶',width=7);rightb.grid(row=1,column=2,padx=2);down=ttk.Button(pad,text='▼',width=7);down.grid(row=2,column=1,pady=2)
  self.bind_hold(up,0,.15,0,0,1);self.bind_hold(leftb,-.15,0,0,-1,0);self.bind_hold(rightb,.15,0,0,1,0);self.bind_hold(down,0,-.15,0,0,-1)
  side=ttk.Frame(controls);side.grid(row=0,column=1,sticky='nsew');ttk.Button(side,text='ZOOM +   [ + ]',command=lambda:self.manual(0,0,.15,0,0)).pack(fill='x',pady=2);ttk.Button(side,text='ZOOM -   [ - ]',command=lambda:self.manual(0,0,-.15,0,0)).pack(fill='x',pady=2)
  ttk.Label(side,text='1 click = 6.923° Pan estimate',foreground='#555').pack(anchor='w',pady=(8,0))
  cal=ttk.LabelFrame(left,text='RADAR CALIBRATION / HARD BOUNDS',padding=7);cal.grid(row=4,column=0,sticky='ew',pady=4)
  ttk.Button(cal,text='SET CURRENT = 0°',command=self.zero).grid(row=0,column=0,padx=2);ttk.Button(cal,text='MARK CALIBRATED',command=self.calibrated).grid(row=0,column=1,padx=2);ttk.Button(cal,text='SET ± LIMITS',command=self.set_limits).grid(row=0,column=2,padx=2)
  statusf=ttk.LabelFrame(left,text='SELECTED CAMERA STATUS',padding=5);statusf.grid(row=5,column=0,sticky='nsew',pady=(4,0));statusf.columnconfigure(0,weight=1);statusf.rowconfigure(0,weight=1)
  self.status=tk.Text(statusf,height=15,bg='#12191b',fg='#d7f7df',font=('Consolas',9),wrap='word');self.status.grid(row=0,column=0,sticky='nsew');ss=ttk.Scrollbar(statusf,orient='vertical',command=self.status.yview);ss.grid(row=0,column=1,sticky='ns');self.status.configure(yscrollcommand=ss.set)
  right.columnconfigure(0,weight=1);right.rowconfigure(1,weight=4);right.rowconfigure(2,weight=2)
  top=ttk.LabelFrame(right,text='PATROL POINTS',padding=6);top.grid(row=0,column=0,sticky='ew');top.columnconfigure(0,weight=1)
  self.points=ttk.Treeview(top,columns=('name','pan','tilt','zoom','dwell','speed'),show='headings',height=4)
  for n,w in [('name',130),('pan',75),('tilt',75),('zoom',75),('dwell',85),('speed',75)]:self.points.heading(n,text=n.upper());self.points.column(n,width=w)
  self.points.grid(row=0,column=0,sticky='ew')
  entry=ttk.Frame(top);entry.grid(row=1,column=0,sticky='ew',pady=(5,0));self.vars={k:tk.StringVar(value=v) for k,v in [('name','POINT'),('pan','0'),('tilt','0'),('zoom','0'),('dwell','5'),('speed','0.5')]}
  for col,(k,v) in enumerate(self.vars.items()):ttk.Label(entry,text=k).grid(row=0,column=col*2,sticky='e');ttk.Entry(entry,textvariable=v,width=8).grid(row=0,column=col*2+1,padx=(2,7))
  ttk.Button(entry,text='ADD',command=self.add_point).grid(row=0,column=12,padx=2);ttk.Button(entry,text='DELETE',command=self.del_point).grid(row=0,column=13,padx=2)
  tiles=ttk.LabelFrame(right,text='CAMERA DIRECTION RADARS - software-estimated center line of sight',padding=6);tiles.grid(row=1,column=0,sticky='nsew',pady=6);self.tile_frame=tiles
  for col in range(4):tiles.columnconfigure(col,weight=1,uniform='radar')
  for row in range(2):tiles.rowconfigure(row,weight=1,uniform='radar')
  logf=ttk.LabelFrame(right,text='REAL OPERATION LOG',padding=5);logf.grid(row=2,column=0,sticky='nsew');logf.columnconfigure(0,weight=1);logf.rowconfigure(0,weight=1)
  self.log=tk.Text(logf,height=7,bg='#101517',fg='#d8f3dc',font=('Consolas',9),wrap='word');self.log.grid(row=0,column=0,sticky='nsew');ls=ttk.Scrollbar(logf,orient='vertical',command=self.log.yview);ls.grid(row=0,column=1,sticky='ns');self.log.configure(yscrollcommand=ls.set)
  self.refresh_all()
 def rebuild_tiles(self):
  for w in self.tile_frame.winfo_children():w.destroy()
  self.tiles={}
  for i,c in enumerate(self.cams[:8]):
   f=ttk.Frame(self.tile_frame,relief='solid',borderwidth=1);f.grid(row=i//4,column=i%4,sticky='nsew',padx=4,pady=4);r=Radar(f,150);r.pack(fill='both',expand=True);r.set_cam(c);f.bind('<Button-1>',lambda e,c=c:self.choose(c));r.bind('<Button-1>',lambda e,c=c:self.choose(c));self.tiles[c.id]=r
 def refresh_all(self):
  sel=self.selected.id if self.selected else None;self.tree.delete(*self.tree.get_children())
  for i,c in enumerate(self.cams):self.tree.insert('', 'end',iid=c.id,values=(i+1,c.name,c.host,c.state))
  if sel and self.tree.exists(sel):self.tree.selection_set(sel)
  self.rebuild_tiles();self.refresh_points()
 def refresh_points(self):
  self.points.delete(*self.points.get_children())
  if self.selected:
   for i,p in enumerate(self.selected.points):self.points.insert('', 'end',iid=str(i),values=(p.name,p.pan,p.tilt,p.zoom,p.dwell_s,p.speed))
 def choose(self,c):self.selected=c;self.tree.selection_set(c.id);self.refresh_points()
 def select(self,e=None):
  ids=self.tree.selection()
  if ids:self.selected=next((c for c in self.cams if c.id==ids[0]),None);self.refresh_points()
 def emit(self,cid,msg):self.q.put((cid,str(msg)));logging.info('[%s] %s',cid,msg)
 def bg(self,fn):threading.Thread(target=lambda:self.safe(fn),daemon=True).start()
 def safe(self,fn):
  try:fn()
  except Exception as e:self.emit('SYSTEM','ERROR '+str(e));logging.error(traceback.format_exc())
 def connect_selected(self):
  if self.selected:self.bg(lambda:self.ctrl.connect(self.selected))
 def bind_keyboard(self):
  self.bind_all('<KeyPress>',self.key_press,add='+');self.bind_all('<KeyRelease>',self.key_release,add='+')
 def editing_widget(self):
  w=self.focus_get();return isinstance(w,(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox,ttk.Spinbox))
 def key_press(self,event):
  if self.editing_widget():return
  key=event.keysym
  if key in self.key_active:return 'break'
  moves={'Left':(-.15,0,0,-1,0),'Right':(.15,0,0,1,0),'Up':(0,.15,0,0,1),'Down':(0,-.15,0,0,-1)}
  if key in moves:self.key_active.add(key);self.start_hold(*moves[key]);return 'break'
  if key in ('space','Escape'):self.ctrl.stop();return 'break'
  if key in ('plus','equal','KP_Add'):self.manual(0,0,.15,0,0);return 'break'
  if key in ('minus','KP_Subtract'):self.manual(0,0,-.15,0,0);return 'break'
  if key in tuple(str(i) for i in range(1,9)):
   i=int(key)-1
   if i<len(self.cams):self.choose(self.cams[i]);self.emit('SYSTEM',f'Keyboard selected camera {i+1}: {self.cams[i].name}')
   return 'break'
 def key_release(self,event):
  key=event.keysym
  if key in self.key_active:self.key_active.discard(key);self.end_hold();return 'break'
 def bind_hold(self,button,p,t,z,hstep,tstep):
  button.bind('<ButtonPress-1>',lambda e:self.start_hold(p,t,z,hstep,tstep))
  button.bind('<ButtonRelease-1>',lambda e:self.end_hold())
 def start_hold(self,p,t,z,hstep,tstep):
  if getattr(self,'hold_active',False):return
  c=self.selected
  if not c or not c.api or not c.api.connected:return messagebox.showerror('Not connected','Connect selected camera first.')
  self.hold_active=True;c.manual_override=True;self.emit(c.id,'MANUAL HOLD overrides patrol until button release')
  def worker():
   while self.hold_active and self.selected is c:
    if hstep<0 and c.pan_step<=-c.left_limit:self.emit(c.id,'LEFT HARD BOUND reached');break
    if hstep>0 and c.pan_step>=c.right_limit:self.emit(c.id,'RIGHT HARD BOUND reached');break
    try:
     c.api.continuous_move(p,t,z,.20)
     if hstep:c.pan_step=max(-c.left_limit,min(c.right_limit,c.pan_step+hstep));c.heading_deg=c.pan_step*(360.0/52.0)
     c.tilt_steps+=tstep;c.zoom_est=max(0,min(1,c.zoom_est+(.05 if z>0 else -.05 if z<0 else 0)));c.confidence='ESTIMATED' if c.confidence!='CALIBRATED' else 'CALIBRATED';c.last_ok=time.time()
    except Exception as e:c.confidence='UNSYNCED';c.last_error=str(e);self.emit(c.id,'HOLD ERROR '+str(e));break
   self.hold_active=False;c.manual_override=False
   try:c.api.stop();c.camera_status=c.api.status();c.camera_utc,c.clock_skew_s=c.api.system_time()
   except Exception as e:self.emit(c.id,'RELEASE STOP/STATUS ERROR '+str(e))
  threading.Thread(target=worker,name='ManualHold',daemon=True).start()
 def end_hold(self):
  self.hold_active=False
  c=self.selected
  if c:c.manual_override=False
 def manual(self,p,t,z,hstep,tstep):
  self.start_hold(p,t,z,hstep,tstep);self.after(260,self.end_hold)
 def stop_selected(self):
  if self.selected and self.selected.api:self.bg(self.selected.api.stop)
 def zero(self):
  if self.selected:self.selected.pan_step=0;self.selected.heading_deg=0;self.selected.confidence='ESTIMATED';self.emit(self.selected.id,'Current physical direction set as software 0°')
 def set_limits(self):
  if not self.selected:return
  value=simpledialog.askinteger('Hard boundary','Allowed steps to EACH side of zero:',initialvalue=self.selected.right_limit,minvalue=1,maxvalue=26)
  if value:self.selected.left_limit=value;self.selected.right_limit=value;self.selected.pan_step=max(-value,min(value,self.selected.pan_step));self.selected.heading_deg=self.selected.pan_step*(360.0/52.0);self.emit(self.selected.id,f'Hard bounds set to -{value} / +{value} steps')
 def calibrated(self):
  if self.selected:self.selected.confidence='CALIBRATED';self.emit(self.selected.id,'Radar estimate marked CALIBRATED')
 def add_point(self):
  if not self.selected:return
  try:self.selected.points.append(Point(self.vars['name'].get(),float(self.vars['pan'].get()),float(self.vars['tilt'].get()),float(self.vars['zoom'].get()),float(self.vars['dwell'].get()),float(self.vars['speed'].get())));self.refresh_points()
  except Exception as e:messagebox.showerror('Invalid point',str(e))
 def del_point(self):
  if not self.selected:return
  for i in sorted([int(x) for x in self.points.selection()],reverse=True):
   if 0<=i<len(self.selected.points):self.selected.points.pop(i)
  self.refresh_points()
 def add_cam(self):
  n=1
  while any(c.id==f'camera_{n}' for c in self.cams):n+=1
  host=simpledialog.askstring('Add camera','IP address:',initialvalue=f'192.168.1.{101+n}')
  if host:self.cams.append(Cam(f'camera_{n}',f'Camera {n}',host,points=[Point('CENTER',0,0,0)]));self.refresh_all()
 def del_cam(self):
  if self.selected and messagebox.askyesno('Delete',f'Delete {self.selected.name}?'):self.cams.remove(self.selected);self.selected=self.cams[0] if self.cams else None;self.refresh_all()
 def tick(self):
  while not self.q.empty():cid,msg=self.q.get();self.log.insert('end',f'[{time.strftime("%H:%M:%S")}] [{cid}] {msg}\n');self.log.see('end')
  for c in self.cams:
   if c.id in self.tiles:self.tiles[c.id].set_cam(c)
  if self.selected:
   c=self.selected;age=time.time()-c.last_ok if c.last_ok else None;s=c.camera_status;lines=[f'Name: {c.name}',f'Address: {c.host}:{c.port}',f'State: {c.state}',f'Last error: {c.last_error or "none"}',f'Last OK age: {age:.1f} s' if age is not None else 'Last OK: never',f'Camera UTC: {c.camera_utc or "unknown"}',f'Clock skew: {c.clock_skew_s:+.1f} s' if c.clock_skew_s is not None else 'Clock skew: unknown',f'ONVIF reported: pan={s.pan}, tilt={s.tilt}, zoom={s.zoom}',f'MoveStatus: {s.pan_tilt_state}/{s.zoom_state}',f'Radar source: SOFTWARE ESTIMATE',f'Pan step from zero: {c.pan_step:+d}',f'Left remaining: {c.pan_step+c.left_limit} steps',f'Right remaining: {c.right_limit-c.pan_step} steps',f'Hard bounds: -{c.left_limit} / +{c.right_limit} steps',f'Heading from zero: {c.heading_deg:+.3f}°',f'Tilt steps: {c.tilt_steps:+d}',f'Confidence: {c.confidence}',f'Calibration: 52 clicks/360° = {360/52:.6f}°/click'];self.status.delete('1.0','end');self.status.insert('end','\n'.join(lines))
  # Update camera rows without destroying selection and producing selection events.
  for c in self.cams:
   if self.tree.exists(c.id):self.tree.item(c.id,values=(self.cams.index(c)+1,c.name,c.host,c.state))
  self.after(500,self.tick)
 def close(self):self.ctrl.stop();self.save();self.destroy()
if __name__=='__main__':App().mainloop()
