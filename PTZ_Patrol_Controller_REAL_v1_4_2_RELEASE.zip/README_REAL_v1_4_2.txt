PTZ PATROL CONTROLLER REAL v1.4.2
=================================

GUI layout repair
- Stable two-column resizable layout.
- Left column: camera list, manual PTZ pad, calibration/bounds, status.
- Right column: compact patrol editor, expandable radar area, operation log.
- Scrollbars added to status and log.
- Camera list has a KEY column showing keyboard numbers 1-8.
- Manual PTZ buttons no longer drift around the status area.

Keyboard controls
- Arrow Left/Right: bounded Pan while held.
- Arrow Up/Down: Tilt while held.
- Release arrow key: final Stop.
- Number keys 1-8: select camera 1-8.
- Space or Escape: global emergency Stop.
- Plus or keypad Plus: one Zoom-in pulse.
- Minus or keypad Minus: one Zoom-out pulse.
- Keyboard shortcuts are ignored while typing into an Entry, Text, Combobox or Spinbox.

The existing -26/+26 Pan hard limits, remaining-step counters, calibration and manual
patrol override remain active for mouse and keyboard control.
