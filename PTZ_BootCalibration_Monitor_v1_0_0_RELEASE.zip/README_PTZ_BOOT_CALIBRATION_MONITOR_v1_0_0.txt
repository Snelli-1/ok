PTZ BOOT / SELF-CALIBRATION MONITOR v1.0.0
=========================================
Purpose: determine whether the camera's power-on PTZ self-calibration is observable through
standard ONVIF responses, and collect timing evidence if it is not directly exposed.

This tool is read-only. It sends no movement, reboot, reset, configuration-write, home,
or preset-write command.

Run:
1. Rename RUN_PTZ_BOOT_CALIBRATION_MONITOR_v1_0_0.bat.txt to .bat.
2. Keep the BAT and Python file together.
3. Double-click the BAT.
4. Once polling begins, power-cycle the camera exactly once.
5. Do not move the camera from another app during the 180 s test.
6. Return the PTZ_BOOT_CALIBRATION_*.txt file.

The log records:
- TCP port 8899 offline/online transitions during reboot.
- Device, service, media profile and PTZ-node responses.
- Search results for calibration/home/origin/initialization/vendor-extension keywords.
- GetStatus every 0.5 s for each media profile.
- Any changes in Pan, Tilt, Zoom, PanTilt MoveStatus, Zoom MoveStatus and camera UTC time.
- Exact chronology and elapsed seconds.

Interpretation:
- If MoveStatus becomes MOVING or Position changes during the startup sweep, standard
  GetStatus can observe calibration.
- If the camera visibly calibrates but GetStatus remains 0/0/0 and IDLE, calibration is
  internal and camera position must be estimated/calibrated in software.
- If a vendor extension appears, the returned XML gives us the next method to test.
