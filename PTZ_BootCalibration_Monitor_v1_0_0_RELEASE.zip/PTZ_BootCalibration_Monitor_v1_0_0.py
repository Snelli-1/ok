#!/usr/bin/env python3
"""Read-only PTZ boot/self-calibration monitor for a private-LAN ONVIF camera.
No movement, reboot, reset or configuration-write operations are sent.
"""
from __future__ import annotations
import argparse, http.client, json, os, re, socket, sys, time, traceback, urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

VERSION="1.0.0"
SOAP="http://www.w3.org/2003/05/soap-envelope"
TDS="http://www.onvif.org/ver10/device/wsdl"
TRT="http://www.onvif.org/ver10/media/wsdl"
TPTZ="http://www.onvif.org/ver20/ptz/wsdl"
TT="http://www.onvif.org/ver10/schema"

def local(tag):return tag.rsplit('}',1)[-1]
def env(body):return f'''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'''
def texts(root,name):return [(e.text or '').strip() for e in root.iter() if local(e.tag)==name and (e.text or '').strip()]
def tokens(root,names):
 out=[]
 for e in root.iter():
  if local(e.tag) in names:
   v=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
   if v and v not in out:out.append(v)
 return out
def xml_summary(root):
 out={}
 for e in root.iter():
  n=local(e.tag)
  if n in {'PanTilt','Zoom','MoveStatus','UtcTime','Name','XAddr','AuxiliaryCommands','HomeSupported','MaximumNumberOfPresets'}:
   val=(e.text or '').strip()
   if e.attrib:val=(val+' '+json.dumps(e.attrib,sort_keys=True)).strip()
   out.setdefault(n,[]).append(val)
 return out
class Log:
 def __init__(self,host):
  stamp=datetime.now().strftime('%Y%m%d_%H%M%S');dirs=[Path.cwd()/'PTZ_BOOT_CALIBRATION_LOGS',Path.home()/'Desktop'/'PTZ_BOOT_CALIBRATION_LOGS',Path(os.environ.get('TEMP','.'))/'PTZ_BOOT_CALIBRATION_LOGS']
  for d in dirs:
   try:d.mkdir(parents=True,exist_ok=True);self.path=d/f'PTZ_BOOT_CALIBRATION_{host}_{stamp}.txt';self.f=self.path.open('w',encoding='utf-8',buffering=1);break
   except Exception:continue
  self.seq=0;self.start=time.monotonic();self.write(f'PTZ BOOT/SELF-CALIBRATION MONITOR v{VERSION}\nTarget: {host}\nUTC start: {datetime.now(timezone.utc).isoformat()}\nREAD-ONLY: no PTZ movement, reboot, reset, preset write or configuration write is sent.\n')
 def write(self,s):print(s,flush=True);self.f.write(s+'\n');self.f.flush()
 def add(self,op,status,detail='',payload=''):
  self.seq+=1;line=f'[{self.seq:04d}] +{time.monotonic()-self.start:8.3f} s {datetime.now(timezone.utc).isoformat()} {op:<26} {status:<10} {detail}';self.write(line)
  if payload:self.write(payload)
 def close(self):
  try:self.f.flush();os.fsync(self.f.fileno());self.f.close()
  except Exception:pass

def post(url,body,timeout):
 u=urllib.parse.urlparse(url);c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=timeout);xml=env(body);st=time.monotonic()
 try:c.request('POST',u.path or '/',xml.encode(),{'Content-Type':'application/soap+xml; charset=utf-8','Connection':'close','User-Agent':'PTZ-BootCalibration-Monitor/1.0'});r=c.getresponse();text=r.read(2*1024*1024).decode('utf-8',errors='replace')
 finally:c.close()
 root=ET.fromstring(text)
 if any(local(e.tag)=='Fault' for e in root.iter()):raise RuntimeError('SOAP Fault: '+' | '.join(texts(root,'Text')+texts(root,'Value')))
 return root,r.status,int((time.monotonic()-st)*1000),text

def safe(log,op,url,body,timeout,full=False):
 st=time.monotonic()
 try:
  root,status,ms,text=post(url,body,timeout);summary=xml_summary(root);log.add(op,'SOAP_OK',f'HTTP {status}, {ms} ms, {json.dumps(summary,ensure_ascii=False)}',text if full else '');return root,text
 except socket.timeout as e:log.add(op,'TIMEOUT',str(e));return None,''
 except Exception as e:log.add(op,'FAIL',f'{type(e).__name__}: {e}',traceback.format_exc());return None,''

def parse_position(root):
 pan=tilt=zoom=None;pt=zs='';utc=''
 if root is None:return pan,tilt,zoom,pt,zs,utc
 for e in root.iter():
  n=local(e.tag)
  if n=='PanTilt' and 'x' in e.attrib:pan=float(e.attrib['x']);tilt=float(e.attrib.get('y',0))
  elif n=='Zoom' and 'x' in e.attrib:zoom=float(e.attrib['x'])
  elif n=='MoveStatus':
   for c in e:
    if local(c.tag)=='PanTilt':pt=(c.text or '').strip()
    elif local(c.tag)=='Zoom':zs=(c.text or '').strip()
  elif n=='UtcTime':utc=(e.text or '').strip()
 return pan,tilt,zoom,pt,zs,utc

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='192.168.1.102');ap.add_argument('--port',type=int,default=8899);ap.add_argument('--seconds',type=int,default=180);ap.add_argument('--interval',type=float,default=.5);ap.add_argument('--timeout',type=float,default=3);a=ap.parse_args()
 log=Log(a.host);device=f'http://{a.host}:{a.port}/onvif/device_service';media=f'http://{a.host}:{a.port}/onvif/media_service';ptz=f'http://{a.host}:{a.port}/onvif/ptz_service'
 try:
  log.add('INSTRUCTIONS','INFO','For best evidence: start this monitor, then power-cycle the camera. The monitor only observes.')
  # Initial service inventory and vendor-extension text search.
  for op,body in [('GetSystemDateAndTime','<tds:GetSystemDateAndTime/>'),('GetDeviceInformation','<tds:GetDeviceInformation/>'),('GetCapabilities','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>'),('GetServices','<tds:GetServices><tds:IncludeCapability>true</tds:IncludeCapability></tds:GetServices>')]:
   root,text=safe(log,op,device,body,a.timeout,True)
   if root:
    xs=texts(root,'XAddr');media=next((x for x in xs if 'media' in x.lower() and 'media2' not in x.lower()),media);ptz=next((x for x in xs if 'ptz' in x.lower()),ptz)
    hits=sorted(set(re.findall(r'(?i).{0,50}(?:calib|self.?test|initiali[sz]|home|zero|origin).{0,80}',text)))
    if hits:log.add(op+'_KEYWORDS','FOUND',json.dumps(hits,ensure_ascii=False))
  prof,_=safe(log,'GetProfiles',media,'<trt:GetProfiles/>',a.timeout,True);profiles=tokens(prof,{'Profiles','Profile'}) if prof else []
  log.add('PROFILE_TOKENS','INFO',json.dumps(profiles))
  nodes,node_text=safe(log,'GetNodes',ptz,'<tptz:GetNodes/>',a.timeout,True)
  safe(log,'GetConfigurations',ptz,'<tptz:GetConfigurations/>',a.timeout,True)
  if nodes:
   hits=sorted(set(re.findall(r'(?i).{0,50}(?:calib|self.?test|initiali[sz]|home|zero|origin|auxiliary).{0,100}',node_text)))
   log.add('PTZ_NODE_KEYWORDS','FOUND' if hits else 'NONE',json.dumps(hits,ensure_ascii=False))
  end=time.monotonic()+max(10,a.seconds);last=None;changes=0;online=False;first_online=None
  while time.monotonic()<end:
   # TCP reachability also captures reboot downtime and service-return time.
   st=time.monotonic()
   try:
    with socket.create_connection((a.host,a.port),a.timeout):pass
    if not online:online=True;first_online=time.monotonic();log.add('TCP_STATE','ONLINE',f'port {a.port} reachable after {int((time.monotonic()-st)*1000)} ms')
   except Exception as e:
    if online or first_online is None:log.add('TCP_STATE','OFFLINE',f'{type(e).__name__}: {e}')
    online=False;time.sleep(a.interval);continue
   if not profiles:
    prof,_=safe(log,'GetProfiles_retry',media,'<trt:GetProfiles/>',a.timeout);profiles=tokens(prof,{'Profiles','Profile'}) if prof else []
   for token in profiles[:2]:
    root,_=safe(log,'GetStatus',ptz,f'<tptz:GetStatus><tptz:ProfileToken>{token}</tptz:ProfileToken></tptz:GetStatus>',a.timeout)
    cur=parse_position(root)
    if cur!=last:
     changes+=1;log.add('STATUS_CHANGE','CHANGED',f'profile={token} previous={last} current={cur}');last=cur
   time.sleep(max(.1,a.interval))
  conclusion={'duration_s':a.seconds,'poll_interval_s':a.interval,'profiles':profiles,'status_changes':changes,'last_status':last,'interpretation':[]}
  if changes<=1:conclusion['interpretation'].append('GetStatus remained static; boot calibration position is not exposed through standard PTZ status, or no power-cycle occurred during monitoring.')
  else:conclusion['interpretation'].append('GetStatus changed during monitoring; compare timestamps with the physical startup sweep to determine whether calibration motion is observable.')
  conclusion['interpretation'].append('No standard ONVIF operation explicitly named PTZ calibration exists in the responses tested. Any calibration state may be firmware-internal or vendor-specific.')
  log.add('FINAL_CONCLUSION','INFO',json.dumps(conclusion,ensure_ascii=False,indent=2))
  return 0
 finally:
  log.add('LOG_PATH','INFO',str(log.path.resolve()));log.close();print(f'\nLOG FILE: {log.path.resolve()}')
if __name__=='__main__':raise SystemExit(main())
