#!/usr/bin/env python3
"""PTZ Patrol Controller REAL v1.5.0 - step patrol, full dashboard, selected live view."""
import configparser,math,queue,threading,time
from dataclasses import dataclass,field
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from real_onvif_camera_v1_5_0 import RealOnvifCamera
from bounded_pulse_engine_v1_5_0 import BoundedPulseEngine
BASE=Path(__file__).resolve().parent;CFG=BASE/'config_REAL_v1_5_0.ini'
@dataclass
class Point:name:str;pan:int;tilt:int;dwell:float
@dataclass
class Cam:
 id:str;name:str;host:str;port:int=8899;rtsp:int=554;enabled:bool=True;points:list=field(default_factory=list);api:object=None;engine:object=None;state:str='DISCONNECTED';pan_step:int=0;tilt_step:int=0;left_limit:int=26;right_limit:int=26;tilt_up_limit:int=13;tilt_down_limit:int=13;heading_deg:float=0;confidence:str='UNSYNCED';manual_override:bool=False;motion_owner:str='NONE';auto_index:int=0;pulse_ms:int=200;gap_ms:int=20;speed:float=.15;zoom_speed:float=.15;main_uri:str='';sub_uri:str='';preview_mode:str='MAIN';last_error:str=''
class Radar(tk.Canvas):
 def __init__(self,p,click=None):super().__init__(p,bg='#062718',height=145,highlightthickness=2);self.cam=None;self.click=click;self.bind('<Button-1>',lambda e:self.click(self.cam) if self.click and self.cam else None);self.bind('<Configure>',lambda e:self.draw())
 def set(self,c,selected=False):self.cam=c;self.configure(highlightbackground='#ffd43b' if selected else '#39805a');self.draw()
 def draw(self):
  self.delete('all');w=max(80,self.winfo_width());h=max(80,self.winfo_height());cx=w/2;cy=h/2;r=min(w,h)*.30
  for f in (1,.66,.33):self.create_oval(cx-r*f,cy-r*f,cx+r*f,cy+r*f,outline='#47e880')
  self.create_line(cx-r,cy,cx+r,cy,fill='#247944');self.create_line(cx,cy-r,cx,cy+r,fill='#247944')
  if self.cam:
   a=math.radians(self.cam.pan_step*360/52);self.create_line(cx,cy,cx+math.cos(a)*r*.9,cy-math.sin(a)*r*.9,fill='#baff35',width=3,arrow='last');self.create_text(cx,12,text=self.cam.name,fill='white');self.create_text(cx,h-12,text=f'P{self.cam.pan_step:+d} T{self.cam.tilt_step:+d} {self.cam.state}',fill='#baff35')
class Preview:
 def __init__(self,label,emit):self.label=label;self.emit=emit;self.stop_evt=threading.Event();self.thread=None;self.cam=None;self.photo=None
 def stop(self):self.stop_evt.set();self.thread=None;self.label.config(image='',text='PREVIEW STOPPED')
 def start(self,cam):
  self.stop();self.cam=cam;self.stop_evt=threading.Event();uri=cam.main_uri if cam.preview_mode=='MAIN' else cam.sub_uri
  def run():
   try:
    import cv2
    from PIL import Image,ImageTk
    cap=cv2.VideoCapture(uri);fails=0
    while not self.stop_evt.is_set():
     ok,frame=cap.read()
     if not ok:
      fails+=1
      if fails>20:raise RuntimeError('RTSP frames unavailable')
      time.sleep(.05);continue
     fails=0;frame=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB);im=Image.fromarray(frame);im.thumbnail((760,430));photo=ImageTk.PhotoImage(im)
     self.label.after(0,lambda ph=photo:self._show(ph))
    cap.release()
   except Exception as e:self.emit(cam.id,f'PREVIEW ERROR {e}');self.label.after(0,lambda:self.label.config(image='',text=f'LIVE VIEW UNAVAILABLE\n{uri}\n{e}'))
  self.label.config(text=f'OPENING {uri} ...');self.thread=threading.Thread(target=run,name='VideoPreview',daemon=True);self.thread.start()
 def _show(self,photo):self.photo=photo;self.label.config(image=photo,text='')
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('PTZ Patrol Controller REAL v1.5.0');self.geometry('1600x940');self.q=queue.Queue();self.cams=self.load();self.selected=self.cams[0];self.stop_evt=threading.Event();self.pause_evt=threading.Event();self.auto_thread=None;self.key_stamp={};self.key_timer={};self.mouse_cam=None;self.tiles={};self.mode='STOPPED';self.build();self.preview=Preview(self.video,self.emit);self.bind_keys();self.after(100,self.tick);self.protocol('WM_DELETE_WINDOW',self.close)
 def load(self):
  cp=configparser.ConfigParser();cp.read(CFG);out=[]
  for s in cp.sections():
   c=Cam(s,cp.get(s,'name'),cp.get(s,'host'),cp.getint(s,'port',fallback=8899),cp.getint(s,'rtsp_port',fallback=554),cp.getboolean(s,'enabled',fallback=True),left_limit=cp.getint(s,'left_limit',fallback=26),right_limit=cp.getint(s,'right_limit',fallback=26),tilt_up_limit=cp.getint(s,'tilt_up_limit',fallback=13),tilt_down_limit=cp.getint(s,'tilt_down_limit',fallback=13),pulse_ms=cp.getint(s,'pulse_duration_ms',fallback=200),gap_ms=cp.getint(s,'pulse_gap_ms',fallback=20),speed=cp.getfloat(s,'pan_tilt_speed',fallback=.15),zoom_speed=cp.getfloat(s,'zoom_speed',fallback=.15),main_uri=cp.get(s,'main_rtsp_uri',fallback=''),sub_uri=cp.get(s,'sub_rtsp_uri',fallback=''),preview_mode=cp.get(s,'preview_mode',fallback='MAIN'))
   for raw in cp.get(s,'points',fallback='CENTER,0,0,5').split('|'):
    n,p,t,d=[x.strip() for x in raw.split(',')];c.points.append(Point(n,int(p),int(t),float(d)))
   out.append(c)
  return out or [Cam('camera_1','Camera 1','192.168.1.102')]
 def save(self):
  cp=configparser.ConfigParser()
  for c in self.cams:cp[c.id]={'name':c.name,'host':c.host,'port':str(c.port),'rtsp_port':str(c.rtsp),'enabled':str(c.enabled),'left_limit':str(c.left_limit),'right_limit':str(c.right_limit),'tilt_up_limit':str(c.tilt_up_limit),'tilt_down_limit':str(c.tilt_down_limit),'pulse_duration_ms':str(c.pulse_ms),'pulse_gap_ms':str(c.gap_ms),'pan_tilt_speed':str(c.speed),'zoom_speed':str(c.zoom_speed),'main_rtsp_uri':c.main_uri,'sub_rtsp_uri':c.sub_uri,'preview_mode':c.preview_mode,'points':' | '.join(f'{p.name},{p.pan},{p.tilt},{p.dwell}' for p in c.points)}
  with CFG.open('w') as f:cp.write(f)
 def emit(self,c,m):self.q.put((c,m))
 def connect(self,c=None):
  c=c or self.selected;c.state='CONNECTING'
  try:c.api=RealOnvifCamera(c.host,c.port,logger=lambda x:self.emit(c.id,x));c.api.connect();c.engine=BoundedPulseEngine(c,self.emit,c.pulse_ms/1000,c.gap_ms/1000,c.speed,c.zoom_speed);c.state='READY';c.confidence='ESTIMATED';return True
  except Exception as e:c.state='ERROR';c.last_error=str(e);self.emit(c.id,str(e));return False
 def build(self):
  style=ttk.Style();style.theme_use('clam');style.configure('Danger.TButton',background='#a11',foreground='white')
  bar=ttk.Frame(self,padding=5);bar.pack(fill='x')
  for t,f,sty in [('CONNECT',lambda:threading.Thread(target=self.connect,daemon=True).start(),''),('CONNECT ALL',lambda:[threading.Thread(target=self.connect,args=(c,),daemon=True).start() for c in self.cams],''),('START PATROL',self.start_patrol,''),('PAUSE',self.pause,''),('EMERGENCY STOP',self.emergency,'Danger.TButton'),('SAVE',self.save,''),('ADD CAMERA',self.add_camera,''),('DELETE CAMERA',self.delete_camera,'')]:ttk.Button(bar,text=t,command=f,style=sty).pack(side='left',padx=2)
  self.mode_label=ttk.Label(bar,text='MODE: STOPPED',font=('Segoe UI',11,'bold'));self.mode_label.pack(side='right')
  settings=ttk.LabelFrame(self,text='SELECTED CAMERA SETTINGS',padding=5);settings.pack(fill='x',padx=6)
  self.vars={k:tk.StringVar() for k in ('camera','stream','pulse','gap','speed','zoom','left','right','tup','tdown')}
  specs=[('Camera', 'camera',14),('Stream','stream',7),('Pulse ms','pulse',7),('Gap ms','gap',7),('PT speed','speed',7),('Zoom speed','zoom',7),('Left limit','left',7),('Right limit','right',7),('Tilt up','tup',7),('Tilt down','tdown',7)]
  for i,(lab,key,w) in enumerate(specs):ttk.Label(settings,text=lab).grid(row=0,column=i*2);widget=ttk.Combobox(settings,textvariable=self.vars[key],width=w,values=['MAIN','SUB'],state='readonly') if key=='stream' else ttk.Entry(settings,textvariable=self.vars[key],width=w);widget.grid(row=0,column=i*2+1,padx=2)
  ttk.Button(settings,text='APPLY + SAVE',command=self.apply_settings).grid(row=0,column=20,padx=5);ttk.Button(settings,text='START VIDEO',command=lambda:self.preview.start(self.selected)).grid(row=0,column=21);ttk.Button(settings,text='STOP VIDEO',command=lambda:self.preview.stop()).grid(row=0,column=22)
  main=ttk.Panedwindow(self,orient='horizontal');main.pack(fill='both',expand=True,padx=6,pady=5);left=ttk.Frame(main,padding=4);right=ttk.Frame(main,padding=4);main.add(left,weight=2);main.add(right,weight=5)
  self.tree=ttk.Treeview(left,columns=('key','name','ip','state'),show='headings',height=7)
  for n,w in [('key',35),('name',150),('ip',120),('state',120)]:self.tree.heading(n,text=n.upper());self.tree.column(n,width=w)
  self.tree.pack(fill='x');self.tree.bind('<<TreeviewSelect>>',self.tree_select)
  manual=ttk.LabelFrame(left,text='MANUAL PTZ - HOLD',padding=6);manual.pack(fill='x',pady=4);g=ttk.Frame(manual);g.pack()
  for text,r,col,p,t in [('UP',0,1,0,1),('LEFT',1,0,-1,0),('RIGHT',1,2,1,0),('DOWN',2,1,0,-1)]:
   b=ttk.Button(g,text=text,width=9);b.grid(row=r,column=col,padx=2,pady=2);b.bind('<ButtonPress-1>',lambda e,p=p,t=t:self.hold(p,t,'MOUSE'));b.bind('<ButtonRelease-1>',lambda e:self.release('mouse release'))
  ttk.Button(g,text='STOP',command=lambda:self.release('stop')).grid(row=1,column=1)
  pat=ttk.LabelFrame(left,text='STEP PATROL POINTS',padding=5);pat.pack(fill='both',expand=True)
  self.points=ttk.Treeview(pat,columns=('name','pan','tilt','dwell'),show='headings',height=7)
  for n in ('name','pan','tilt','dwell'):self.points.heading(n,text=n.upper())
  self.points.pack(fill='both',expand=True);pf=ttk.Frame(pat);pf.pack(fill='x');ttk.Button(pf,text='ADD',command=self.add_point).pack(side='left');ttk.Button(pf,text='DELETE',command=self.del_point).pack(side='left');ttk.Button(pf,text='SET CURRENT AS POINT',command=self.current_point).pack(side='left')
  self.status=tk.Text(left,height=13,bg='#101719',fg='#d8f3dc',font=('Consolas',9));self.status.pack(fill='both',expand=True,pady=4)
  right.rowconfigure(1,weight=4);right.rowconfigure(2,weight=2);right.columnconfigure(0,weight=1)
  cards=ttk.LabelFrame(right,text='CAMERA RADARS - click to select',padding=4);cards.grid(row=0,column=0,sticky='ew')
  for i,c in enumerate(self.cams[:8]):r=Radar(cards,self.select_cam);r.grid(row=i//4,column=i%4,sticky='nsew',padx=3,pady=3);cards.columnconfigure(i%4,weight=1);self.tiles[c.id]=r
  vf=ttk.LabelFrame(right,text='SELECTED CAMERA LIVE VIEW',padding=4);vf.grid(row=1,column=0,sticky='nsew',pady=4);vf.rowconfigure(0,weight=1);vf.columnconfigure(0,weight=1)
  self.video=tk.Label(vf,text='VIDEO STOPPED',bg='black',fg='white',font=('Segoe UI',15));self.video.grid(row=0,column=0,sticky='nsew');self.overlay=ttk.Label(vf,text='');self.overlay.grid(row=1,column=0,sticky='ew')
  self.log=tk.Text(right,height=10,bg='#101719',fg='#d8f3dc',font=('Consolas',9));self.log.grid(row=2,column=0,sticky='nsew')
  self.refresh()
 def apply_settings(self):
  c=self.selected;self.release('settings change');old=(c.pulse_ms,c.speed);c.preview_mode=self.vars['stream'].get();c.pulse_ms=max(50,min(1000,int(self.vars['pulse'].get())));c.gap_ms=max(5,min(1000,int(self.vars['gap'].get())));c.speed=max(.05,min(1,float(self.vars['speed'].get())));c.zoom_speed=max(.05,min(1,float(self.vars['zoom'].get())));c.left_limit=int(self.vars['left'].get());c.right_limit=int(self.vars['right'].get());c.tilt_up_limit=int(self.vars['tup'].get());c.tilt_down_limit=int(self.vars['tdown'].get())
  if c.engine:c.engine.pulse_duration=c.pulse_ms/1000;c.engine.pulse_gap=c.gap_ms/1000;c.engine.pan_tilt_speed=c.speed;c.engine.zoom_speed=c.zoom_speed
  if old!=(c.pulse_ms,c.speed):c.confidence='UNSYNCED'
  self.save();self.emit(c.id,'settings applied')
 def load_settings(self):
  c=self.selected
  for k,v in [('camera',c.name),('stream',c.preview_mode),('pulse',c.pulse_ms),('gap',c.gap_ms),('speed',c.speed),('zoom',c.zoom_speed),('left',c.left_limit),('right',c.right_limit),('tup',c.tilt_up_limit),('tdown',c.tilt_down_limit)]:self.vars[k].set(str(v))
 def hold(self,p,t,owner):
  c=self.selected
  if not c.api and not self.connect(c):return
  c.engine.start_hold(p,t,0,owner);self.mouse_cam=c
 def release(self,reason):
  c=getattr(self,'mouse_cam',None) or self.selected
  if c.engine:c.engine.cancel_motion(reason,join=True,stop=True);c.motion_owner='NONE';c.manual_override=False;c.state='READY'
  self.mouse_cam=None
 def start_patrol(self):
  self.stop_evt.clear();self.pause_evt.clear();self.mode='RUNNING'
  if self.auto_thread and self.auto_thread.is_alive():return
  self.auto_thread=threading.Thread(target=self.auto_loop,daemon=True);self.auto_thread.start()
 def auto_loop(self):
  while not self.stop_evt.is_set():
   if self.pause_evt.is_set():time.sleep(.05);continue
   for c in self.cams:
    if self.stop_evt.is_set():break
    if not c.enabled or not c.points or c.manual_override:continue
    if not c.api and not self.connect(c):continue
    p=c.points[c.auto_index%len(c.points)];c.engine.cancel_motion('auto target',join=True,stop=True)
    with c.engine.lock:c.engine.generation+=1;c.engine.cancel=threading.Event();c.engine.owner='AUTOMATION';g=c.engine.generation
    c.state='AUTO_MOVING';c.engine.target_step=p.pan;self.emit(c.id,f'AUTO {p.name}: P{p.pan:+d} T{p.tilt:+d}')
    ok=True
    while (c.pan_step!=p.pan or c.tilt_step!=p.tilt) and not self.stop_evt.is_set() and not c.manual_override:
     pd=1 if p.pan>c.pan_step else -1 if p.pan<c.pan_step else 0;td=1 if p.tilt>c.tilt_step else -1 if p.tilt<c.tilt_step else 0
     if not c.engine.pulse(pd,td,0,g):ok=False;break
     if c.engine.cancel.wait(c.gap_ms/1000):ok=False;break
    if ok:c.state='AUTO_DWELL';end=time.monotonic()+p.dwell
    else:continue
    while time.monotonic()<end and not self.stop_evt.is_set() and not c.manual_override:time.sleep(.05)
    c.auto_index=(c.auto_index+1)%len(c.points);c.state='READY'
   time.sleep(.02)
  self.mode='STOPPED'
 def pause(self):self.pause_evt.set() if not self.pause_evt.is_set() else self.pause_evt.clear();self.mode='PAUSED' if self.pause_evt.is_set() else 'RUNNING'
 def emergency(self):
  self.stop_evt.set();self.mode='EMERGENCY';self.release('EMERGENCY')
  for c in self.cams:
   if c.engine:c.engine.cancel_motion('EMERGENCY',join=True,stop=True)
 def select_cam(self,c):
  if not c or c is self.selected:return
  self.release('camera switch');self.preview.stop();self.selected=c;self.refresh();self.preview.start(c)
 def tree_select(self,e=None):
  s=self.tree.selection()
  if s:self.select_cam(next(c for c in self.cams if c.id==s[0]))
 def bind_keys(self):self.bind_all('<KeyPress>',self.key_down);self.bind_all('<KeyRelease>',self.key_up);self.bind_all('<FocusOut>',lambda e:self.release('focus loss'));self.bind_all('<ButtonRelease-1>',lambda e:self.release('root release'),add='+')
 def editing(self):return isinstance(self.focus_get(),(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox))
 def key_down(self,e):
  if self.editing():return
  m={'Left':(-1,0),'Right':(1,0),'Up':(0,1),'Down':(0,-1)}
  if e.keysym in m:
   self.key_stamp[e.keysym]=time.monotonic();timer=self.key_timer.pop(e.keysym,None)
   if timer:self.after_cancel(timer)
   if not self.selected.engine or self.selected.engine.owner!='KEYBOARD':self.release('direction change');self.hold(*m[e.keysym],'KEYBOARD')
   return 'break'
  if e.keysym in ('space','Escape'):self.emergency();return 'break'
  if e.keysym.isdigit() and 1<=int(e.keysym)<=len(self.cams):self.select_cam(self.cams[int(e.keysym)-1]);return 'break'
 def key_up(self,e):
  if e.keysym in ('Left','Right','Up','Down'):
   def done(k=e.keysym):
    if time.monotonic()-self.key_stamp.get(k,0)>=.11:self.release('key release')
   self.key_timer[e.keysym]=self.after(120,done);return 'break'
 def add_camera(self):
  host=simpledialog.askstring('Add camera','IP address:')
  if host:self.cams.append(Cam(f'camera_{len(self.cams)+1}',f'Camera {len(self.cams)+1}',host,main_uri=f'rtsp://{host}/live/ch00_0',sub_uri=f'rtsp://{host}/live/ch00_1'));self.rebuild_cards();self.refresh()
 def delete_camera(self):
  if len(self.cams)>1:self.preview.stop();self.cams.remove(self.selected);self.selected=self.cams[0];self.rebuild_cards();self.refresh()
 def add_point(self):
  n=simpledialog.askstring('Point','Name:',initialvalue='POINT');p=simpledialog.askinteger('Point','Pan step:',initialvalue=self.selected.pan_step,minvalue=-self.selected.left_limit,maxvalue=self.selected.right_limit);t=simpledialog.askinteger('Point','Tilt step:',initialvalue=self.selected.tilt_step,minvalue=-self.selected.tilt_down_limit,maxvalue=self.selected.tilt_up_limit)
  if n is not None and p is not None and t is not None:self.selected.points.append(Point(n,p,t,5));self.refresh_points()
 def current_point(self):self.selected.points.append(Point(f'P{len(self.selected.points)+1}',self.selected.pan_step,self.selected.tilt_step,5));self.refresh_points()
 def del_point(self):
  s=self.points.selection()
  if s:self.selected.points.pop(self.points.index(s[0]));self.refresh_points()
 def rebuild_cards(self):pass
 def refresh_points(self):
  self.points.delete(*self.points.get_children())
  for p in self.selected.points:self.points.insert('', 'end',values=(p.name,p.pan,p.tilt,p.dwell))
 def refresh(self):
  self.tree.delete(*self.tree.get_children())
  for i,c in enumerate(self.cams):self.tree.insert('', 'end',iid=c.id,values=(i+1,c.name,c.host,c.state))
  self.tree.selection_set(self.selected.id);self.refresh_points();self.load_settings()
 def tick(self):
  while not self.q.empty():c,m=self.q.get();self.log.insert('end',f'[{time.strftime("%H:%M:%S")}] [{c}] {m}\n');self.log.see('end')
  c=self.selected;e=c.engine;self.status.delete('1.0','end');self.status.insert('end',f'Camera: {c.name}\nState: {c.state}\nOwner: {c.motion_owner}\nPan: {c.pan_step:+d} steps\nTilt: {c.tilt_step:+d} steps\nLeft remaining: {c.pan_step+c.left_limit} steps\nRight remaining: {c.right_limit-c.pan_step} steps\nPulse: {c.pulse_ms} ms\nGap: {c.gap_ms} ms\nSpeed: {c.speed:.2f}\nConfidence: {c.confidence}\nWorker: {e.alive() if e else False}\nLast error: {c.last_error or "none"}')
  self.overlay.config(text=f'{c.name} | {c.preview_mode} | PAN {c.pan_step:+d} steps ESTIMATED | TILT {c.tilt_step:+d} steps ESTIMATED | {c.state}')
  for cam in self.cams:
   if cam.id in self.tiles:self.tiles[cam.id].set(cam,cam is self.selected)
   if self.tree.exists(cam.id):self.tree.item(cam.id,values=(self.cams.index(cam)+1,cam.name,cam.host,cam.state))
  self.mode_label.config(text='MODE: '+self.mode);self.after(150,self.tick)
 def close(self):self.emergency();self.preview.stop();self.save();self.destroy()
if __name__=='__main__':App().mainloop()
