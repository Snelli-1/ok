#!/usr/bin/env python3
import sys,time,threading,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from bounded_pulse_engine_v1_5_0 import BoundedPulseEngine
class Transport:
 def __init__(self,fail_move_at=0,fail_stop_at=0):self.moves=[];self.stops=0;self.fail_move_at=fail_move_at;self.fail_stop_at=fail_stop_at
 def continuous_move(self,p,t,z):
  if self.fail_move_at and len(self.moves)+1==self.fail_move_at:raise RuntimeError('move fail')
  self.moves.append((p,t,z))
 def stop(self):
  self.stops+=1
  if self.fail_stop_at and self.stops==self.fail_stop_at:raise RuntimeError('stop fail')
class Cam:
 def __init__(self):
  self.id='test';self.api=Transport();self.pan_step=0;self.left_limit=26;self.right_limit=26;self.tilt_step=0;self.tilt_up_limit=13;self.tilt_down_limit=13;self.heading_deg=0;self.confidence='ESTIMATED';self.manual_override=False;self.motion_owner='NONE';self.state='READY'
def eng(cam=None):
 c=cam or Cam();e=BoundedPulseEngine(c,pulse_duration=0,pulse_gap=0);e.cancel.clear();return c,e
class Tests(unittest.TestCase):
 def test_01_right_26(self):
  c,e=eng()
  for _ in range(26):self.assertTrue(e.pulse(1))
  self.assertEqual(c.pan_step,26);self.assertEqual(len(c.api.moves),26)
 def test_02_27_block(self):
  c,e=eng();c.pan_step=26;self.assertFalse(e.pulse(1));self.assertEqual(len(c.api.moves),0)
 def test_03_full_left(self):
  c,e=eng();c.pan_step=26
  for _ in range(52):self.assertTrue(e.pulse(-1))
  self.assertEqual((c.pan_step,len(c.api.moves)),(-26,52))
 def test_04_release(self):
  c,e=eng();e.pulse_duration=.005;e.pulse_gap=.001;e.start_hold(1,owner='MOUSE');time.sleep(.02);e.cancel_motion('release');n=len(c.api.moves);time.sleep(.01);self.assertEqual(n,len(c.api.moves));self.assertFalse(e.alive())
 def test_05_repeat_model(self):
  c,e=eng();e.pulse_duration=.001;e.pulse_gap=.001;e.start_hold(1,owner='KEYBOARD');time.sleep(.012);self.assertTrue(len(c.api.moves)>1);e.cancel_motion()
 def test_06_reverse(self):
  c,e=eng();e.start_hold(1);time.sleep(.005);e.start_hold(-1);time.sleep(.005);e.cancel_motion();self.assertFalse(e.alive())
 def test_07_emergency_workers(self):
  c,e=eng();e.start_hold(1);time.sleep(.003);e.cancel_motion('EMERGENCY');self.assertFalse(e.alive())
 def test_08_automation_targets(self):
  c,e=eng()
  self.assertTrue(e.move_to(0));self.assertTrue(e.move_to(-16));self.assertTrue(e.move_to(16));self.assertEqual(c.pan_step,16);self.assertEqual(len(c.api.moves),48)
 def test_09_manual_override(self):
  c,e=eng();cancel=threading.Event();cancel.set();self.assertFalse(e.move_to(5,external_cancel=cancel));self.assertEqual(c.pan_step,0)
 def test_10_failed_move(self):
  c,e=eng();c.api=Transport(fail_move_at=1);self.assertFalse(e.pulse(1));self.assertEqual(c.pan_step,0)
 def test_11_failed_stop(self):
  c,e=eng();c.api=Transport(fail_stop_at=1);self.assertFalse(e.pulse(1));self.assertEqual(c.confidence,'UNSYNCED');self.assertEqual(c.pan_step,0)
 def test_12_switch_cancels(self):
  c,e=eng();e.start_hold(1);time.sleep(.003);e.cancel_motion('camera switch');self.assertFalse(e.alive())
 def test_13_radar_bounds(self):
  c,e=eng();c.pan_step=26;self.assertFalse(e.pulse(1));self.assertLessEqual(abs(c.pan_step),26)
 def test_14_static_motion_ownership(self):
  root=Path(__file__).resolve().parent
  bad=[]
  for f in ['PTZ_Patrol_Controller_REAL_v1_5_0.py']:
   t=(root/f).read_text()
   for token in ['.continuous_move(','.absolute_move(','.relative_move(']:
    if token in t:bad.append((f,token))
  self.assertEqual(bad,[])
if __name__=='__main__':unittest.main(verbosity=2)
