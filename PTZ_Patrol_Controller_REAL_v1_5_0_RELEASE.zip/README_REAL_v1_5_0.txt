PTZ PATROL CONTROLLER REAL v1.5.0 - MAJOR DEVELOPMENT
=====================================================
Major dashboard release built on the bounded pulse engine.

NEW
- Full two-column operations dashboard.
- Persistent per-camera settings bar: pulse ms, gap ms, Pan/Tilt speed, zoom speed,
  Pan hard limits, Tilt hard limits and MAIN/SUB preview selection.
- Up to 8 clickable camera radar cards. Selected radar, settings, PTZ controls,
  patrol points, status and live view always refer to the same selected camera.
- Dedicated RTSP preview worker using OpenCV and Pillow when installed.
- Main/sub RTSP URI storage per camera; preview failure is explicitly displayed.
- Pan and Tilt patrol targets use integer steps, not normalized coordinates.
- Diagonal automation pulses move Pan and Tilt together where possible.
- Default pulse gap reduced to 20 ms for a more fluid sequence.
- Add/delete camera and add/delete/save-current patrol point controls.
- Keyboard hold, mouse hold, 1-8 camera selection, Space/Escape Emergency Stop.

DEFAULT TIMING
Pulse duration 200 ms; gap 20 ms; Pan/Tilt velocity 0.15; Zoom velocity 0.15.
Changing pulse duration or velocity invalidates the physical calibration and marks
confidence UNSYNCED. Changing only gap controls fluidity without intentionally changing
one pulse's movement distance.

VIDEO REQUIREMENTS
Optional: pip install opencv-python pillow
Main: rtsp://192.168.1.102/live/ch00_0
Sub:  rtsp://192.168.1.102/live/ch00_1
Video decoding is isolated from PTZ and automation threads.

SAFETY
All physical movement remains gated by BoundedPulseEngine. Pan and Tilt counters commit
only after ContinuousMove and Stop both succeed. Position is still a software estimate.
