#!/usr/bin/env python3
"""Real ONVIF camera backend. Standard library only. No simulation paths."""
from __future__ import annotations
import http.client, time, urllib.parse, xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
SOAP="http://www.w3.org/2003/05/soap-envelope";TDS="http://www.onvif.org/ver10/device/wsdl";TRT="http://www.onvif.org/ver10/media/wsdl";TPTZ="http://www.onvif.org/ver20/ptz/wsdl";TT="http://www.onvif.org/ver10/schema"
def esc(s):return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def local(t):return t.rsplit('}',1)[-1]
def env(body):return f'''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{SOAP}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}"><s:Body>{body}</s:Body></s:Envelope>'''
def vals(root,name):return [(e.text or '').strip() for e in root.iter() if local(e.tag)==name and (e.text or '').strip()]
def toks(root,names):
 out=[]
 for e in root.iter():
  if local(e.tag) in names:
   v=e.attrib.get('token') or e.attrib.get(f'{{{TT}}}token')
   if v and v not in out:out.append(v)
 return out
@dataclass
class Position: pan:Optional[float];tilt:Optional[float];zoom:Optional[float];pan_tilt_status:str='';zoom_status:str=''
class OnvifError(RuntimeError):pass
class RealOnvifCamera:
 def __init__(self,host='192.168.1.102',port=8899,timeout=5.0,logger=None):
  self.host=host;self.port=int(port);self.timeout=float(timeout);self.logger=logger
  self.device=f'http://{host}:{port}/onvif/device_service';self.media=f'http://{host}:{port}/onvif/media_service';self.ptz=f'http://{host}:{port}/onvif/ptz_service';self.profiles=[];self.ptz_configs=[];self.presets={}
 def _log(self,msg):
  if self.logger:self.logger(msg)
 def _call(self,url,op,body):
  xml=env(body);u=urllib.parse.urlparse(url);c=http.client.HTTPConnection(u.hostname,u.port or 80,timeout=self.timeout);st=time.monotonic()
  try:
   c.request('POST',u.path or '/',xml.encode(),{'Content-Type':'application/soap+xml; charset=utf-8','Connection':'close'});r=c.getresponse();text=r.read(2*1024*1024).decode('utf-8',errors='replace')
  finally:c.close()
  self._log(f'{op} HTTP {r.status} {int((time.monotonic()-st)*1000)} ms')
  try:root=ET.fromstring(text)
  except Exception as e:raise OnvifError(f'{op}: non-XML response HTTP {r.status}: {e}')
  for e in root.iter():
   if local(e.tag)=='Fault':raise OnvifError(f'{op}: SOAP Fault: '+ ' | '.join(vals(root,'Text')+vals(root,'Value')))
  return root
 def connect(self):
  self._call(self.device,'GetSystemDateAndTime','<tds:GetSystemDateAndTime/>')
  cap=self._call(self.device,'GetCapabilities','<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>')
  xs=vals(cap,'XAddr')
  self.media=next((x for x in xs if 'media' in x.lower() and 'media2' not in x.lower()),self.media);self.ptz=next((x for x in xs if 'ptz' in x.lower()),self.ptz)
  prof=self._call(self.media,'GetProfiles','<trt:GetProfiles/>');self.profiles=toks(prof,{'Profiles','Profile'});self.ptz_configs=toks(prof,{'PTZConfiguration'})
  if not self.profiles:raise OnvifError('camera returned no media ProfileToken')
  self.refresh_presets();return self.describe()
 def describe(self):return {'host':self.host,'device_xaddr':self.device,'media_xaddr':self.media,'ptz_xaddr':self.ptz,'profiles':self.profiles,'ptz_configurations':self.ptz_configs,'presets':self.presets}
 def profile(self):
  if not self.profiles:self.connect()
  return self.profiles[0]
 def status(self):
  root=self._call(self.ptz,'GetStatus',f'<tptz:GetStatus><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken></tptz:GetStatus>')
  pan=tilt=zoom=None;ps=zs=''
  for e in root.iter():
   if local(e.tag)=='PanTilt' and 'x' in e.attrib:pan=float(e.attrib['x']);tilt=float(e.attrib['y'])
   elif local(e.tag)=='Zoom' and 'x' in e.attrib:zoom=float(e.attrib['x'])
   elif local(e.tag)=='MoveStatus':
    for c in e: 
     if local(c.tag)=='PanTilt':ps=(c.text or '').strip()
     elif local(c.tag)=='Zoom':zs=(c.text or '').strip()
  return Position(pan,tilt,zoom,ps,zs)
 def refresh_presets(self):
  if not self.profiles:return {}
  root=self._call(self.ptz,'GetPresets',f'<tptz:GetPresets><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken></tptz:GetPresets>');out={}
  for e in root.iter():
   if local(e.tag)=='Preset':
    token=e.attrib.get('token','');name=next(((c.text or '').strip() for c in e if local(c.tag)=='Name'),token)
    if token:out[name or token]=token
  self.presets=out;return out
 def stop(self):self._call(self.ptz,'Stop',f'<tptz:Stop><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>')
 def goto_preset(self,token):self._call(self.ptz,'GotoPreset',f'<tptz:GotoPreset><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:PresetToken>{esc(token)}</tptz:PresetToken></tptz:GotoPreset>')
 def absolute_move(self,pan,tilt,zoom=0.0,speed=0.5):
  pan=max(-1,min(1,float(pan)));tilt=max(-1,min(1,float(tilt)));zoom=max(0,min(1,float(zoom)));speed=max(0.01,min(1,float(speed)))
  b=f'<tptz:AbsoluteMove><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:Position><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Position><tptz:Speed><tt:PanTilt x="{speed}" y="{speed}"/><tt:Zoom x="{speed}"/></tptz:Speed></tptz:AbsoluteMove>';self._call(self.ptz,'AbsoluteMove',b)
 def continuous_move(self,pan,tilt,zoom=0.0,duration=0.2):
  pan=max(-1,min(1,float(pan)));tilt=max(-1,min(1,float(tilt)));zoom=max(-1,min(1,float(zoom)));duration=max(.05,min(2,float(duration)))
  b=f'<tptz:ContinuousMove><tptz:ProfileToken>{esc(self.profile())}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="{pan}" y="{tilt}"/><tt:Zoom x="{zoom}"/></tptz:Velocity></tptz:ContinuousMove>'
  try:self._call(self.ptz,'ContinuousMove',b);time.sleep(duration)
  finally:self.stop()
