PTZ Patrol Controller REAL v1.2.0
=================================
This release replaces the placeholder camera layer with direct SOAP 1.2 operations.
There is no simulator backend, no generated camera state, and no invented preset token.

Files:
- PTZ_Patrol_Controller_REAL_v1_2_0.py: complete GUI and patrol application.
- real_onvif_camera_v1_2_0.py: real ONVIF Device/Media/PTZ backend.
- config_REAL_v1_2_0.txt: verified camera facts from the deep test.

Run:
py -3 PTZ_Patrol_Controller_REAL_v1_2_0.py

The GUI connects to 192.168.1.102:8899, reads real profiles/status, supports manual
bounded ContinuousMove with guaranteed Stop, and patrols through real AbsoluteMove
positions. Default patrol positions are editable in the GUI. Coordinates use pan/tilt
-1.0..1.0 and zoom 0.0..1.0. Start at speed 0.5 and keep Stop accessible.

The camera currently has zero presets, so this release does not invent or use preset IDs.
Preset support can be added after SetPreset is explicitly tested and real tokens exist.
