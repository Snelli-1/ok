#!/usr/bin/env python3
"""PTZ Patrol Controller REAL v1.2.0. No simulation backend."""
import configparser,logging,queue,threading,time,traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from real_onvif_camera_v1_2_0 import RealOnvifCamera
BASE=Path(__file__).resolve().parent;LOGDIR=BASE/'logs_real';LOGDIR.mkdir(exist_ok=True)
logging.basicConfig(filename=LOGDIR/'application_real.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('PTZ Patrol Controller REAL v1.2.0');self.geometry('960x640');self.cam=None;self.stop_event=threading.Event();self.pause_event=threading.Event();self.q=queue.Queue();self.steps=[];self._ui();self.after(100,self._drain)
 def _ui(self):
  top=ttk.Frame(self,padding=8);top.pack(fill='x')
  self.host=tk.StringVar(value='192.168.1.102');self.port=tk.IntVar(value=8899);self.speed=tk.DoubleVar(value=.5);self.dwell=tk.DoubleVar(value=5.0)
  for text,var,w in [('Host',self.host,18),('ONVIF port',self.port,8),('Speed',self.speed,6),('Dwell s',self.dwell,6)]:ttk.Label(top,text=text).pack(side='left');ttk.Entry(top,textvariable=var,width=w).pack(side='left',padx=4)
  for text,cmd in [('Connect',self.connect),('Status',self.status),('Stop',self.emergency),('Start patrol',self.start_patrol),('Pause/Resume',self.pause)]:ttk.Button(top,text=text,command=cmd).pack(side='left',padx=3)
  manual=ttk.LabelFrame(self,text='Real camera manual control',padding=8);manual.pack(fill='x',padx=8,pady=4)
  for text,p,t in [('Left',-.15,0),('Right',.15,0),('Up',0,.15),('Down',0,-.15)]:ttk.Button(manual,text=text,command=lambda p=p,t=t:self.run(lambda:self.cam.continuous_move(p,t,0,.2))).pack(side='left',padx=4)
  ttk.Button(manual,text='Zoom +',command=lambda:self.run(lambda:self.cam.continuous_move(0,0,.15,.2))).pack(side='left');ttk.Button(manual,text='Zoom -',command=lambda:self.run(lambda:self.cam.continuous_move(0,0,-.15,.2))).pack(side='left')
  patrol=ttk.LabelFrame(self,text='Absolute patrol positions: name, pan, tilt, zoom',padding=8);patrol.pack(fill='both',expand=True,padx=8,pady=4)
  self.tree=ttk.Treeview(patrol,columns=('name','pan','tilt','zoom'),show='headings',height=8)
  for c in ('name','pan','tilt','zoom'):self.tree.heading(c,text=c);self.tree.column(c,width=125)
  self.tree.pack(fill='x');
  for row in [('Center',0,0,0),('Left view',-.6,0,0),('Right view',.6,0,0)]:self.tree.insert('', 'end',values=row)
  edit=ttk.Frame(patrol);edit.pack(fill='x',pady=4);self.name=tk.StringVar(value='Position');self.pan=tk.DoubleVar();self.tilt=tk.DoubleVar();self.zoom=tk.DoubleVar()
  for text,var in [('Name',self.name),('Pan -1..1',self.pan),('Tilt -1..1',self.tilt),('Zoom 0..1',self.zoom)]:ttk.Label(edit,text=text).pack(side='left');ttk.Entry(edit,textvariable=var,width=10).pack(side='left',padx=3)
  ttk.Button(edit,text='Add',command=lambda:self.tree.insert('', 'end',values=(self.name.get(),self.pan.get(),self.tilt.get(),self.zoom.get()))).pack(side='left');ttk.Button(edit,text='Delete',command=lambda:[self.tree.delete(x) for x in self.tree.selection()]).pack(side='left')
  self.log=tk.Text(self,height=14);self.log.pack(fill='both',padx=8,pady=5)
 def msg(self,s):self.q.put(str(s));logging.info(s)
 def _drain(self):
  while not self.q.empty():self.log.insert('end',self.q.get()+'\n');self.log.see('end')
  self.after(100,self._drain)
 def run(self,fn):
  def work():
   try:
    if not self.cam:raise RuntimeError('Connect first')
    fn()
   except Exception as e:self.msg('ERROR '+str(e));logging.error(traceback.format_exc())
  threading.Thread(target=work,daemon=True).start()
 def connect(self):
  def x():self.cam=RealOnvifCamera(self.host.get(),self.port.get(),logger=self.msg);self.msg('CONNECTED '+str(self.cam.connect()));self.msg('STATUS '+str(self.cam.status()))
  self.run_connect(x)
 def run_connect(self,fn):
  def w():
   try:fn()
   except Exception as e:self.msg('CONNECT ERROR '+str(e));logging.error(traceback.format_exc())
  threading.Thread(target=w,daemon=True).start()
 def status(self):self.run(lambda:self.msg(self.cam.status()))
 def emergency(self):
  self.stop_event.set()
  if self.cam:self.run(self.cam.stop)
  self.msg('EMERGENCY STOP requested')
 def pause(self):
  if self.pause_event.is_set():self.pause_event.clear();self.msg('RESUMED')
  else:self.pause_event.set();self.msg('PAUSED')
 def start_patrol(self):
  if not self.cam:return messagebox.showerror('Error','Connect first')
  rows=[self.tree.item(i)['values'] for i in self.tree.get_children()]
  if not rows:return
  self.stop_event.clear()
  def patrol():
   try:
    while not self.stop_event.is_set():
     for name,pan,tilt,zoom in rows:
      if self.stop_event.is_set():break
      while self.pause_event.is_set() and not self.stop_event.is_set():time.sleep(.1)
      self.msg(f'MOVE {name}: pan={pan} tilt={tilt} zoom={zoom} speed={self.speed.get()}')
      self.cam.absolute_move(float(pan),float(tilt),float(zoom),self.speed.get())
      end=time.monotonic()+self.dwell.get()
      while time.monotonic()<end and not self.stop_event.is_set():time.sleep(.1)
   except Exception as e:self.msg('PATROL ERROR '+str(e));logging.error(traceback.format_exc())
   finally:
    try:self.cam.stop()
    except Exception:pass
  threading.Thread(target=patrol,daemon=True).start()
if __name__=='__main__':App().mainloop()
