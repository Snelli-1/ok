#!/usr/bin/env python3
"""PTZ Real Camera Deep Tester v1.2.0 - Windows 10 Pro.
Dependency-free, real-device-only, no-auth-first, crash-safe diagnostic.
Creates a log before network or argument parsing begins.
"""
from __future__ import annotations
import argparse, base64, hashlib, http.client, ipaddress, json, os, re, secrets, socket, sys, time, traceback, urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

VERSION = "1.2.0"
SOAP12 = "http://www.w3.org/2003/05/soap-envelope"
SOAP11 = "http://schemas.xmlsoap.org/soap/envelope/"
TDS = "http://www.onvif.org/ver10/device/wsdl"
TRT = "http://www.onvif.org/ver10/media/wsdl"
TR2 = "http://www.onvif.org/ver20/media/wsdl"
TPTZ = "http://www.onvif.org/ver20/ptz/wsdl"
TT = "http://www.onvif.org/ver10/schema"
WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
WSU = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"

ERRORS = {
 "D000":"Real response received and parsed", "D001":"Informational checkpoint", "D101":"TCP connection failed",
 "D102":"Network timeout", "D103":"HTTP connection closed without response", "D104":"Unparseable HTTP body",
 "D201":"Camera returned SOAP fault", "D202":"Authorization required or rejected", "D203":"Operation unsupported",
 "D204":"Endpoint/path rejected", "D301":"No real media profile token", "D302":"No PTZ configuration token",
 "D303":"No real preset token", "D304":"No position data in real response", "D401":"Movement safety lock active",
 "D402":"Movement prerequisite missing", "D403":"Stop failed", "D501":"Log path fallback used",
 "D900":"Unexpected tester error; full traceback follows"
}

# Log is created before argparse and before any network action.
def create_log() -> Tuple[Path, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    candidates = [Path.cwd()/"PTZ_DEEP_TEST_LOGS", Path.home()/"Desktop"/"PTZ_DEEP_TEST_LOGS", Path(os.environ.get("TEMP", "."))/"PTZ_DEEP_TEST_LOGS"]
    failures=[]
    for directory in candidates:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            path=directory/f"PTZ_DEEP_TEST_{stamp}.txt"
            handle=path.open("w", encoding="utf-8", buffering=1)
            return path,handle
        except Exception as e: failures.append(f"{directory}: {type(e).__name__}: {e}")
    emergency=Path(f"PTZ_DEEP_TEST_EMERGENCY_{stamp}.txt")
    handle=emergency.open("w",encoding="utf-8",buffering=1)
    handle.write("LOG DIRECTORY FAILURES\n"+"\n".join(failures)+"\n")
    return emergency,handle

LOG_PATH, LOG_HANDLE = create_log()
SEQ=0
START=time.monotonic()
STATE: Dict[str,Any] = {"events":[],"xaddrs":[],"profiles":[],"ptz_configurations":[],"presets":[],"stream_uris":[],"snapshot_uris":[],"position":None}

def now(): return datetime.now(timezone.utc).isoformat()
def emit(text=""):
    print(text, flush=True)
    LOG_HANDLE.write(text+"\n"); LOG_HANDLE.flush()
def redact(text:Any)->str:
    s=str(text or "")
    s=re.sub(r"(?s)(<wsse:Password[^>]*>).*?(</wsse:Password>)",r"\1<REDACTED>\2",s)
    s=re.sub(r"(?s)(<wsse:Nonce[^>]*>).*?(</wsse:Nonce>)",r"\1<REDACTED>\2",s)
    s=re.sub(r"(?i)(authorization\s*[:=]\s*)\S+",r"\1<REDACTED>",s)
    s=re.sub(r"(rtsp://[^:/\s]+:)[^@\s]+@",r"\1<REDACTED>@",s)
    return s
def event(phase,operation,target,status,code,detail="",request="",response="",headers=None,elapsed=None):
    global SEQ
    SEQ+=1
    item={"seq":SEQ,"utc":now(),"elapsed_ms":int((elapsed if elapsed is not None else time.monotonic()-START)*1000),"phase":phase,"operation":operation,"target":target,"status":status,"code":code,"meaning":ERRORS.get(code,"Unknown code"),"detail":redact(detail),"request":redact(request),"response":redact(response),"headers":headers or {}}
    STATE["events"].append(item)
    emit(f"[{SEQ:03d}] {phase:<14} {operation:<30} {status:<11} {code:<5} {item['elapsed_ms']:>7} ms | {redact(detail)}")
    if request: emit("--- REQUEST ---\n"+redact(request))
    if headers: emit("--- HEADERS ---\n"+json.dumps(headers,indent=2,ensure_ascii=False))
    if response: emit("--- RESPONSE ---\n"+redact(response))
def section(title): emit("\n"+"="*100+"\n"+title+"\n"+"="*100)
def local(tag): return tag.rsplit("}",1)[-1]
def escape(s): return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")
def wsse(user,password):
    nonce=secrets.token_bytes(16); created=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    digest=base64.b64encode(hashlib.sha1(nonce+created.encode()+password.encode()).digest()).decode()
    return f'''<s:Header><wsse:Security s:mustUnderstand="1" xmlns:wsse="{WSSE}" xmlns:wsu="{WSU}"><wsse:UsernameToken><wsse:Username>{escape(user)}</wsse:Username><wsse:Password Type="{WSSE}#PasswordDigest">{digest}</wsse:Password><wsse:Nonce EncodingType="{WSSE}#Base64Binary">{base64.b64encode(nonce).decode()}</wsse:Nonce><wsu:Created>{created}</wsu:Created></wsse:UsernameToken></wsse:Security></s:Header>'''
def envelope(body,header="",soap12=True):
    soap=SOAP12 if soap12 else SOAP11
    return f'''<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="{soap}" xmlns:tds="{TDS}" xmlns:trt="{TRT}" xmlns:tr2="{TR2}" xmlns:tptz="{TPTZ}" xmlns:tt="{TT}" xmlns:wsse="{WSSE}" xmlns:wsu="{WSU}">{header}<s:Body>{body}</s:Body></s:Envelope>'''
def post(url,xml,timeout,soap12=True):
    u=urllib.parse.urlparse(url); cls=http.client.HTTPSConnection if u.scheme=="https" else http.client.HTTPConnection
    c=cls(u.hostname,u.port or (443 if u.scheme=="https" else 80),timeout=timeout)
    path=(u.path or "/")+("?"+u.query if u.query else "")
    ctype="application/soap+xml; charset=utf-8" if soap12 else "text/xml; charset=utf-8"
    try:
        c.request("POST",path,xml.encode("utf-8"),{"Content-Type":ctype,"User-Agent":f"PTZ-DeepTester/{VERSION}","Connection":"close"})
        r=c.getresponse(); data=r.read(2*1024*1024); return r.status,r.reason,dict(r.getheaders()),data.decode("utf-8",errors="replace")
    finally:c.close()
def parse(text): return ET.fromstring(text)
def fault(root): return any(local(e.tag)=="Fault" for e in root.iter())
def fault_words(root): return " | ".join((e.text or "").strip() for e in root.iter() if local(e.tag) in {"Value","Text","Reason","Subcode"} and (e.text or "").strip())
def auth_fault(http_status,root,text):
    t=((fault_words(root) if root is not None else "")+" "+text).lower()
    return http_status in (401,403) or any(x in t for x in ["notauthorized","unauthorized","failedauthentication"])
def texts(root,name): return [(e.text or "").strip() for e in root.iter() if local(e.tag)==name and (e.text or "").strip()]
def tokens(root,names):
    out=[]
    for e in root.iter():
        if local(e.tag) in names:
            v=e.attrib.get("token") or e.attrib.get(f"{{{TT}}}token")
            if v and v not in out: out.append(v)
    return out

def call(phase,op,url,body,args,permit_auth=True):
    attempts=[("NO_AUTH","")]
    for mode,header in attempts:
        for soap12 in (True,False):
            xml=envelope(body,header,soap12); st=time.monotonic()
            try:
                hs,reason,headers,text=post(url,xml,args.timeout,soap12)
                try: root=parse(text)
                except Exception:
                    event(phase,op,url,"HTTP_ONLY","D104",f"{mode} SOAP {'1.2' if soap12 else '1.1'} HTTP {hs} {reason}; body not XML",xml,text,headers,time.monotonic()-st); continue
                if fault(root):
                    why=fault_words(root) or "SOAP Fault"; code="D202" if auth_fault(hs,root,text) else "D203" if "notsupported" in why.lower() else "D201"
                    event(phase,op,url,"SOAP_FAULT",code,f"{mode} SOAP {'1.2' if soap12 else '1.1'} HTTP {hs}: {why}",xml,text,headers,time.monotonic()-st)
                    if auth_fault(hs,root,text) and permit_auth and args.username:
                        axml=envelope(body,wsse(args.username,args.password),soap12); ast=time.monotonic()
                        try:
                            ahs,areason,aheaders,atext=post(url,axml,args.timeout,soap12); aroot=parse(atext)
                            if fault(aroot): event(phase,op,url,"SOAP_FAULT","D202" if auth_fault(ahs,aroot,atext) else "D201",f"WSSE HTTP {ahs}: {fault_words(aroot)}",axml,atext,aheaders,time.monotonic()-ast)
                            else:
                                event(phase,op,url,"SOAP_OK","D000",f"WSSE SOAP {'1.2' if soap12 else '1.1'} real XML response",axml,atext,aheaders,time.monotonic()-ast); return aroot,atext,"WSSE"
                        except Exception as e:event(phase,op,url,"EXCEPTION","D900",f"WSSE {type(e).__name__}: {e}",axml,traceback.format_exc(),{},time.monotonic()-ast)
                    continue
                event(phase,op,url,"SOAP_OK","D000",f"{mode} SOAP {'1.2' if soap12 else '1.1'} real XML response",xml,text,headers,time.monotonic()-st); return root,text,mode
            except socket.timeout as e:event(phase,op,url,"TIMEOUT","D102",f"{mode}: {e}",xml,"",{},time.monotonic()-st)
            except http.client.RemoteDisconnected as e:event(phase,op,url,"DISCONNECTED","D103",f"{mode}: {e}",xml,"",{},time.monotonic()-st)
            except Exception as e:event(phase,op,url,"EXCEPTION","D900",f"{mode} {type(e).__name__}: {e}",xml,traceback.format_exc(),{},time.monotonic()-st)
    return None,"",""
def choose_xaddr(urls,needle,fallback):
    for u in urls:
        if needle.lower() in u.lower(): return u
    return fallback

def interactive_args():
    ap=argparse.ArgumentParser(description="Real-device-only dependency-free ONVIF/PTZ deep tester")
    ap.add_argument("--host",default="192.168.1.102");ap.add_argument("--port",type=int,default=8899);ap.add_argument("--username",default="");ap.add_argument("--password",default="");ap.add_argument("--timeout",type=float,default=5.0);ap.add_argument("--arm-motion",action="store_true");ap.add_argument("--version",action="version",version=VERSION)
    return ap.parse_args()
def main():
    args=interactive_args(); args.timeout=max(1.0,min(args.timeout,20.0))
    emit(f"PTZ Real Camera Deep Tester v{VERSION}")
    emit(f"LOG CREATED BEFORE TESTING: {LOG_PATH.resolve()}")
    emit(f"Python: {sys.version}")
    emit(f"Executable: {sys.executable}")
    emit(f"Working directory: {Path.cwd()}")
    emit(f"Arguments: host={args.host} port={args.port} username={'<provided>' if args.username else '<empty>'} motion={args.arm_motion}")
    if not ipaddress.ip_address(args.host).is_private: raise RuntimeError("Only private-LAN targets are permitted")
    device=f"http://{args.host}:{args.port}/onvif/device_service"
    section("00 REAL TCP CONNECTION")
    st=time.monotonic()
    try:
        with socket.create_connection((args.host,args.port),args.timeout) as s:event("network","TCP_CONNECT",f"{args.host}:{args.port}","PASS","D000",f"local={s.getsockname()} remote={s.getpeername()}",elapsed=time.monotonic()-st)
    except Exception as e:event("network","TCP_CONNECT",f"{args.host}:{args.port}","FAIL","D101",f"{type(e).__name__}: {e}",response=traceback.format_exc(),elapsed=time.monotonic()-st);return 2

    section("01 DEVICE SERVICE: EXACT DEPENDENCY ORDER")
    operations=[
      ("GetSystemDateAndTime","<tds:GetSystemDateAndTime/>"),
      ("GetDeviceInformation","<tds:GetDeviceInformation/>"),
      ("GetCapabilities","<tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>"),
      ("GetServices","<tds:GetServices><tds:IncludeCapability>true</tds:IncludeCapability></tds:GetServices>"),
      ("GetScopes","<tds:GetScopes/>"),
      ("GetNetworkInterfaces","<tds:GetNetworkInterfaces/>"),
      ("GetHostname","<tds:GetHostname/>"),
      ("GetNetworkProtocols","<tds:GetNetworkProtocols/>"),
    ]
    roots={}
    for op,body in operations:
        root,raw,mode=call("device",op,device,body,args);roots[op]=root
        if root is not None:
            for x in texts(root,"XAddr"):
                if x not in STATE["xaddrs"]:STATE["xaddrs"].append(x)
        time.sleep(.25)
    media=choose_xaddr(STATE["xaddrs"],"media",f"http://{args.host}:{args.port}/onvif/media_service")
    ptz=choose_xaddr(STATE["xaddrs"],"ptz",f"http://{args.host}:{args.port}/onvif/ptz_service")
    event("decision","SELECT_ENDPOINTS",args.host,"INFO","D001",f"device={device} media={media} ptz={ptz}; advertised={STATE['xaddrs']}")

    section("02 MEDIA PROFILE/TOKEN CHAIN")
    root,raw,mode=call("media","GetProfiles",media,"<trt:GetProfiles/>",args)
    if root is not None:
        STATE["profiles"]=tokens(root,{"Profiles","Profile"});STATE["ptz_configurations"]=tokens(root,{"PTZConfiguration"})
        event("extract","REAL_PROFILE_TOKENS",media,"INFO","D001",json.dumps(STATE["profiles"]))
        event("extract","REAL_PTZ_CONFIG_TOKENS",media,"INFO","D001",json.dumps(STATE["ptz_configurations"]))
    else:event("extract","REAL_PROFILE_TOKENS",media,"FAIL","D301","No parseable GetProfiles response")
    for token in STATE["profiles"]:
        body=f'<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup><trt:ProfileToken>{escape(token)}</trt:ProfileToken></trt:GetStreamUri>'
        r,_,_=call("media","GetStreamUri",media,body,args)
        if r is not None:
            for u in texts(r,"Uri"):
                if u not in STATE["stream_uris"]:STATE["stream_uris"].append(u)
        r,_,_=call("media","GetSnapshotUri",media,f'<trt:GetSnapshotUri><trt:ProfileToken>{escape(token)}</trt:ProfileToken></trt:GetSnapshotUri>',args)
        if r is not None:
            for u in texts(r,"Uri"):
                if u not in STATE["snapshot_uris"]:STATE["snapshot_uris"].append(u)

    section("03 PTZ READ-ONLY CAPABILITY CHAIN")
    call("ptz","GetNodes",ptz,"<tptz:GetNodes/>",args)
    call("ptz","GetConfigurations",ptz,"<tptz:GetConfigurations/>",args)
    for cfg in STATE["ptz_configurations"]:
        call("ptz","GetConfigurationOptions",ptz,f'<tptz:GetConfigurationOptions><tptz:ConfigurationToken>{escape(cfg)}</tptz:ConfigurationToken></tptz:GetConfigurationOptions>',args)
    for token in STATE["profiles"]:
        r,_,_=call("ptz","GetStatus",ptz,f'<tptz:GetStatus><tptz:ProfileToken>{escape(token)}</tptz:ProfileToken></tptz:GetStatus>',args)
        if r is not None:
            pos=[e for e in r.iter() if local(e.tag)=="Position"]
            if pos:STATE["position"]=ET.tostring(pos[0],encoding="unicode")
        r,_,_=call("ptz","GetPresets",ptz,f'<tptz:GetPresets><tptz:ProfileToken>{escape(token)}</tptz:ProfileToken></tptz:GetPresets>',args)
        if r is not None:
            for p in tokens(r,{"Preset"}):
                if p not in STATE["presets"]:STATE["presets"].append(p)
    if STATE["position"] is None:event("extract","REAL_POSITION",ptz,"INFO","D304","Camera did not return Position; software estimation may be required")
    if not STATE["presets"]:event("extract","REAL_PRESETS",ptz,"INFO","D303","Camera returned no preset tokens")

    section("04 MOVEMENT SAFETY GATE")
    if not args.arm_motion:event("motion","ALL_MOVEMENT",ptz,"SKIP","D401","Read-only run; no movement XML was sent")
    elif not STATE["profiles"]:event("motion","ALL_MOVEMENT",ptz,"SKIP","D402","No real ProfileToken")
    else:
        token=STATE["profiles"][0]
        stop=f'<tptz:Stop><tptz:ProfileToken>{escape(token)}</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>'
        call("motion","Stop_before",ptz,stop,args)
        if STATE["presets"]:
            call("motion","GotoPreset_existing",ptz,f'<tptz:GotoPreset><tptz:ProfileToken>{escape(token)}</tptz:ProfileToken><tptz:PresetToken>{escape(STATE["presets"][0])}</tptz:PresetToken></tptz:GotoPreset>',args)
        else:
            move=f'<tptz:ContinuousMove><tptz:ProfileToken>{escape(token)}</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="0.06" y="0.0"/><tt:Zoom x="0.0"/></tptz:Velocity><tptz:Timeout>PT0.15S</tptz:Timeout></tptz:ContinuousMove>'
            call("motion","ContinuousMove_0.06",ptz,move,args);time.sleep(.15);call("motion","Stop_after",ptz,stop,args)

    section("05 FINAL CONFIGURATION RESULT")
    mode="NO_USABLE_REAL_PROFILE"
    if STATE["profiles"] and STATE["presets"]:mode="PRESET_ONLY_FIRST"
    elif STATE["profiles"] and STATE["position"]:mode="STANDARD_ONVIF_WITH_CAMERA_POSITION"
    elif STATE["profiles"]:mode="ONVIF_WITH_SOFTWARE_POSITION_ESTIMATION"
    final={"tester_version":VERSION,"real_device_only":True,"host":args.host,"onvif_port":args.port,"rtsp_port":554,"device_xaddr":device,"media_xaddr":media,"ptz_xaddr":ptz,"profile_tokens":STATE["profiles"],"ptz_configuration_tokens":STATE["ptz_configurations"],"preset_tokens":STATE["presets"],"stream_uris":STATE["stream_uris"],"snapshot_uris":STATE["snapshot_uris"],"position_xml":STATE["position"],"recommended_mode":mode,"production_rules":{"adapter":"real_onvif_only","simulation_disabled":True,"unknown_capabilities":"UNKNOWN_NOT_FALSE_NOT_TRUE","dry_run_initially":True}}
    emit(json.dumps(final,indent=2,ensure_ascii=False));STATE["final"]=final
    return 0

def finalize(exit_code):
    try:
        section("06 TESTER TERMINATION")
        event("system","EXIT",str(LOG_PATH.resolve()),"INFO","D001",f"exit_code={exit_code}; log exists={LOG_PATH.exists()}; size_before_close={LOG_PATH.stat().st_size if LOG_PATH.exists() else -1}")
        LOG_HANDLE.flush();os.fsync(LOG_HANDLE.fileno())
    except Exception:pass
    try:LOG_HANDLE.close()
    except Exception:pass
    print(f"\nLOG FILE WAS WRITTEN TO:\n{LOG_PATH.resolve()}\n",flush=True)

if __name__=="__main__":
    code=1
    try:code=main()
    except SystemExit as e:
        code=int(e.code or 0);event("system","SYSTEM_EXIT",str(LOG_PATH),"FAIL" if code else "INFO","D900" if code else "D001",f"SystemExit {code}",response=traceback.format_exc())
    except BaseException as e:
        event("system","UNHANDLED_EXCEPTION",str(LOG_PATH),"FAIL","D900",f"{type(e).__name__}: {e}",response=traceback.format_exc());code=1
    finally:finalize(code)
    raise SystemExit(code)
