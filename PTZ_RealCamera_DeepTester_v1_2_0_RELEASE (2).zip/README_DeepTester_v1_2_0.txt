PTZ REAL CAMERA DEEP TESTER v1.2.0
==================================

WHY THIS VERSION ALWAYS LEAVES A LOG
- The log file is created before argparse, IP validation, imports, or network access.
- Every line is flushed immediately.
- At shutdown fsync forces buffered data to disk.
- Unhandled exceptions and SystemExit are written with full tracebacks.
- If the current folder is unwritable, it falls back to Desktop, then TEMP.
- The BAT prints and opens the expected folder.

RUN
1. Rename RUN_DEEP_TEST_READ_ONLY_v1_2_0.bat.txt to RUN_DEEP_TEST_READ_ONLY_v1_2_0.bat.
2. Keep it beside PTZ_RealCamera_DeepTester_v1_2_0.py.
3. Double-click the BAT.
4. Return the newest PTZ_DEEP_TEST_*.txt.

NO DEPENDENCIES
Only Python standard-library modules are used. onvif-zeep, zeep and FFmpeg are not needed.

REAL-DEVICE RULES
- No production simulator or generated camera status exists in this file.
- Every SOAP_OK result contains XML actually received from 192.168.1.102.
- Every operation tries no authentication first.
- It retries SOAP 1.1 if SOAP 1.2 fails.
- WS-Security is attempted only after a real authorization fault and credentials supplied.
- All real XAddr, ProfileToken, PTZConfigurationToken and PresetToken values are extracted.
- Unknown remains UNKNOWN. It is never replaced with a favorable synthetic status.

READ-ONLY OPERATIONS
GetSystemDateAndTime, GetDeviceInformation, GetCapabilities, GetServices, GetScopes,
GetNetworkInterfaces, GetHostname, GetNetworkProtocols, GetProfiles, GetStreamUri,
GetSnapshotUri, GetNodes, GetConfigurations, GetConfigurationOptions, GetStatus,
GetPresets.

MOVEMENT
No movement is sent in the standard BAT run. Do not use --arm-motion until the read-only
log has been reviewed and real profile/PTZ tokens are known.
