PTZ PATROL CONTROLLER REAL v1.4.0
=================================

Real ONVIF-only controller for the verified camera at 192.168.1.102:8899.
No mock camera, fake capability, video decoder, invented preset or silent fallback.

Main features
- Multi-camera list and up to eight functional radar tiles where the design showed CAM boxes.
- Radar shows software-estimated center line of sight, never falsely labels 0/0 ONVIF as true.
- Calibration based on measured 52 clicks per 360 degrees = 6.9230769 degrees/click.
- Current direction can be assigned 0 degrees and marked calibrated.
- Real camera UTC and computer/camera clock skew.
- Real GetStatus values shown separately from estimated radar direction.
- Continuous round-robin patrol among all enabled cameras.
- Independent patrol point, dwell and speed settings for every camera.
- Automatic reconnect after real network/SOAP failure.
- Global Emergency Stop and guaranteed Stop after bounded manual ContinuousMove.
- State, last error, last successful response age and PTZ MoveStatus display.
- Persistent camera, patrol and radar calibration configuration.

Patrol note
AbsoluteMove patrol works on the tested camera, but its GetStatus position is unreliable.
After an AbsoluteMove the radar uses the commanded Pan as an ESTIMATED direction. Manual
Left/Right increments use 6.9230769 degrees per click. If another application moves the
camera, or communication fails, mark/recalibrate the direction.

Start
1. Keep both Python files and config_REAL_v1_4_0.ini in one folder.
2. Rename RUN_REAL_v1_4_0.bat.txt to RUN_REAL_v1_4_0.bat.
3. Run the BAT.
4. Connect selected.
5. Test one short manual movement and Stop.
6. Point the camera at a chosen reference and press SET CURRENT = 0 degrees.
7. Press MARK CALIBRATED.
8. Start auto patrol only after the radar direction behaves correctly.
